# Proof-source coverage manifest — mean-oscillation self-improvement

CORPUS: source/self-improvement.tex sha256:7f218e9763a8e92c344ec7e1f6a7d1d6b0ea5ca81fae924d7d237903c92a3644; source/reference.txt sha256:ca07c7ca2f799428e70b9d84a9abfa2923c811d7b5df8c8b1c46bd5c7ce394c9

## Inventory

ITEM: tex-section-heading
KIND: heading
SOURCE: source/self-improvement.tex#pt.1@L1-L3
DISPOSITION: NODE selfimprovement
REASON: section heading and introductory sentence announce the root lemma and subsequent out-of-root theorem application
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-root-statement
KIND: lemma
SOURCE: source/self-improvement.tex#selfimprovement@L5-L39
DISPOSITION: NODE selfimprovement
REASON: exact source statement for the joint frozen root
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-root-hosc-definition
KIND: definition
SOURCE: source/self-improvement.tex#selfimprovement-hosc@L6-L10
DISPOSITION: NODE selfimprovement
REASON: theorem-local definition is part of the root statement contract
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-relative-display
KIND: display
SOURCE: source/self-improvement.tex#eq:abstractrelative@L11-L21
DISPOSITION: NODE selfimprovement
REASON: conditional hypothesis is recorded verbatim in the root source fields
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-exponent-display
KIND: definition
SOURCE: source/self-improvement.tex#eq:exponent@L22-L28
DISPOSITION: NODE selfimprovement
REASON: exponent definition and admissible range are part of the root contract
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-fractional-display
KIND: display
SOURCE: source/self-improvement.tex#eq:abstractfractional@L29-L38
DISPOSITION: NODE selfimprovement, final-rescaling-estimate
REASON: root conclusion and the final proof step establishing its quantitative conjunct
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-fixed-ball-definitions
KIND: definition
SOURCE: source/self-improvement.tex#fixed-ball-definitions@L41-L55
DISPOSITION: NODE oscillation-tail-definitions
REASON: fixed-ball normalization and all tail quantities
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-cover-and-tailfinite
KIND: proof-region
SOURCE: source/self-improvement.tex#eq:tailfinite@L56-L77
DISPOSITION: NODE tailfinite
REASON: finite cover and initial tail bound form one reusable obligation
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-centre-average-lower
KIND: proof-region
SOURCE: source/self-improvement.tex#averaged-lower-bound@L78-L102
DISPOSITION: NODE averaged-lower-bound
REASON: Tonelli and ball-containment lower bound
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-centre-average-upper
KIND: proof-region
SOURCE: source/self-improvement.tex#averaged-upper-bounds@L104-L124
DISPOSITION: NODE averaged-upper-bounds
REASON: separate oscillation and μ-error estimates
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-tailinequality-display
KIND: display
SOURCE: source/self-improvement.tex#eq:tailinequality@L125-L131
DISPOSITION: NODE tailinequality
REASON: one-scale tail inequality
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-tailintegration-display
KIND: display
SOURCE: source/self-improvement.tex#eq:tailintegration@L132-L153
DISPOSITION: NODE tailintegration
REASON: integrated recurrence and identities
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-contraction-display
KIND: display
SOURCE: source/self-improvement.tex#contract@L154-L160
DISPOSITION: NODE contract
REASON: hole-filling contraction
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-discrete-iteration
KIND: proof-region
SOURCE: source/self-improvement.tex#discrete-tail-decay@L161-L169
DISPOSITION: NODE discrete-tail-decay
REASON: discrete recurrence and geometric-series estimate
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-continuous-decay
KIND: display
SOURCE: source/self-improvement.tex#continuous-tail-decay@L170-L176
DISPOSITION: NODE continuous-tail-decay
REASON: transfers discrete decay to every scale
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-weighted-moment
KIND: display
SOURCE: source/self-improvement.tex#weighted-oscillation-moment@L177-L184
DISPOSITION: NODE weighted-oscillation-moment
REASON: integration-by-parts estimate needed by the Besov input
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-lp-application
KIND: proof-region
SOURCE: source/self-improvement.tex#fixed-ball-fractional@L185-L196
DISPOSITION: NODE fixed-ball-fractional, dorronsoro-local-mean-oscillation
REASON: fixed-ball conclusion explicitly invokes the cited external characterization
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-fractional-exponent-admissibility
KIND: proof-region
SOURCE: source/self-improvement.tex#fixed-ball-fractional@L177-L196
DISPOSITION: NODE fractional-exponent-admissibility
REASON: omitted discharge of the 0<s<1 premise for the cited fractional characterization
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-dorronsoro-citation
KIND: citation
SOURCE: source/self-improvement.tex#DorBesov-citation@L185-L196
DISPOSITION: NODE dorronsoro-local-mean-oscillation
REASON: cited LP/Besov input is an explicit external boundary
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-m-zero-strengthening
KIND: corollary
SOURCE: source/self-improvement.tex#m-zero-strengthening@L197-L198
DISPOSITION: EXCLUDED
REASON: explicit out-of-root-closure strengthening for M=0; the approved joint frozen root asserts only s<min{s₀,σ/2} and c(n,K,σ,s)
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-scaled-data
KIND: definition
SOURCE: source/self-improvement.tex#scaled-data@L200-L213
DISPOSITION: NODE scaled-data, scaled-oscillation-identity
REASON: Step 2 data definitions and the separate displayed change-of-variables identity
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-scaled-relative
KIND: proof-region
SOURCE: source/self-improvement.tex#scaled-relative-hypothesis@L215-L234
DISPOSITION: NODE scaled-relative-hypothesis
REASON: discharges the root hypothesis for rescaled data
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-scaled-local-data-admissibility
KIND: proof-region
SOURCE: source/self-improvement.tex#apply-fixed-ball@L201-L235
DISPOSITION: NODE scaled-local-data-admissibility
REASON: omitted affine-pullback transfer of local integrability and nonnegativity before Step 1 is reapplied
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-apply-fixed-ball
KIND: proof-region
SOURCE: source/self-improvement.tex#apply-fixed-ball@L235-L242
DISPOSITION: NODE apply-fixed-ball-after-scaling
REASON: applies Step 1 to rescaled data
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-rescale-back
KIND: proof-region
SOURCE: source/self-improvement.tex#final-rescaling@L243-L244
DISPOSITION: NODE final-rescaling-estimate, local-compact-membership
REASON: quantitative rescaling is asserted, while the separate local compact-set conclusion is omitted and exposed as a source gap
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: tex-final-theorem-application
KIND: theorem
SOURCE: source/self-improvement.tex#maint-application@L246-L267
DISPOSITION: EXCLUDED
REASON: explicit out-of-root-closure application of the lemma to Proposition prop:relative and Theorem maint; no additional frozen anchor was approved
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: reference-ambient-setting
KIND: assumption
SOURCE: source/reference.txt#ambient-setting@L24-L31
DISPOSITION: NODE selfimprovement
REASON: supplies the paper-level ambient domain and dimension assumptions recorded in the root source fields and frozen statement header
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: reference-pre-section4-introduction
KIND: proof-region
SOURCE: source/reference.txt#pre-section4-introduction@L2-L23
DISPOSITION: EXCLUDED
REASON: front matter and introductory context outside the approved Lemma 4.1 root closure
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: reference-pre-section4-body
KIND: proof-region
SOURCE: source/reference.txt#pre-section4-body@L32-L491
DISPOSITION: EXCLUDED
REASON: assumptions, preliminaries, and Sections 2–3 lie outside the approved Lemma 4.1 root closure after extracting its ambient setting
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: reference-section4-heading
KIND: heading
SOURCE: source/reference.txt#section-4@L492-L495
DISPOSITION: NODE selfimprovement
REASON: corroborating OCR heading for the root source section
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: reference-root-statement
KIND: lemma
SOURCE: source/reference.txt#lemma-4.1@L496-L537
DISPOSITION: NODE selfimprovement
REASON: corroborating OCR copy of the root statement; canonical locators use the TeX source
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: reference-root-proof
KIND: proof-region
SOURCE: source/reference.txt#lemma-4.1-proof@L538-L729
DISPOSITION: NODE oscillation-tail-definitions, tailfinite, averaged-lower-bound, averaged-upper-bounds, tailinequality, tailintegration, contract, discrete-tail-decay, continuous-tail-decay, weighted-oscillation-moment, fractional-exponent-admissibility, dorronsoro-local-mean-oscillation, fixed-ball-fractional, scaled-data, scaled-oscillation-identity, scaled-local-data-admissibility, scaled-relative-hypothesis, apply-fixed-ball-after-scaling, final-rescaling-estimate, local-compact-membership
REASON: corroborating OCR copy of the full root proof and its exposed omitted bridges
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: reference-final-theorem-application
KIND: theorem
SOURCE: source/reference.txt#theorem-1.1-application@L731-L760
DISPOSITION: EXCLUDED
REASON: explicit out-of-root-closure application following Lemma 4.1
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: reference-post-section4-front
KIND: proof-region
SOURCE: source/reference.txt#post-section4-front@L761-L772
DISPOSITION: EXCLUDED
REASON: formalization remark, acknowledgments, AI statement, and unrelated bibliography header contain no additional in-root proof obligations
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: reference-dorronsoro-bibliography
KIND: citation
SOURCE: source/reference.txt#reference-4@L775-L776
DISPOSITION: NODE dorronsoro-local-mean-oscillation
REASON: identifies the cited external mean-oscillation and Besov source
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review

ITEM: reference-post-section4-rest
KIND: proof-region
SOURCE: source/reference.txt#post-section4-rest@L777-L814
DISPOSITION: EXCLUDED
REASON: unrelated bibliography entries and author addresses contain no additional in-root proof obligations
COVERAGE_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review
