# Independent final statement audit: `meanOscillation_selfImprovement`

## Initial verdict (source and exact type only)

`DECLARATION_FIDELITY: PASS`

`DRAFT_ALLOWLIST: PASS`

`PROOF_STATUS: FROZEN_UNPROVED`

`CONSUMPTION: PENDING_PROVIDER_AND_SEAL`

`AXIOM_CLOSURE: PENDING_PROVIDER_AND_SEAL`

This initial audit approves the exact frozen theorem type as a faithful rendering of the approved source root. It does not claim that the theorem is proved. The registered provider was not available for final consumption and axiom inspection at this stage.

## Pinned identity

- Manifest anchor: `self-improvement-v1`.
- Contract: `mean-oscillation-self-improvement@1`.
- Frozen path: `Frozen/SelfImprovement.lean`.
- Frozen export: `AffineCarleson.meanOscillation_selfImprovement`.
- Kind/state: theorem, `DRAFT_SORRY`; registered proof status `FROZEN_UNPROVED`.
- Provider: module `AffineCarleson.SelfImprovement.Proof`, export `AffineCarleson.Internal.meanOscillation_selfImprovement`.
- Source: `source/self-improvement.tex`, statement lines 5--39, SHA-256 `7f218e9763a8e92c344ec7e1f6a7d1d6b0ea5ca81fae924d7d237903c92a3644`.
- Approved command and frozen file SHA-256: `58cc205979733e42ab1153778ef4be714b341359a4703a04a35243aed47f49c2`.
- Manifest ABI SHA-256: `d674c7a7c39e732be5b485fd2f30c7b0b6de0be5b33c17b71616a2a5d9ac0086`.
- Author approval: 2026-09-10, recorded in `audit/self-improvement-approval.md` and the manifest.

Mechanical checks independently recomputed on 2026-09-10:

1. `Frozen/SelfImprovement.lean` has the registered SHA-256.
2. `source/self-improvement.tex` has the registered SHA-256.
3. `audit/proposed-self-improvement-command.txt` has the registered SHA-256 and is byte-for-byte identical to the frozen file.
4. `Frozen/` contains exactly the two files owned by the manifest's two anchor entries.
5. The frozen theorem has exactly the registered proof body `by\n  sorry`; no other `sorry`, `admit`, custom `axiom`, `opaque`, `unsafe`, or custom option occurs in this file. `set_option autoImplicit false` is ordinary declaration hygiene, not a proof escape.

## Independent source reconstruction

The approved source root is Lemma 4.1 at TeX lines 5--39, read under the manuscript's standing Euclidean convention `n >= 2`. It has domain `Omega` open in `R^n`, target `R^m`, `g in L²_loc`, and a locally integrable a.e.-nonnegative scalar `mu`. For fixed `K >= 1`, `M >= 0`, and `sigma > 0`, the relative mean-oscillation estimate holds on every admissible `4R` ball, for `0 < R <= 1`.

For every `0 < s < min(s0,sigma/2)`, with

`s0 = log(1 + log(4)/(4^n K)) / (2 log(16))`,

there is a positive constant `c=c(n,K,sigma,s)` such that `g` has finite local `W^{s,2}` Gagliardo energy and the quantitative energy bound holds on each `R` ball whose `8R` closure lies in `Omega`. The quantifier order therefore requires `c` to be chosen after `n,K,sigma,s` and before `m,Omega,g,mu,M,x0,R`.

## Five-bin binder audit

Every logical input is expanded below. The existential witness and the two conclusion conjuncts are also shown so their scope is explicit, but they are not counted as theorem inputs.

| # | Lean binder/component | Bin | Source role |
|---:|---|---|---|
| 1 | `n : Nat` | TYPING | Coordinate dimension of `R^n`. |
| 2 | `hn : 2 <= n` | STANDING | Manuscript standing convention `n >= 2`. |
| 3 | `K : Real` | SOURCE | Fixed Carleson constant, lines 20--21. |
| 4 | `sigma : Real` | SOURCE | Fixed error exponent, lines 20--24. |
| 5 | `s : Real` | SOURCE | Fractional exponent quantified in lines 27--28. |
| 6 | `hK : 1 <= K` | SOURCE | Line 21. |
| 7 | `hSigma : 0 < sigma` | SOURCE | Line 21. |
| 8 | `hs : 0 < s` | SOURCE | Line 28. |
| 9 | `hs_upper` with the displayed exact `s0` | SOURCE | Lines 22--28. |
| 10 | `c : Real`, existential, with `0 < c` | CONCLUSION | The positive estimate constant from line 38. Its scope enforces exactly `c(n,K,sigma,s)`. |
| 11 | `m : Nat` | TYPING | Finite target coordinate type representing `R^m`. |
| 12 | `Omega : Set (Fin n -> Real)` | TYPING | Source domain. |
| 13 | `IsOpen Omega` | STANDING | The manuscript's open-domain convention. |
| 14 | `g : (Fin n -> Real) -> Fin m -> Real` | SOURCE | The `R^m`-valued map at line 6. |
| 15 | `mu : (Fin n -> Real) -> Real` | SOURCE | Scalar datum at line 7. |
| 16 | `M : Real` | SOURCE | Fixed error coefficient, lines 16 and 21. It is after `c`, as required. |
| 17 | `0 <= M` | SOURCE | Line 21. |
| 18 | compact test set `A` for local `L²` | SOURCE | Expansion of `g in L²_loc`, line 6. |
| 19 | `IsCompact A` | SOURCE | Compact-local test. |
| 20 | `A subset Omega` | SOURCE | Local-domain condition. |
| 21 | `alpha : Fin m` | TYPING | Coordinate expansion of finite-dimensional vector `L²`. |
| 22 | `MemLp (g_alpha) 2 (volume.restrict A)` | SOURCE | Componentwise exact local square integrability. |
| 23 | compact test set `A` for local `L¹` | SOURCE | Expansion of `mu in L¹_loc`, line 7. |
| 24 | `IsCompact A` | SOURCE | Compact-local test. |
| 25 | `A subset Omega` | SOURCE | Local-domain condition. |
| 26 | `IntegrableOn mu A` | SOURCE | Exact local integrability. |
| 27 | `mu >= 0` a.e. for `volume.restrict Omega` | SOURCE | Measure-theoretically exact reading of line 7. |
| 28 | hypothesis center `x0 : Fin n -> Real` | SOURCE | Universal center in (4.1). |
| 29 | hypothesis radius `R : Real` | SOURCE | Universal radius in (4.1). |
| 30 | `0 < R` | SOURCE | Line 20. |
| 31 | `R <= 1` | SOURCE | Line 20. |
| 32 | `closure (ball x0 (4*R)) subset Omega` | SOURCE | Finite-dimensional rendering of `B(x0,4R) compactly contained in Omega`. |
| 33 | relative mean-oscillation inequality | SOURCE | Equation (4.1), with normalized oscillation, unnormalized outer integrals, `K |B_4R|`, and the `M R^sigma integral mu` term. |
| 34 | finite fractional energy on every compact `A subset Omega` | CONCLUSION | Exact local fractional regularity when combined with the assumed local `L²`. |
| 35 | quantitative bound for every admissible `x0,R` | CONCLUSION | Equation (4.3), including the `8R` window. |

Input counts: `SOURCE = 26`, `STANDING = 2`, `TYPING = 4`, `RULED = 0`, `EXCESS = 0`. (Repeated compact-test binders and their premises are counted separately exactly as displayed.)

## Carrier, definitions, and conclusion semantics

- **Domain and target carriers:** `Fin n -> Real` and `Fin m -> Real` are the finite Euclidean coordinate models of `R^n` and `R^m`. All norm squares are the corresponding finite coordinate sums.
- **Ball:** `{y | sum_i (y_i-x_i)^2 < r^2}` is the literal open Euclidean ball for every positive radius used by the theorem.
- **Mean:** inverse ball volume times the componentwise ball integral is the source average `(g)_{x,r}`. All uses have positive radius, hence positive finite ball volume.
- **Oscillation:** inverse ball volume times the integral of the sum of coordinate squares is exactly the normalized `H_g(x,r)`.
- **Fractional energy:** the double `lintegral` of the nonnegative Gagliardo kernel has numerator `|g(x)-g(y)|²` and denominator `|x-y|^(n+2s)`, with Euclidean distance expressed as the square root of the coordinate sum. The diagonal convention is irrelevant because it is null in the approved `n >= 2` domain.
- **Compact containment:** for a positive-radius Euclidean ball in finite dimension, `closure ball subset Omega` is equivalent to the source notation `B compactly contained in Omega`, since the closed ball is compact.
- **Local regularity:** finiteness of the explicit energy on every compact subset of the open domain, together with the separately required local `L²`, is equivalent to source `W^{s,2}_loc`. It neither inserts an auxiliary theorem premise nor weakens the local finiteness claim.
- **Extended integrals:** the potentially improper nonnegative hypothesis integral and fractional energy use `ENNReal` `lintegral`, preserving finiteness and divergence. Ordinary ball integrals occur where local integrability supplies finiteness. `ENNReal.ofReal` embeds the nonnegative source quantities into the common inequality carrier.
- **Quantitative conclusion:** the Lean conclusion retains `0<R<=1`, `closure(B(x0,8R)) subset Omega`, energy on `B(x0,R)`, the exact `R^(-2s)` factor, and both terms integrated on `B(x0,8R)`.

No project-owned assumption bundle, proposition alias, gate, or pre-proved conclusion appears in the frozen type. In particular, none of the covering, Tonelli, hole-filling, tail-decay, kernel, rescaling, or local-fractional comparison results is assumed as a theorem premise.

## Adversarial checks

1. `c` cannot depend on `m`, `Omega`, `g`, `mu`, `M`, the center, or radius: all are quantified strictly after the existential.
2. The hypothesis and conclusion use separate universal ball binders, so no single favorable ball can witness either source assertion.
3. Componentwise local `L²` is equivalent to vector-valued local `L²` because `Fin m` is finite.
4. The coefficient of the relative estimate is exactly `K * volume(B_4R)`, with only the oscillation normalized; no average/ordinary-integral swap occurred.
5. The first conclusion and the quantitative conclusion are joined in the same result under the same chosen `c`; local membership has not been deferred to a later theorem.
6. Earlier manuscript inputs used only in the downstream application (Proposition 3.1, Gehring, and the `V` inequalities) are absent, as required for the abstract lemma.
7. The source proof's sharper `M=0` observation is not part of the displayed Lemma 4.1 conclusion and its absence does not change this frozen root.
8. The only proof hole is the manifest-authorized body of the exact frozen root. Consequently declaration fidelity can pass, but theorem closure cannot yet pass.

## Readiness for final provider audit

The source/type audit is ready for the post-provider phase. After the provider is assembled and the frozen anchor is sealed, the required remaining checks are:

1. verify that the only frozen-file change from SHA-256 `58cc2059...` is the registered proof-body replacement plus the already anticipated provider import arrangement;
2. compile a transient exact-type witness whose body is exactly `AffineCarleson.meanOscillation_selfImprovement`;
3. compile a transient term-level witness applying the registered internal provider at the exact frozen type;
4. inspect `#print axioms` for both the provider export and frozen export;
5. fail on `sorryAx`, any project custom axiom, hidden conclusion hypothesis, or unregistered trust input;
6. record final provider and frozen hashes, exact commands, output, and the definitive `PROVED` or failure verdict.

Until those checks pass, this audit certifies only the exact approved statement and its draft allowlist.

## Provider consumption audit (pre-seal)

Audit performed against provider SHA-256
`92f0a8f1cc888ac8b6be47f8fa34d3ab1537608de853445772f216f5c4fd74ef`.
The canonical frozen file remained at its approved draft SHA-256
`58cc205979733e42ab1153778ef4be714b341359a4703a04a35243aed47f49c2` throughout this phase.

`PROVIDER_TYPE_CONSUMPTION: PASS`

`QUANTITATIVE_CONSUMPTION: PASS`

`COMPACT_LOCALIZATION_CONSUMPTION: PASS`

`TRANSIENT_EXACT_EXPORT: PASS`

`TRANSIENT_ABI: PASS`

`TRANSIENT_AXIOMS: PASS`

`PROOF_STATUS: VERIFIED_FOR_SEAL`

This status authorizes sealing with the exact tested proof body. It is not yet the final `PROVED` verdict because the canonical frozen bytes and manifest are still in draft state and must be checked after the root performs the seal.

### Exact assembly and constant scope

`AffineCarleson.Internal.meanOscillation_selfImprovement` has the exact approved public theorem type. Its proof first obtains `C,hC,hbound` from `ball_selfImprovement n K sigma s ...`, before introducing `m,Omega,g,mu,M`. Thus the implementation realizes, rather than merely states, the required dependence `C=C(n,K,sigma,s)`.

For each requested ball, the provider derives local `L²`, local `L¹`, and local nonnegativity by restriction from the source hypotheses on the compact closure of the `8R` ball. It then supplies the relative hypothesis at every inner center and scale by composing:

- `t <= R` with the public `R <= 1`;
- `ball(c,4t) subset ball(x0,8R)` with closure monotonicity; and
- the enclosing `closure(ball(x0,8R)) subset Omega`.

No estimate, recurrence, regularity assertion, or conclusion is introduced as a new binder of the source-facing provider.

### Quantitative chain

The actual term path is:

`Proof.meanOscillation_selfImprovement`
→ `GeneralBallBound.ball_selfImprovement`
→ `UnitBound.unit_selfImprovement`
→ `RelativeDensity.relative_unit_tail_finite_and_le` and
  `RelativeDensity.relative_density_scale_le`
→ `TailIntegration.tailIntegral_contract`
→ `OscillationMoment.oscillation_weightedMoment_of_tail_contract`
→ `UnitFractional.unitFractionalEnergy_le_densityMoment`
→ affine rescaling in `ScaledBound.fractionalEnergy_le_of_scaled_unit_bound`.

Refute-first results:

| Concern | Evidence/refutation | Verdict |
|---|---|---|
| Internal shell with an unproduced recurrence premise | `unit_selfImprovement` constructs the scalar tail contraction from `relative_density_scale_le`, which itself consumes the actual normalized relative ball hypothesis. | Refuted |
| Finiteness smuggled into the moment theorem | `relative_unit_tail_finite_and_le` proves the finite unit tail from the actual radius-one relative estimate and local integrability. | Refuted |
| Unverified Littlewood--Paley citation used as an axiom | `UnitFractional` proves the inverse-power comparison directly through `KernelTonelli`, `NearPairs`, ball variance, and oscillation density. | Refuted |
| Scale-dependent or `M`-dependent output constant | `C` is chosen by the unit theorem before all later data; the rescaling theorem transports the same `C`. | Refuted |
| Incorrect rescaling power | `fractionalEnergy_le_of_scaled_unit_bound` proves the exact identity combining `R^(2s-n)`, Jacobian `R^n`, and `R^(-2s)`, yielding the source RHS. | Refuted |
| Source a.e. data silently strengthened to everywhere-measurable representatives | `GeneralBallBound` constructs measurable representatives `h,nu`, proves a.e. congruence back to `g,mu`, and rewrites both energy and RHS integrals before returning the source conclusion. | Refuted |
| Source relative estimate used outside its allowed radius/domain | The normalized call has radius `R*t <= R <= 1`; `rescaled_relative_ball_subset` supplies the `4Rt` inclusion in the enclosing `8R` ball, and the provider composes it into `Omega`. | Refuted |
| Lost coefficient in affine transport | `relativeOscillation_le_affineScale` transports both outer integral and RHS with the same inverse Jacobian and proves `(R*t)^sigma=R^sigma*t^sigma`. | Refuted |

### Compact-localization chain

The quantitative estimate gives diagonal energy finiteness on a sufficiently small ball about every `x in Omega`. `exists_enlarged_ballSet_closure_subset` chooses `0<r<=1` with the `8r` closure inside the open domain, so the already proved quantitative bound applies.

`lintegral_fractionalIntegrand_lt_top_of_compact` then treats the full compact product `A x A` as follows:

- near a diagonal point `(x,x)`, it uses the finite small-ball energy supplied above;
- near an off-diagonal point `(x,y)`, it chooses separated neighborhoods and bounds the kernel by local `L²` square functions with a positive distance lower bound;
- it packages the kernel as a with-density measure, proves finite-at-filter at every point of compact `A x A`, and obtains total finiteness from compactness;
- Tonelli identifies that product-measure result with the exact nested `lintegral` in the frozen conclusion.

This proves all cross-ball pairs; it does not infer compact energy merely from a finite cover of diagonal ball energies.

Refute-first results:

| Concern | Evidence/refutation | Verdict |
|---|---|---|
| Compact conclusion covers only diagonal pieces | Off-diagonal pairs are explicitly handled by `lintegral_fractionalIntegrand_lt_top_of_separated`. | Refuted |
| Separation estimate lacks local `L²` on both factors | Each neighborhood is contained in a compact closure inside `Omega`; the public local `L²` hypothesis is restricted to both factors. | Refuted |
| Product measure differs from the nested source integral | `lintegral_fractionalIntegrand_prod_eq_iterated` supplies the measurable Tonelli identity used by the compact proof. | Refuted |
| Kernel positivity exponent unavailable | Provider proves `0 < n + 2*s` from `2 <= n` and `0<s` before invoking compact localization. | Refuted |

### Transient exact sealed-export check

An untracked probe was produced from the exact approved frozen command by replacing only

```lean
by
  sorry
```

with

```lean
by
  exact Internal.meanOscillation_selfImprovement n hn K σ s hK hσ hs hs_upper
```

The existing provider import was unchanged. Command:

`lake env lean /Users/seabiscs/Documents/Codex/2026-09-10/tak-3/work/self-improvement/SealedSelfImprovementProbe.lean`

Result: exit code 0, no warning. The exact transient public export and provider export both reported:

`[propext, Classical.choice, Quot.sound]`

There was no `sorryAx`, custom project axiom, or other trust input. SHA-256 of the exact `repr ci.type` bytes between the audit markers was

`d674c7a7c39e732be5b485fd2f30c7b0b6de0be5b33c17b71616a2a5d9ac0086`,

exactly matching the registered ABI. The transient probe was deleted after these outputs were recorded.

### Remaining post-seal gate

After the canonical anchor is sealed, independently confirm:

1. its statement and ABI remain exact;
2. its proof body is byte-for-byte the tested assembly;
3. its canonical frozen export compiles without warnings;
4. its canonical `#print axioms` remains exactly the three standard axioms above; and
5. the manifest's sealed state and hashes match the actual files.

## Final canonical seal confirmation

`ROOT_DECLARATION_FIDELITY: PASS`

`ROOT_PROOF_BODY_IDENTITY: PASS`

`ROOT_ABI: PASS`

`ROOT_AXIOM_CLOSURE: PASS`

`ROOT_PROOF_STATUS: PROVED`

The canonical `Frozen/SelfImprovement.lean` has SHA-256
`49f91cefbde8960bc6d79fdfcd9e98787dac3326831011916ae2e89bb8c66c46`,
exactly matching both `frozen_file_sha256` and `sealed_file_sha256` in the
manifest. The manifest state and proof status are both `PROVED`, and quarantine
is inactive.

A direct diff against the author-approved draft command shows one change only:

```diff
-  sorry
+  exact Internal.meanOscillation_selfImprovement n hn K σ s hK hσ hs hs_upper
```

Thus the approved statement, imports, namespace, docstring, and all non-proof
bytes are unchanged. `python3 scripts/check_frozen.py` exits zero, independently
confirming the registered exact seal transition, ownership, source identity,
marker policy, and active import policy.

Direct canonical compilation commands:

- `lake env lean Frozen/SelfImprovement.lean` — exit 0, no output or warning.
- `lake env lean AffineCarleson/SelfImprovement/ZeroError.lean` — exit 0, no output or warning.

A transient probe importing `ZeroError` recomputed the canonical root type hash
as `d674c7a7c39e732be5b485fd2f30c7b0b6de0be5b33c17b71616a2a5d9ac0086`,
exactly the frozen ABI. Recursive `Lean.collectAxioms` reported:

- canonical root: `[propext, Classical.choice, Quot.sound]`;
- internal provider: `[propext, Classical.choice, Quot.sound]`;
- zero-error corollary: `[propext, Classical.choice, Quot.sound]`.

There is no `sorryAx`, project axiom, or unregistered trust input. The transient
probe was deleted.

The pre-seal removal of the unused local-`L²` premise from
`RelativeScale.relative_scale_le` was also checked. The theorem is an
extended-nonnegative-integral center-averaging bound and its proof uses
measurability of `g`, plus measurability, nonnegativity, and local integrability
of `mu`; it does not need local `L²`. Its sole call in
`RelativeDensity.relative_density_scale_le` was updated accordingly. The local
`L²` premise remains present there and is used by the separate oscillation-density
conversion. This cleanup strengthens an internal helper, does not add a premise,
and does not alter the provider or frozen theorem type/body.

## Zero-error source corollary audit

Target: `AffineCarleson.meanOscillation_selfImprovement_zeroError` in
`AffineCarleson/SelfImprovement/ZeroError.lean`, SHA-256
`8b140850fbb0a932070c669d112934d7e479acbffa9166bf0e18af60f12fdacf`.
Source anchor: TeX lines 197--198, which assert the same conclusion for `M=0`,
every `0<s<s0`, with constant `c(n,K,s)`.

`ZERO_ERROR_DECLARATION_FIDELITY: PASS`

`ZERO_ERROR_ROOT_CONSUMPTION: PASS`

`ZERO_ERROR_CONSTANT_SCOPE: PASS`

`ZERO_ERROR_AXIOM_CLOSURE: PASS`

`ZERO_ERROR_PROOF_STATUS: PROVED`

The corollary retains the approved domain dimension, open domain, finite target,
local `L²` hypothesis, relative zero-error estimate, local fractional-energy
conclusion, and the exact quantitative `8R` estimate. Its existential `c` occurs
after only `n,K,s` and their range conditions, before `m,Omega,g,x0,R`, so the
source dependence is enforced by the type.

The proof explicitly consumes the sealed public root, rather than importing an
internal substitute. It applies the root with

- `sigma := 4*s`, so `sigma>0` follows from `s>0`;
- `s < sigma/2` because `sigma/2=2s`;
- `mu := 0` and `M := 0`;
- direct proofs of local integrability and nonnegativity of zero.

The root returns a constant formally depending on `(n,K,4s,s)`. Since `4s` is a
fixed expression determined solely by `s`, this is exactly a dependence on
`(n,K,s)`, as the source requires. Simplification removes every error term and
converts the root's local definitions to the public `ballSet` and
`ballOscillation` expressions. No sigma, `mu`, `M`, or proof obligation remains
as a corollary binder.

Refute-first checks:

| Concern | Evidence/refutation | Verdict |
|---|---|---|
| General root only permits `s<min(s0,sigma/2)` | Choosing `sigma=4s` makes the second bound `s<2s`, proved from `s>0`; only `s<s0` remains. | Refuted |
| Constant secretly depends on a free sigma | `sigma` is the deterministic expression `4s`, introduced inside the proof after all corollary parameters. | Refuted |
| Error datum remains hidden | Both `mu` and `M` are literal zero terms supplied internally and simplify out of the conclusion. | Refuted |
| Corollary bypasses the frozen theorem | The proof names `AffineCarleson.meanOscillation_selfImprovement`, imported through `Frozen.SelfImprovement`. | Refuted |
| Corollary gains trust from the old draft | Canonical root is sealed; recursive axiom collection for the corollary has only the three standard axioms. | Refuted |

Final independent verdicts: the exact frozen root is `PROVED`, and the ordinary
zero-error corollary is `PROVED` relative only to that sealed root's standard
Lean trust boundary.
