# Unit-bound audit

## Scope and verdict

Read-only, refute-first audit of `UnitBound.lean`, `UnitFractional.lean`, and
`NearPairs.lean` against `source/self-improvement.tex` and the approved
`Frozen/SelfImprovement.lean` declaration.  I also inspected the immediately
used kernel layer-cake implementation and the relative-tail interfaces where
needed to check diagonal behavior and premise discharge.  I authored some of
those predecessor modules, so this is not an independent audit of their proofs.

**Verdict: PASS for the internal unit-ball theorem and its two geometric
comparison modules.**  I found no counterexample, hidden finiteness assumption,
constant-dependence error, or mismatch in the fractional kernel.  This does not
close the frozen theorem: the unit theorem deliberately has stronger
representative-level regularity hypotheses, and the frozen theorem still needs
localization, representative congruence, rescaling, and the compact-set
finiteness conclusion.

## Refutation checks

### 1. Quantifiers and constant independence: pass

`unit_selfImprovement` quantifies `n, K, σ, s` before producing `C`, and only
then quantifies `m, g, μ, M` (`UnitBound.lean` lines 13–21).  The explicit
construction

`C = 2 V + L D (c + d)`

at lines 33–39 depends only on `n, K, σ, s`: `V` is unit-ball volume in
dimension `n`; `D` comes from the weighted-moment theorem with arguments
`n,K,σ,s`; and `c,q,e,d,L` use only those parameters.  No later data enter the
chosen constant.  This agrees with the source's `c=c(n,K,σ,s)`
(`self-improvement.tex` lines 37–38) and the frozen quantifier order
(`Frozen/SelfImprovement.lean` lines 13–22).

The unit lemma is valid for every `n`; the frozen theorem's additional `2 ≤ n`
can be supplied when the unit result is consumed.  This strengthening creates
no mismatch.

### 2. Fractional exponent, strict near pairs, and diagonal: pass

The target denominator is exactly
`sqrt (∑ i, (u i - v i)^2) ^ (n + 2*s)` in `UnitBound.lean` lines 27–29 and
`UnitFractional.lean` lines 61–63, matching the frozen energy at lines 34–37.
The layer-cake exponent is instantiated as `a = n + 2*s`, with positivity
proved from `s>0` (`UnitFractional.lean` lines 71–79).

Near pairs use the strict condition `dist(toLp 2 u,toLp 2 v) < r`
throughout (`NearPairs.lean` lines 16–20, 27–38, 96–100), and the consumer
retains the strict square-root condition (`UnitFractional.lean` lines 93–103).
The intersection lower bound accepts the derived weak condition `dist ≤ r`,
which is a valid consequence of strict inequality and does not enlarge the
near-pair integrand.

At distance zero, the kernel layer-cake theorem uses injectivity of
`WithLp.toLp 2` to infer `u=v`, then the explicitly proved identity
`Q(u,u)=0`; `Q` is the sum of squared coordinate differences
(`UnitFractional.lean` lines 71–79).  Thus division at the diagonal is handled
by the zero numerator rather than by discarding the diagonal or assuming it has
measure zero.

### 3. ENNReal finiteness discipline: pass

The base, close-pair, and layer-cake estimates remain in `ENNReal`, so Tonelli
and monotonicity do not require kernel finiteness.  Cancellation of the
near-pair geometric factor proves both nonzero and non-top side conditions
before using `ENNReal.mul_le_mul_iff_right` (`NearPairs.lean` lines 114–137).

The only conversion of a tail integral to `ℝ` is guarded by the finite unit-tail
result.  `UnitBound.lean` obtains `< ⊤` from the actual relative hypothesis at
lines 63–65 and passes the resulting `≠ ⊤` to contraction and weighted-moment
lemmas (lines 74–87).  Products moved through `ofReal` have explicit
nonnegativity proofs (lines 40–48, 56–59, 99–106, 112–121).  No step infers a
finite fractional-energy left side before the final finite real upper bound is
established.

### 4. Conditional tail premises are discharged: pass

The source defines `E` and `Φ` at lines 44–49, derives unit-tail finiteness at
lines 56–78, the scale inequality at lines 78–131, contraction at lines
132–160, and the weighted moment at lines 161–184.  The Lean assembly follows
that dependency order:

- `relative_unit_tail_finite_and_le ... hrel` supplies both unit-tail finiteness
  and its energy/error bound (`UnitBound.lean` lines 63–65, 88–91).
- `relative_density_scale_le ... hrel` supplies every `0<t≤1/4` scale estimate
  (`UnitBound.lean` lines 66–73).
- `tailIntegral_contract` receives measurability, nonnegativity, finite unit
  tail, `σ>0`, and that derived scale estimate (`UnitBound.lean` lines 74–86).
- `oscillation_weightedMoment_of_tail_contract` receives the resulting
  contraction together with the already derived finite-tail premise
  (`UnitBound.lean` lines 32, 87).

Accordingly, the unit theorem assumes only the actual relative ball inequality;
it does not expose tail finiteness, contraction, decay, or a weighted moment as
an input.

### 5. Constants and absorption: pass

The scale coefficient is exactly `c = 4^n K`; the error coefficient is tracked
as `q X`, with `q=4^n` and `X=M∫_{B8}μ` (`UnitBound.lean` lines 34–37, 51–55,
66–73).  The contraction factor is
`c/(c+log 4)` (lines 74–86), giving the same exponent threshold as source lines
154–178.  The extra explicit factor
`e = 4^σ log 4/(c+log 4)` is absorbed into `d=q(1+e)` and hence into `C`; it
depends only on approved constant parameters.  Lines 88–121 absorb the unit
tail and error into `A+X`, exactly the unit-scale form of source lines 182–194.

`NearPairs.lean` derives the displayed factor `2^(n+1)|B_r|` by cancelling the
finite positive common-center measure factor (lines 114–137).  After the ball
volume scaling identity, `UnitFractional.lean` produces the weight
`r^(-2s-1)` and a coefficient depending only on `n,s` (lines 32–53, 92–123),
consistent with the local mean-oscillation comparison invoked by the source at
lines 185–196.

## Frozen-boundary limitation

The unit theorem assumes globally measurable representatives, pointwise
`μ≥0`, and `MemLp`/integrability on `B8` (`UnitBound.lean` lines 19–21).  The
frozen declaration supplies compact-local `MemLp` and integrability plus
`μ≥0` only almost everywhere on `Ω` (`Frozen/SelfImprovement.lean` lines
20–26).  Therefore `unit_selfImprovement` is a correct stronger-input internal
lemma, but it cannot by itself be cited as the frozen theorem.  A later assembly
must select measurable representatives, transfer the relative inequality and
energy by local a.e. congruence, derive the `B8` hypotheses from compact
containment, rescale, and separately prove fractional-energy finiteness on each
compact subset.  The current audit makes no source-closure claim.

## Mechanical verification

A transient probe imported `AffineCarleson.SelfImprovement.UnitBound`, printed
the exact export, and checked axioms for:

- `AffineCarleson.Internal.unit_selfImprovement`
- `AffineCarleson.Internal.unitFractionalEnergy_le_weightedOscillation`
- `AffineCarleson.Internal.unitFractionalEnergy_le_densityMoment`
- `AffineCarleson.Internal.nearPairs_le_integrated_ballPairs`
- `AffineCarleson.Internal.integrated_ballPairs_eq_oscillation`
- `AffineCarleson.Internal.nearPairs_le_oscillation`

Every declaration depends only on `[propext, Classical.choice, Quot.sound]`.
The probe exited successfully and was deleted.  No audited source file was
modified.
