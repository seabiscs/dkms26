# Audit evidence

Current release evidence:

- `verification-summary.json`: full verification result and per-module hashes.
- `verification-build.log`, `verification-axioms.tsv`, `verification-kernel-replay.log`, and `verification-sealed-axioms.log`: current compiler, recursive axiom, kernel replay, and frozen-root identity evidence.
- `final-statement-audit.md`: independent source-first statement review, provider review, final canonical seal confirmation, and zero-error corollary audit. The final sections supersede the earlier pre-seal gate in the same report.
- `unit-bound-audit.md`, `affine-scaling-audit.md`, and the earlier helper audits: scoped mathematical and Lean reviews. Each report states the exact snapshot and its limitations.
- `section4-coverage-closeout.md`: source-to-Lean map and explicit remaining PDE scope.
- `depgraph-publication-validation.log` and `section4-graph-*-review.md`: source-only graph checks and independent topology review.

Historical identity evidence is retained unchanged where it binds approved bytes: `proposed-self-improvement-command.txt`, `frozen-manifest-at-approval.json`, and `self-improvement-frozen-identity.log` describe the earlier draft state. The old identity log therefore includes the expected historical `sorryAx`; it is not the release's axiom report. Use `verification-sealed-axioms.log` for the current root.

Reports may mention local paths at which checks were performed. The project scripts derive their paths from the repository root and do not require those original directories. The source graph's reference transcription is included in `source/reference.txt`.
