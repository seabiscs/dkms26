# TailMeasure / Kernel focused audit

## Verdict and scope

**GREEN for the exact declarations audited.** `TailMeasure.lean` correctly realizes the
nonnegative density `ENNReal.ofReal (E r / r)` as a measure and proves its stated cumulative and
weighted `lintegral` identities. `Kernel.lean` correctly proves the inverse-power integral formula
on `0 < d ≤ 1` and the complementary bound for `1 ≤ d`.

This was a read-only tier-2 focused audit of statement semantics, proof closure, endpoint handling,
and total Bochner-integral behavior. It was not an audit of downstream Tonelli, layer-cake, tail
finiteness, or source-theorem closure.

## Frozen inputs (`frozen-v1`)

Frozen and rechecked on 2026-09-10:

| File | SHA-256 |
|---|---|
| `AffineCarleson/SelfImprovement/TailMeasure.lean` | `08add243140f13ac85a4acb614dfeb4c52b4176ad0d63093b613ac2f0b585c20` |
| `AffineCarleson/SelfImprovement/Kernel.lean` | `2211ec156a3073cca76a535664051dcdeee770cf30a41e7858c77db852a5b56a` |

The enclosing directory is not a Git repository, so no commit identifier was available. The two
SHA-256 values are the immutable audit anchors. The hashes were unchanged at closeout.

Permission envelope: read-only inspection of the two Lean sources; creation of this report under
`work/self-improvement`; scoped direct Lean checks permitted; no production edits, network use,
destructive cleanup, full build, or Mathlib rebuild.

## Statement ledger

| Declaration | Anchor at `frozen-v1` | Verdict | Semantic check |
|---|---:|---|---|
| `tailMeasure` | TailMeasure 20–23 | GREEN | Defines `volume.withDensity (ENNReal.ofReal (E r / r))`; negative density values are deliberately clipped to zero. |
| `tailMeasure_Ioc_eq_lintegral_Ioo` | TailMeasure 25–31 | GREEN | Exact equality in `ℝ≥0∞`; the right endpoint is removable because Lebesgue singletons are null. No measurability or finiteness assumption is needed for this measure-evaluation identity. |
| `tailMeasure_Ioc_mono` | TailMeasure 33–36 | GREEN | Direct set inclusion. It remains valid for negative endpoints and infinite masses. |
| `ofReal_tailMeasure_Ioc_toReal` | TailMeasure 38–42 | GREEN | The explicit `≠ ⊤` premise is exactly what is needed to recover an ENNReal value from `toReal`. |
| `lintegral_inversePower_tailMeasure` | TailMeasure 44–74 | GREEN | Correct with-density identity on `(0,1]`; global measurability of `E` supplies measurable density, and local nonnegativity makes `ofReal` multiplication exact. Both sides may equal `⊤`. |
| `inversePower_eq_one_add_integral` | Kernel 17–36 | GREEN | For `a>0` and `0<d≤1`, the antiderivative computation gives `d⁻ᵃ = 1 + a∫_(d,1) r⁻ᵃ⁻¹ dr`. |
| `inversePower_le_one` | Kernel 38–41 | GREEN | Correct monotonicity of a nonpositive real exponent on bases `d≥1`. |

## Endpoint and integral audit

The quoted tail anchor is:

> `tailMeasure E (Ioc 0 t) = ∫⁻ r in Ioo (0 : ℝ) t, ENNReal.ofReal (E r / r)`

The only set difference is `{t}`. Both the defining set integral and `tailMeasure E` are absolutely
continuous with respect to Lebesgue measure, so the endpoint contributes zero even if the raw
density is nonmeasurable or infinite there. The endpoint `0` is excluded on both sides.

The weighted identity is an ENNReal `lintegral` equality. It therefore does not silently invoke a
total Bochner integral and does not require weighted integrability. On `Ioo 0 1`, `r>0`, so the
assumption `0≤E r` implies `0≤E r/r`; this is precisely the sign needed for
`ENNReal.ofReal_mul`. The real power `r ^ (-q)` is positive on that interval for every real `q`.

The quoted kernel anchor is:

> `d ^ (-a) = 1 + a * ∫ r in Ioo d 1, r ^ (-a - 1)`

Although Lean's Bochner integral is total, the proof invokes `integral_rpow` on `[d,1]`. The premise
`d>0` keeps the interval away from the singularity at zero and establishes the genuine finite
integral formula. Replacing `Ioo d 1` by the interval integral only removes endpoints, which are
Lebesgue-null. The case `d=1` is consistent: the set integral is zero and both sides equal one.

## Adversarial refutation pass

The following candidate failures were tested against the exact hypotheses and did not survive:

1. **Nonmeasurable `E` breaks cumulative mass.** Refuted. `withDensity_apply` defines the measure
   evaluation by the ENNReal set integral for measurable sets without a measurability premise on
   the density. Measurability is required, and supplied, only for the later integration-against-
   density theorem.
2. **Changing `Ioc` to `Ioo` drops an endpoint atom.** Refuted. Lebesgue measure has no singleton
   atoms, and with-density measures are absolutely continuous with respect to their base measure.
3. **The kernel theorem exploits the zero value of a nonintegrable total Bochner integral.**
   Refuted. `d>0` and `d≤1` put the integration interval in a compact subset of `(0,∞)`;
   `integral_rpow` proves the actual integral formula there.
4. **The weighted identity needs `q>0`.** Refuted. It is an extended nonnegative integral identity;
   measurability and positivity of the weight on `(0,1)` hold for arbitrary real `q`.

No reportable mathematical or formal finding survived refutation.

## Proof closure and verification

Commands run from the project root:

```text
lake env lean AffineCarleson/SelfImprovement/TailMeasure.lean
lake env lean AffineCarleson/SelfImprovement/Kernel.lean
lake env lean /tmp/tail_kernel_axioms.lean
```

Both direct module checks completed with zero output. A source scan found no `sorry`, custom
`axiom`, `unsafe`, `proof_wanted`, or heartbeat/recursion-depth override. `#print axioms` for all six
theorems listed only standard foundations: `propext`, `Classical.choice`, and `Quot.sound`.

## Limitations and downstream obligations

- `tailMeasure` represents the positive part of `E(r)/r`. Identifying it with the unclipped source
  density requires nonnegativity of `E` on the region used. The weighted theorem supplies exactly
  that assumption on `(0,1)`; the bare definition and cumulative identity do not assert it.
- `tailMeasure_Ioc_eq_lintegral_Ioo` is an ENNReal statement. Converting cumulative masses to real
  numbers requires a separate finiteness proof, reflected by `ofReal_tailMeasure_Ioc_toReal`.
- `lintegral_inversePower_tailMeasure` proves an identity, not finiteness of either side. Any later
  use of `toReal`, subtraction, or a finite weighted moment must discharge finiteness separately.
- `Kernel.lean` supplies the one-dimensional radial kernel identities only. It does not justify a
  Tonelli interchange, pair-measure measurability, or the geometric lower-volume comparison needed
  downstream.
- No source-LaTeX constant normalization or downstream consumer theorem was audited here.

## Closeout

- Frozen hashes recorded and unchanged: yes.
- Every declaration in the two files classified: yes.
- Endpoint and total-integral traps checked: yes.
- Candidate findings independently challenged: yes; none survived.
- Scoped elaboration checks clean: yes.
- Axiom and placeholder census clean: yes.
- Production files modified: no.

Closeout status: **GREEN within the stated scope**.
