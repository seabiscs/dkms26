# Independent local topology review: Section 4 self-improvement graph

Reviewer: `section4_graph_local_review`  
Writer reviewed: `section4_graph`  
Scope: source topology only. This report does not certify any theorem proof.

## Boundary and material re-read

I read only the permitted artifacts: `source/self-improvement.tex` lines 1–267; `source/reference.txt` lines 1–120 and 480–813 as needed for ambient context, the Section 4 OCR copy, and bibliography; identity fields in `frozen-manifest.json` lines 1–70; the declaration statement header in `Frozen/SelfImprovement.lean` lines 13–50; and all records in `DEPGRAPH.md` and `DEPGRAPH_COVERAGE.md`. I did not inspect implementation Lean, imports, proof bodies beyond seeing the statement terminator, axioms, proof-status ledgers, or extractor-private material.

The recorded corpus and manifest hashes match the files. The root identity matches manifest anchor `self-improvement-v1`, export `AffineCarleson.meanOscillation_selfImprovement`, contract `mean-oscillation-self-improvement@1`, and ABI `d674c7a7c39e732be5b485fd2f30c7b0b6de0be5b33c17b71616a2a5d9ac0086` (manifest lines 27–34, 68; declaration header lines 13–50).

## Overall verdict

**FAIL pending two coverage corrections and one corresponding root-source correction.** The 18-node proof topology, all 23 direct edges, the three explicit source-gap boundaries, the M=0 exclusion, and the final theorem-application exclusion are otherwise faithful. The defect is provenance/coverage: the root records `n >= 2` and `Omega` open from the paper's ambient setup at `source/reference.txt` lines 24–31, but the graph's root locator cites only the standalone lemma at TeX lines 5–39 and coverage excludes all pre-Section-4 context. Likewise the external Dorronsoro boundary relies on bibliography item [4] at reference lines 773–776, while coverage excludes the entire bibliography.

## Node verdicts

| Node | Verdict | Exact spans re-read | Review |
|---|---|---|---|
| `selfimprovement` | **FAIL** | TeX 5–39, 235–244; reference 24–31, 496–537; manifest 27–34, 37–47, 68; frozen header 13–50 | Identity, conclusion, constant scope, two conjunctive dependencies, and exclusions are correct. `SOURCE_HYPOTHESES` includes ambient `n >= 2` and openness of `Omega`, but `STATEMENT_SOURCE` does not cite reference 24–31 and coverage excludes that evidence. Apply the replacement fragment below; no anchor change is requested. |
| `oscillation-tail-definitions` | PASS | TeX 43–55 | Correct boundary and no dependencies. |
| `tailfinite` | PASS | TeX 56–78 | The cover, use of (4.1), minimizing property, and `Phi(1)` bound form one substantive step. Its sole graph dependency is the definitions; (4.1) remains a theorem-local premise. |
| `averaged-lower-bound` | PASS | TeX 78–102 | Correctly isolates Tonelli/containment lower bound and directly uses the tail definitions. |
| `averaged-upper-bounds` | PASS | TeX 104–124 | Correctly captures both RHS estimates, including `mu >= 0`; the definitions edge is direct. |
| `tailinequality` | PASS | TeX 78–131 | Both lower and upper estimates are conjunctively consumed at lines 125–130; edge directions and use locators are correct. |
| `tailintegration` | PASS | TeX 132–153 | Directly consumes `tailinequality`; `tailfinite` directly supplies monotonicity/finite values used in the second inequality. |
| `contract` | PASS | TeX 154–160 | Faithful algebraic hole-filling contraction; no hidden alternate route. |
| `discrete-tail-decay` | PASS | TeX 161–169 | Correctly exposes iteration and geometric-sum control as one reusable obligation. |
| `continuous-tail-decay` | PASS | TeX 170–176 | Directly consumes discrete decay, monotonicity, and the `Phi(1)` bound from `tailfinite`. |
| `weighted-oscillation-moment` | PASS | TeX 177–184 | Quantifier/witness scope for `gamma` is correct; both decay and endpoint dependencies are direct. |
| `dorronsoro-local-mean-oscillation` | PASS | TeX 185–196; reference 685–699, 773–776 | Correct explicit external leaf. Its `SOURCE_GAP` honestly records that the cited manuscript does not state the exact localized/normalized theorem. Bibliographic coverage needs correction, but the node boundary is sound. |
| `fixed-ball-fractional` | PASS | TeX 185–196 | Correct conditional application; both weighted-moment and external-characterization premises are directly consumed. |
| `scaled-data` | PASS | TeX 200–214 | Correct definitions and oscillation scaling identity; no prerequisite node is needed. |
| `scaled-relative-hypothesis` | PASS | TeX 210–234 | Correctly discharges all substantive premises for the rescaled application, including `R rho <= 1`, and gets exactly `M_R = M R^sigma`. |
| `apply-fixed-ball-after-scaling` | PASS | TeX 235–242 | Both the preserved conditional hypothesis and fixed-ball conclusion are directly consumed. |
| `final-rescaling-estimate` | PASS | TeX 202–243 | Direct edges to the rescaled estimate and scaling definitions are correct. The omitted seminorm/integral scaling identities are properly exposed as a `SOURCE_GAP`, including the `R^(n-2s)` cancellation. |
| `local-compact-membership` | PASS | TeX 27–38, 235–244; frozen header 44–50 | The frozen/root conclusion has a distinct local-membership conjunct. The source omits its localization argument; the graph correctly retains an ordinary gap node depending on the ball estimate. |

### Required root correction

Replace only the root provenance locator (or add an explicit ambient-source field if the schema supports it):

```text
STATEMENT_SOURCE: source/self-improvement.tex#selfimprovement@L5-L39; source/reference.txt#ambient-setting@L24-L31
```

The `SOURCE_HYPOTHESES` may then retain `n >= 2; Omega subset R^n open`. If only the standalone TeX slice is intended as authoritative, the alternative is to remove those two ambient claims from the source-only fields; that would cease to match the already frozen header, so the source-context locator correction is the appropriate topology repair.

## Direct-edge audit

PASS for every recorded edge: `selfimprovement -> {final-rescaling-estimate, local-compact-membership}` (TeX 27–38, 235–243); `tailfinite -> oscillation-tail-definitions` (66–74); `averaged-lower-bound -> oscillation-tail-definitions` (87–101); `averaged-upper-bounds -> oscillation-tail-definitions` (108–123); `tailinequality -> {averaged-lower-bound, averaged-upper-bounds}` (125–130); `tailintegration -> {tailinequality, tailfinite}` (132–152); `contract -> tailintegration` (154–159); `discrete-tail-decay -> contract` (161–169); `continuous-tail-decay -> {discrete-tail-decay, tailfinite}` (170–175); `weighted-oscillation-moment -> {continuous-tail-decay, tailfinite}` (177–183); `fixed-ball-fractional -> {weighted-oscillation-moment, dorronsoro-local-mean-oscillation}` (185–196); `scaled-relative-hypothesis -> scaled-data` (210–233); `apply-fixed-ball-after-scaling -> {scaled-relative-hypothesis, fixed-ball-fractional}` (235–241); `final-rescaling-estimate -> {apply-fixed-ball-after-scaling, scaled-data}` (243); `local-compact-membership -> final-rescaling-estimate` (235–244).

No edge is reversed, merely chronological, or an incorrectly conjunctive encoding of alternatives. No alternative proof route is stated in the source. No standing-assumption leaf is needed. The only external leaf is the cited Dorronsoro result.

## Coverage-item verdicts

| Coverage item | Verdict | Exact spans re-read / correction |
|---|---|---|
| `tex-section-heading` | PASS | TeX 1–3. |
| `tex-root-statement` | PASS | TeX 5–39; maps the displayed local lemma statement. Ambient context is corrected separately below. |
| `tex-root-hosc-definition` | PASS | TeX 6–10. |
| `tex-relative-display` | PASS | TeX 11–21. |
| `tex-exponent-display` | PASS | TeX 22–28. |
| `tex-fractional-display` | PASS | TeX 29–38. |
| `tex-fixed-ball-definitions` | PASS | TeX 41–55. |
| `tex-cover-and-tailfinite` | PASS | TeX 56–77. |
| `tex-centre-average-lower` | PASS | TeX 78–102. |
| `tex-centre-average-upper` | PASS | TeX 104–124. |
| `tex-tailinequality-display` | PASS | TeX 125–131. |
| `tex-tailintegration-display` | PASS | TeX 132–153. |
| `tex-contraction-display` | PASS | TeX 154–160. |
| `tex-discrete-iteration` | PASS | TeX 161–169. |
| `tex-continuous-decay` | PASS | TeX 170–176. |
| `tex-weighted-moment` | PASS | TeX 177–184. |
| `tex-lp-application` | PASS | TeX 185–196. |
| `tex-dorronsoro-citation` | PASS | TeX 185–196; the invocation is mapped to the external leaf. |
| `tex-m-zero-strengthening` | PASS | TeX 197–198. Exclusion is concrete and valid: it strengthens the `s` range and constant scope beyond the approved frozen root, and is unused in proving that root. |
| `tex-scaled-data` | PASS | TeX 200–213. |
| `tex-scaled-relative` | PASS | TeX 215–234. |
| `tex-apply-fixed-ball` | PASS | TeX 235–242. |
| `tex-rescale-back` | PASS | TeX 243–244; both omitted quantitative scaling and qualitative localization are exposed. |
| `tex-final-theorem-application` | PASS | TeX 246–267. Exclusion is valid because it consumes Lemma 4.1 after the root proof and targets an unapproved theorem anchor. |
| `reference-pre-section4` | **FAIL** | Reference 2–491, especially 24–31. The broad exclusion hides the ambient `Omega subset R^n open` and `n,N >= 2` setup actually used by the root source fields/frozen header. Replace as below. |
| `reference-section4-heading` | PASS | Reference 492–495. |
| `reference-root-statement` | PASS | Reference 496–537. |
| `reference-root-proof` | PASS | Reference 538–729. |
| `reference-final-theorem-application` | PASS | Reference 731–760; same valid out-of-root rationale as the TeX application. |
| `reference-post-section4` | **FAIL** | Reference 761–813, especially bibliography 773–776. The broad exclusion hides the bibliographic identity of cited external result [4]. Replace as below. |

### Required coverage replacements

Replace `reference-pre-section4` by two inventory items (or equivalently narrow it and add the ambient item):

```text
ITEM: reference-ambient-setting
KIND: convention
SOURCE: source/reference.txt#ambient-setting@L24-L31
DISPOSITION: NODE selfimprovement
REASON: supplies the paper-level ambient domain and dimension assumptions recorded in the root source fields and frozen statement header

ITEM: reference-pre-section4-rest
KIND: proof-region
SOURCE: source/reference.txt#pre-section4-rest@L2-L23,L32-L491
DISPOSITION: EXCLUDED
REASON: paper context outside the approved Lemma 4.1 root closure after extracting its ambient setting
```

Replace `reference-post-section4` by a mapped bibliography item and a narrowed exclusion:

```text
ITEM: reference-dorronsoro-bibliography
KIND: citation
SOURCE: source/reference.txt#reference-4@L773-L776
DISPOSITION: NODE dorronsoro-local-mean-oscillation
REASON: identifies the manuscript's cited external Littlewood--Paley/Besov source [4]

ITEM: reference-post-section4-rest
KIND: proof-region
SOURCE: source/reference.txt#post-section4-rest@L761-L772,L777-L813
DISPOSITION: EXCLUDED
REASON: formalization remark, acknowledgments, AI statement, unrelated bibliography entries, and author addresses contain no additional in-root obligations
```

## Source gaps and exclusions

PASS: the LP/Besov boundary at TeX 185–196 is explicit and external, with the manuscript's missing localization/normalization statement preserved as a gap. PASS: the asserted rescaling at line 243 is exposed rather than silently reconstructed. PASS: the unstated passage from ball estimates to local compact membership at lines 235–244 is exposed. PASS: the M=0 strengthening at lines 197–198 and final application at lines 246–267 are correctly excluded from this frozen root. No further substantive bridge, witness-scope change, conditional-premise discharge, hidden external input, or route alternative was found.

## Follow-up review of narrow repairs

Date: 2026-09-10. Scope was restricted to the writer's changed records. I re-read TeX lines 154–169, 185–196, and 200–234; reference lines 24–31, 492–537, 685–699, and 767–780; and the changed graph/coverage records. No implementation Lean, proof bodies, statuses, axioms, or private rationale were inspected.

Overall follow-up verdict: **FAIL pending four narrow record corrections.** The revised mathematical node boundaries pass. Remaining failures concern exact locator precision, a stale edge rationale, and one omitted coverage mapping.

| Changed record | Verdict | Exact spans re-read | Finding / correction |
|---|---|---|---|
| `selfimprovement` `STATEMENT_SOURCE` / `NOTE` | **FAIL** | reference 24–31 and 492–537; TeX 5–39 | The note correctly identifies the two source pieces, but `@L24-L537` is not an exact locator: it swallows unrelated Sections 1–3 (lines 32–491). Use two exact locators if accepted: `source/self-improvement.tex#selfimprovement@L5-L39; source/reference.txt#ambient-setting@L24-L31`. If the schema enforces one locator, keep the exact TeX locator and put the ambient locator in `NOTE`; do not use the 514-line super-span. |
| `reference-ambient-setting` | PASS | reference 24–31 | Correctly maps the ambient open-domain and `n,N >= 2` context to the root. |
| `reference-pre-section4-introduction` | PASS | reference 2–23 | Narrow exclusion is correct. |
| `reference-pre-section4-body` | PASS | reference 32–491 | Narrow exclusion is correct after separately inventorying lines 24–31. |
| `reference-dorronsoro-bibliography` | **FAIL** | reference 773–776 | Item [4] occupies lines 775–776. Lines 773–774 are distinct item [3]. Replace its source with `source/reference.txt#reference-4@L775-L776`. |
| `reference-post-section4-front` | PASS | reference 761–772 | Correctly excludes front matter and unrelated bibliography items [1]–[2]. |
| `reference-post-section4-rest` | PASS | reference 777–813 | Correctly excludes unrelated entries [5] onward and addresses. Prefer actual EOF 813 rather than 814. |
| `discrete-tail-decay` source fields | PASS | TeX 161–169 | Moving `beta=...` and `r_k=...` from hypotheses into the conclusion faithfully models local definitions; `gamma` scope and recurrence are correct. |
| `dorronsoro-local-mean-oscillation` source fields / note | PASS | TeX 177–196; reference 685–699, 775–776 | The revision distinguishes the displayed invocation from unknown exact external hypotheses/quantifiers. The expanded `SOURCE_GAP` correctly preserves uncertainty about spatial support, localization, boundary extension, and normalization. |
| `scaled-data` | PASS with editorial cleanup | TeX 201–210 | Correctly limits the node to the three definitions and `B_8` containment. `CONSTANT_SCOPE: K,sigma remain unchanged` belongs to the later scaled-hypothesis result; `no new constants` would be cleaner but does not alter topology. |
| `scaled-oscillation-identity` | PASS | TeX 210–214 | The substantive change-of-variables identity merits its own step, and its dependency on `scaled-data` is direct. |
| `scaled-relative-hypothesis` dependencies | **FAIL (edge rationale only)** | TeX 210–234 | Both dependencies are direct. The `scaled-data` rationale still says it uses the oscillation identity, now owned by the other edge. Replace it with: `EDGE: scaled-data | source/self-improvement.tex#scaled-relative-hypothesis@L215-L233 | uses the definitions of Omega_R, g_R, and mu_R, the ball/domain correspondence, and the integral change of variables`. Keep the identity edge. |
| `tex-scaled-data` | PASS | TeX 200–214 | Correctly maps the combined source region to both the definition and identity nodes. |
| `reference-root-proof` disposition after split | **FAIL** | reference 538–729, especially 700–705 | The corroborating full-proof list omits `scaled-oscillation-identity`. Add it beside `scaled-data` and `scaled-relative-hypothesis`. |

All other aspects of these changes pass: no new route alternative appears, no conditional premise is hidden, and splitting the scaling identity introduces neither a cycle nor an unnecessary transitive edge.

## Final narrow verification after second repair

Date: 2026-09-10. **PASS.** I re-read only the four repaired records and their exact evidence spans.

- Root locator and note: PASS against TeX lines 5–39 and reference lines 24–31. `STATEMENT_SOURCE` is again the exact standalone lemma locator, while the note and separately mapped ambient coverage item preserve the source of `n >= 2` and open `Omega` without swallowing unrelated sections.
- Dorronsoro bibliography coverage: PASS against reference lines 773–776. The item now points exactly to bibliography entry [4], lines 775–776, excluding entry [3].
- `scaled-relative-hypothesis -> scaled-data` edge rationale: PASS against TeX lines 210–234. It now names the definitions, domain/ball correspondence, and integral change of variables; the distinct identity edge owns oscillation rewriting at lines 215–227.
- `reference-root-proof` disposition: PASS against reference lines 538–729, especially 700–705. It now includes `scaled-oscillation-identity` alongside `scaled-data` and `scaled-relative-hypothesis`.

The four prior failures are closed. This remains a source-topology verdict only and is not theorem proof certification.

## Review of global-review premise-discharge additions

Date: 2026-09-10. **PASS.** Scope was limited to the two new nodes, their changed target dependency lists and direct edges, the two new TeX coverage items, and the updated corroborating reference-proof disposition.

- `fractional-exponent-admissibility`: PASS against TeX lines 22–28 and 177–196, corroborated by reference lines 677–699. Its hypotheses reproduce the ambient `n >= 2`, `K >= 1`, the exact formula for `s_0`, and the selected `s` range. Its conclusion `0 < s < 1` is the missing premise needed by the fractional characterization. Leaving it as an explicit `SOURCE_GAP` with no graph prerequisites faithfully exposes the manuscript's omitted elementary logarithmic bound rather than pretending the source proved it.
- `fixed-ball-fractional` changed dependency list and edge: PASS against TeX lines 185–196. The new edge to `fractional-exponent-admissibility` is direct at the external-theorem application and remains conjunctive with the weighted oscillation bound and the Dorronsoro boundary. The consumer locator is exact.
- `scaled-local-data-admissibility`: PASS against TeX lines 201–209 and 235, corroborated by reference lines 700–718. Its source fields preserve the original local `L^2`, local `L^1`, and a.e. nonnegativity premises and state exactly their affine-pullback versions. The edge to `scaled-data` is direct. The `SOURCE_GAP` correctly records that the manuscript silently relies on preservation of local membership and a.e. nonnegativity under the positive affine rescaling.
- `apply-fixed-ball-after-scaling` changed dependency list and edge: PASS against TeX lines 215–241. The new admissibility dependency supplies premises distinct from the already modeled scaled relative inequality; the edge is direct at “Applying Step 1.” It is neither transitive nor redundant.
- `tex-fractional-exponent-admissibility`: PASS against TeX lines 177–196, with the exponent formula separately located by its node at lines 22–28. The disposition maps the omitted application-premise discharge exactly once.
- `tex-scaled-local-data-admissibility`: PASS against TeX lines 201–235. The disposition correctly maps the omitted affine-pullback premise discharge.
- Updated `reference-root-proof`: PASS against reference lines 538–729, specifically 677–699 and 700–718. It now includes both new gap nodes.

No missing premise, altered quantifier or witness scope, wrong edge direction, accidental alternative-as-conjunction, or new external boundary was found in these additions. This is a source-topology verdict only, not theorem proof certification.
