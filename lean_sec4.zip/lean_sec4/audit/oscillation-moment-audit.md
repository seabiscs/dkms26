# Audit: `oscillation_weightedMoment_of_tail_contract`

## Pinned target

- File: `outputs/self-improvement-lean/AffineCarleson/SelfImprovement/OscillationMoment.lean`
- SHA-256: `2eba3f616a907d2cc86b2bb89d634a5b39f8e45690700adacf1f2af10da25d94`
- Declaration: `AffineCarleson.Internal.oscillation_weightedMoment_of_tail_contract`
- Kind: proved internal conditional helper; it is not a frozen source theorem.
- Narrow elaboration: `lake env lean AffineCarleson/SelfImprovement/OscillationMoment.lean` succeeded with no warnings.
- Axiom report: `[propext, Classical.choice, Quot.sound]`; no `sorryAx` or project-defined axiom occurs.

## Exact interface and constant scope

The declaration first quantifies `n K σ s` and their admissibility assumptions, then produces
`C : ℝ` with `0 < C`, and only afterward universally quantifies `E` and `B`. Consequently the
witness `C` can depend on `n, K, σ, s` but cannot depend on `E`, `B`, the tail mass, or the
contraction proof. This matches the required uniformity.

The conclusion is the exact extended-nonnegative weighted estimate

```lean
∫⁻ r in Set.Ioo (0 : ℝ) 1,
    ENNReal.ofReal (r ^ (-(2 * s)) * E r / r)
  ≤ ENNReal.ofReal
      (C * ((∫⁻ r in Set.Ioo (0 : ℝ) 1,
        ENNReal.ofReal (E r / r)).toReal + B)).
```

There is no assumed weighted integrability, weighted moment bound, power decay, or final
fractional estimate. The only finiteness input is the unweighted tail integral on `(0,1)`.

## Binder audit

The bins below are relative to this declaration's stated role as an internal bridge. The final
column records what would happen if it were misidentified as the full manuscript lemma.

| Binder | Internal classification | Mathematical role | Relative to full source lemma |
|---|---|---|---|
| `n : ℕ` | TYPING | ambient dimension | SOURCE |
| `K σ s : ℝ` | SOURCE | recurrence and target exponents | SOURCE |
| `hK : 1 ≤ K` | SOURCE | source parameter range | SOURCE |
| `hs : 0 < s` | SOURCE | target exponent range | SOURCE conclusion specialization |
| `hsmax : s < min s₀ (σ/2)` | SOURCE | exact source exponent restriction | SOURCE conclusion specialization |
| `E : ℝ → ℝ` | TYPING | scalar oscillation tail density | proof-local object in source |
| `B : ℝ` | TYPING | normalized error mass | proof-local object in source |
| `0 ≤ B` | SOURCE | sign required by the scalar recurrence | derived in source application |
| `Measurable E` | TYPING | permits construction of `tailMeasure E` | proof obligation in source application |
| `∀ r ∈ Ioo 0 1, 0 ≤ E r` | SOURCE | literal nonnegative density input | derived from oscillation in source |
| unweighted tail `≠ ⊤` | SOURCE | explicit finite-tail premise of this bridge | EXCESS if asserted in the full source theorem |
| contraction on `Ioc 0 (1/16)` | SOURCE | explicit recurrence premise of this bridge | EXCESS if asserted in the full source theorem |

Internal counts: SOURCE 8, TYPING 4, STANDING 0, RULED 0, EXCESS 0. If presented as the full
source lemma, at least the finite-tail and contraction premises would be EXCESS, so such a
presentation would fail.

## Composition and conversion checks

1. `weightedMoment_of_contract` is invoked before `E` and `B` are introduced. Its existential
   constant is therefore preserved unchanged; the composition does not choose a new
   data-dependent constant.
2. `tailMeasure_Ioc_eq_lintegral_Ioo` rewrites cumulative masses exactly. The `Ioc`/`Ioo`
   difference is only the Lebesgue-null endpoint built into that proved identity.
3. The finite unweighted tail premise is transferred exactly to
   `tailMeasure E (Ioc 0 1) ≠ ⊤`. It is not replaced by finiteness of the desired weighted
   integral.
4. The contraction is transferred by equality rewriting, with the same factor
   `4^n K / (4^n K + log 4)`, scale `16 r`, error `B r^σ`, interval `(0,1/16]`, and
   `ENNReal.toReal` placement.
5. `lintegral_inversePower_tailMeasure E (2*s)` is an equality, not an inequality. It converts
   the measure moment exactly to the displayed density integral. Multiplication order is changed
   only by real-field normalization inside the previously proved identity.
6. The final unweighted tail term is again rewritten by exact equality. No `ENNReal.toReal`
   inequality, truncation, or silent finiteness strengthening occurs in this assembly.

## Scope verdict

**VERDICT: PASS (CONDITIONAL INTERNAL BRIDGE).**

The theorem has a uniform constant with the correct dependency order, composes exact
`ENNReal` identities without weakening, assumes no desired conclusion, and accurately leaves
finite-tail and contraction as explicit internal premises. Its module documentation explicitly
states that deriving those premises from the ball-oscillation hypothesis is separate. It therefore
does not claim the full source self-improvement lemma and supplies no source-closure evidence by
itself.

**FULL SOURCE THEOREM VERDICT: NOT APPLICABLE / NOT PROVED BY THIS DECLARATION.**
