# Section 4 source-to-Lean coverage

Final update, 10 September 2026: the canonical abstract theorem is sealed and independently audited PROVED. The zero-error corollary is also PROVED; see `final-statement-audit.md`. The mapping below records the implementation route. The later PDE application remains unproved.

## Scope

The approved root is exactly the abstract mean-oscillation self-improvement
lemma in `source/self-improvement.tex` lines 5–39, with proof attachment lines
41–244 and ambient assumptions supplied by `source/reference.txt` lines 24–31.
The current provider export is
`AffineCarleson.Internal.meanOscillation_selfImprovement`; the sealed
frozen file exports the unchanged approved declaration
`AffineCarleson.meanOscillation_selfImprovement` with contract
`mean-oscillation-self-improvement`, version `1`, and ABI
`d674c7a7c39e732be5b485fd2f30c7b0b6de0be5b33c17b71616a2a5d9ac0086`.

This closeout maps the complete abstract lemma only. It does not claim that all
of Section 4, or the paper's main theorem, has been formalized.

## Source-to-Lean coverage map

### Statement, definitions, and relative hypothesis (TeX 5–39)

- The approved statement, quantifier order, exponent threshold, local compact
  membership, and quantitative ball estimate are implemented together by
  `AffineCarleson.Internal.meanOscillation_selfImprovement` in `Proof.lean`.
- `ballSet` and `ballOscillation` implement the displayed Euclidean balls,
  normalized coordinate means, and normalized vector variance.
- The constant is chosen before `m, Ω, g, μ, M, x₀, R`; the provider obtains it
  from `AffineCarleson.Internal.ball_selfImprovement`, which in turn preserves
  the unit theorem's dependence only on `n,K,σ,s`.

### Fixed-ball tail setup and initial finiteness (TeX 41–77)

- `measurable_oscillationDensity`, `ofReal_oscillationDensity_eq_lintegral`,
  and `lintegral_oscillationDensity_div_eq` implement the source density
  `E(r)` and tail integral `Φ(t)` in `OscillationDensity.lean`.
- `relative_tail_le_energy` and `relative_tail_lt_top` implement the finite
  cover, minimizing property of the mean, and the finite unit-tail bound in
  `RelativeTail.lean`.
- `relative_unit_tail_finite_and_le` packages precisely the two consequences
  used by the unit assembly, deriving them from the actual relative-ball
  hypothesis in `RelativeDensity.lean`.

### Averaging centers and one-scale inequality (TeX 78–131)

- `lintegral_ballSet_radius_swap`, `integrated_centers_lower`, and
  `integrated_centers_error_upper` implement the Tonelli center average and
  its lower/error bounds in `IntegratedCenters.lean`.
- `relative_scale_le` combines those estimates, ball-volume scaling, and the
  oscillation upper bound in `RelativeScale.lean`.
- `relative_density_scale_le` converts the result to the real scalar tail
  inequality used downstream, with coefficient `4^n K` and error
  `4^n M(∫B₈ μ)t^σ`.

### Integrated recurrence, contraction, and decay (TeX 132–176)

- `tailIntegral_contract` implements the scale integration, logarithmic
  identities, monotonicity, and rearrangement into the contraction in
  `TailIntegration.lean`; `holeFilling_rearrange_source` isolates the source
  algebra in `HoleFilling.lean`.
- `iterationExponent_eq_twice_baseExponent` and the neighboring exponent
  lemmas in `Exponent.lean` prove the exact identity
  `β=log(1/θ)/log 16=2s₀` and the admissible exponent inequalities.
- `discrete_decay`, `continuous_decay_of_geometric`, and
  `tail_decay_of_contract` in `DiscreteDecay.lean`, `ContinuousDecay.lean`,
  and `TailDecay.lean` implement the discrete iteration, geometric sum, and
  passage to all scales.

### Weighted moment and unit fractional bound (TeX 177–196)

- `weightedMoment_of_contract` and
  `oscillation_weightedMoment_of_tail_contract` implement the weighted tail
  moment required at exponent `2s` in `TailMoment.lean` and
  `OscillationMoment.lean`.
- `nearPairs_le_oscillation` and its Tonelli/variance helpers in
  `NearPairs.lean` give the local close-pair estimate.
- `lintegral_inversePower_kernel_le_layerCake` in `KernelTonelli.lean` proves a
  direct local inverse-power layer-cake inequality, including the zero-distance
  diagonal case and without assuming kernel finiteness.
- `unitFractionalEnergy_le_densityMoment` in `UnitFractional.lean` combines the
  close-pair bound with the direct layer-cake inequality.
- `unit_selfImprovement` in `UnitBound.lean` combines the actual relative
  hypothesis, finite tail, contraction, moment, and fractional comparison into
  the normalized quantitative estimate.

The manuscript itself invokes Dorronsoro's external Littlewood–Paley/Besov
characterization at TeX 185–196. The reviewed source graph must continue to
record that cited result as the explicit external leaf
`dorronsoro-local-mean-oscillation`, together with the manuscript's unstated
localization and exponent-admissibility obligations. The Lean provider follows
a different, direct local Tonelli/layer-cake route. That direct route proves the
approved root but does not certify the cited Dorronsoro theorem, and it must not
be retrofitted into the source graph as though the author had written it.

### Representatives, rescaling, and the general ball estimate (TeX 200–243)

- `exists_measurable_l2_representative` and
  `exists_measurable_nonneg_representative` construct usable representatives;
  `relative_inequality_congr_ae` and `lintegral_gagliardo_congr_ae` transfer the
  relevant quantities under local a.e. equality.
- `ballOscillation_affineScale`, `relativeOscillationLIntegral_affineScale`,
  and `relativeOscillation_le_affineScale` prove the exact scaled oscillation
  and relative-hypothesis identities, including invariance of `dr/r` and the
  replacement `M_R=M R^σ`.
- `normalized_relative_ball_subset` and
  `rescaled_relative_ball_subset` discharge the normalized ball containment
  for every `0<t≤1`; the consumer uses `R≤1` to obtain `Rt≤1`.
- `memLp_comp_affineScale_ball` and
  `IntegrableOn.comp_affineScale_ball` supply the scaled local-data
  admissibility omitted by the prose.
- `fractionalEnergy_affineScale`, `setIntegral_affineScale`, and
  `fractionalEnergy_le_of_scaled_unit_bound` prove the omitted final
  change-of-variable calculation, including the `R^(2s-n)` energy factor,
  `R^(-n)` single-integral factors, and the final `R^(-2s)` coefficient.
- `ball_selfImprovement` in `GeneralBallBound.lean` assembles these facts and
  returns to the original a.e. representatives on an arbitrary admissible ball.

### Local compact-set membership (statement 27–38; omitted at proof close)

- `exists_enlarged_ballSet_closure_subset` supplies an admissible local ball
  around each point of the open domain.
- `lintegral_fractionalIntegrand_lt_top_of_compact` in
  `CompactFractional.lean` combines finite diagonal neighborhoods with local
  `L²` control of separated cross terms to prove finite fractional energy on
  every compact subset.
- `meanOscillation_selfImprovement` uses the general-ball bound to obtain the
  required local diagonal estimates and then applies this compactness theorem.

This closes a genuine gap in the manuscript's prose while preserving the
approved statement: the source ends after rescaling the ball estimate and does
not spell out control of cross-ball pairs on a general compact set.

## Items that remain outside the approved root

1. **The stronger `M=0` corollary (TeX 197–198): now PROVED.**
   `AffineCarleson.meanOscillation_selfImprovement_zeroError` in
   `AffineCarleson/SelfImprovement/ZeroError.lean` permits every `0<s<s₀`
   with `c(n,K,s)`. It applies the sealed public root with `σ=4s`, `μ=0`,
   and `M=0`. The final independent audit checks the complete source
   statement, constant scope, application, and standard-axiom closure.

2. **The application to the paper's main PDE theorem (TeX 246–267).** This
   requires the earlier Proposition `prop:relative`, the facts labeled
   `eq:Vconsequences`, Gehring higher integrability `eq:gehring`, definitions of
   `V(Du)`, `q`, `s_*`, and the conversion from fractional control of `V(Du)`
   to `W^{2s/p,p}` control of `Du`. None belongs to the approved frozen anchor.

3. **Earlier paper prerequisites and the remainder of `reference.txt`.** The
   source graph correctly excludes Sections 1–3, their PDE setup and results,
   the post-lemma main-theorem application, and unrelated bibliography. The
   Dorronsoro bibliography entry remains relevant only as provenance for the
   source graph's external leaf; it has not been independently formalized or
   certified here.

The verified scope is therefore: **the approved abstract self-improvement
lemma and its zero-error corollary are formalized**. It is not: **Section 4 and Theorem
`maint` are fully formalized**.

## Completed graph binding refresh

The source graph is a reviewed source-level database. Sealing changed no source statement, edge, coverage disposition, source identity, frozen ABI, or contract version. Its topology, source-gap notes, external citation, and initial Lean planning statuses were therefore preserved.

The graph header now binds the final authoritative manifest at SHA-256 `1ee8d5d5a3324f7720076b4233b653a6219ed5ba04f29cafbc764423f4a65596`. The frozen ABI remains `d674c7a7c39e732be5b485fd2f30c7b0b6de0be5b33c17b71616a2a5d9ac0086`. Dashboard regeneration and both strict publication checks passed; exact commands and outputs are recorded in `audit/depgraph-publication-validation.log`.

The source-only graph does not certify Lean implementation status. The final independent statement audit certifies the canonical frozen root and its ordinary zero-error corollary; `proof-status.json` records implementation status. The Dorronsoro external leaf and the five source-gap notes describe the manuscript's proof route and are retained even where the implementation proves the target through additional lemmas or a direct alternative.
