# Independent audit of self-improvement helper modules

## Verdict

`HELPER_PROOF_SOUNDNESS: PASS` at the audited file hashes below.

`SOURCE_STEP_CORRESPONDENCE: PASS (conditional/internal)`.

`FULL_SOURCE_THEOREM_COVERAGE: INCOMPLETE`.

`AXIOM_CLOSURE: PASS` under the standard Mathlib foundations `propext`, `Classical.choice`, and `Quot.sound`.

The seventeen declarations in the six requested modules compile without `sorry`, `axiom`, `admit`, unsafe declarations, or heartbeat overrides. Their statements are valid internal lemmas matching identifiable steps of the source proof. None asserts the full abstract Lemma 4.1, local Sobolev regularity, or Theorem 1.1. No hidden source premise is being passed off as part of the source-facing theorem.

The modules do not yet form a proof of Lemma 4.1. The geometric/measure-theoretic bridges from the source hypothesis to the scalar recurrence, from `Phi` to its Stieltjes measure, and from local mean oscillation to the Gagliardo integral remain outside this audited set.

## Frozen audit inputs

| Module | SHA-256 |
|---|---|
| `Exponent.lean` | `b1f16ce38cb30a51316188f87e84942396c0994fbc94a1d7541dffff79e0de04` |
| `DiscreteDecay.lean` | `929a38648d635a7100b31a06d7717b042f2de8527867442d7dd9fc9d145b4677` |
| `ContinuousDecay.lean` | `d681b893a4bb193fb6feb568df31756ea00428dee412c92453e830bddcf67a28` |
| `TailDecay.lean` | `81b91945fb4bfdd81f0fd67d3003d1140c20e632ceaa8fdd6a74cd1ddafe3932` |
| `WeightedMoment.lean` | `9fd9b5bf0d9f19ba77dba2f59ad0564500b564c3ca1598c1c3ffeeb580aa964a` |
| `FractionalComparison.lean` | `5601f59764cd86791ea5a0122014b73f610acc9b5fa8f3a6d42fbb9755f72b16` |

Source: `source/self-improvement.tex` SHA-256 `7f218e9763a8e92c344ec7e1f6a7d1d6b0ea5ca81fae924d7d237903c92a3644`, especially lines 132–198 and 261–265.

Audit method: theorem-type inventory, line-level proof inspection, correspondence against the source proof, adversarial premise review, marker scan, independent import compilation, and `#print axioms` for every declaration. Proof files were not edited. The temporary axiom probe was deleted after use.

## Declaration inventory and source correspondence

### `Exponent.lean`

| Declaration | Role and source correspondence | Premise assessment | Verdict |
|---|---|---|---|
| `iterationRatio_pos` | Proves `0<theta` for `theta=c_*/(c_*+log 4)`, source (4.7). | `K>=1` is a source premise; no excess. | PASS |
| `iterationRatio_lt_one` | Proves `theta<1`, explicitly asserted in (4.7). | `K>=1`; no excess. | PASS |
| `baseExponent_pos` | Shows the displayed `s0` is positive. | `K>=1`; no excess. | PASS |
| `baseExponent_lt_one` | Auxiliary bound `s0<1`, useful for fractional-order side conditions but not stated in the source proof. | Derived solely from `K>=1`; internal strengthening, no excess. | PASS |
| `iterationExponent_eq_twice_baseExponent` | Exact identity `log(1/theta)/log 16 = 2s0`, source line 161. | `K>=1`; no excess. | PASS |
| `iterationRatio_eq_rpow_neg_iterationExponent` | Rewrites `theta` as `16^(-beta)` for the geometric comparison. | `K>=1`; derived algebraically. | PASS |
| `iterationRatio_lt_rpow_neg` | From `gamma<2s0`, derives `theta<16^(-gamma)`. | Its `gamma` bound is exactly the selected source exponent bound. | PASS |
| `rpow_neg_pos_lt_one` | Shows `0<16^(-gamma)<1` when `gamma>0`. | Exact elementary side condition. | PASS |
| `rpow_neg_lt_rpow_neg` | From `gamma<sigma`, derives `16^(-sigma)<16^(-gamma)`. | Exact error-series comparison. | PASS |
| `exists_exponent_between` | Produces `2s<gamma<min(2s0,sigma)`, source lines 177–178. | Exact two source inequalities; no excess. | PASS |

The algebra uses the same `4^n K`, `log 4`, and `log 16` as the manuscript. There is no factor-of-two drift: the iteration exponent is exactly `2*s0`.

### `DiscreteDecay.lean`

`discrete_decay` is a generic recurrence lemma. Under

`u(k+1) <= theta u(k) + B b^(k+1)`, `0<=theta<a<1`, `0<=b<=a`, and `u(0),B>=0`,

it proves

`u(k) <= a^k (u(0) + B b/(a-theta))`.

This is a correct closed form for the geometric-series step on source lines 162–169. Its hypotheses are internal facts that must be produced at application: positivity of `Phi(1)` and the error coefficient, and comparisons supplied by `Exponent.lean`. They are not source-theorem premises. The induction is noncircular and preserves all error terms.

Verdict: `PASS, CONDITIONAL INTERNAL HELPER`.

### `ContinuousDecay.lean`

`continuous_decay_of_geometric` converts decay on `16^(-k)` to every `r in (0,1]` using monotonicity, losing exactly one factor `16^gamma`. This matches source lines 168–175. The theorem correctly selects adjacent geometric scales and uses

`16^(-k) <= 16 r`.

Its `MonotoneOn Phi (0,1]` premise must later be proved from the source definition of `Phi`; it is not a new premise of Lemma 4.1.

Verdict: `PASS, CONDITIONAL INTERNAL HELPER`.

### `TailDecay.lean`

`tail_decay_of_contract` assembles the preceding helpers for the source-shaped recurrence

`Phi(r) <= theta Phi(16r) + B r^sigma`, `0<r<=1/16`,

and proves explicit `r^gamma` decay for every `0<r<=1`. This corresponds to source (4.7) through line 175. The constant

`16^gamma [Phi(1) + B 16^(-sigma)/(16^(-gamma)-theta)]`

is finite and nonnegative because the proved inequalities give `theta<16^(-gamma)`.

The explicit `_hSigma : 0<sigma` is unused syntactically, but it is a source premise and is redundant only because `0<gamma<sigma` already follows from `hgamma` and `hgammaMax`. It is not an `EXCESS` premise. `hPhiOne`, monotonicity, and the recurrence are exactly proof obligations generated by the source definitions and earlier estimates.

Verdict: `PASS, CONDITIONAL INTERNAL ASSEMBLY`.

### `WeightedMoment.lean`

| Declaration | Role | Verdict |
|---|---|---|
| `inversePower_superlevel_subset` | For `t>=1`, identifies the inverse-power superlevel set inside `(0,1]` as lying below `t^(-1/q)`. | PASS |
| `inversePower_superlevel_measure_le` | Converts a distribution bound `nu((0,r]) <= A r^gamma` into the tail estimate `<= A t^(-gamma/q)`. | PASS |
| `inversePower_weightedMoment_le` | Layer cake yields `integral_(0,1] r^(-q) dnu <= A gamma/(gamma-q)` for `0<q<gamma`. | PASS |

The last theorem matches the source integration-by-parts consequence with `q=2s` once `nu((0,r])=Phi(r)` is constructed. Its constant is correct:

`A + A*q/(gamma-q) = A*gamma/(gamma-q)`.

No positivity premise for `gamma` is missing: it follows from `0<q<gamma`. The general measure `nu` is a legitimate abstraction, but a future consumer must construct the appropriate Lebesgue–Stieltjes measure and prove its interval distribution identity. Merely instantiating `nu` with an unrelated measure would not prove the source step.

Verdict: `PASS, CONDITIONAL INTERNAL HELPER`.

### `FractionalComparison.lean`

`fractionalEnergy_le_of_pointwise` lifts

`|u(x)-u(y)|^p <= C |v(x)-v(y)|^2`

to the exact two Gagliardo kernels, using

`n + (2s/p)*p = n+2s` when `p>0`.

This corresponds to the final source application at lines 261–265, with `u=Du`, `v=V(Du)`, and the first inequality in (2.3). Its pointwise premise is visibly explicit and the module documentation correctly says that it must be supplied by a proved `V` inequality; it is not an assumption to add to Theorem 1.1.

The proof remains valid when the distance denominator is zero: Lean real division by zero is zero on both sides, and away from the diagonal it is ordinary division by a nonnegative kernel. Pulling the finite constant through both `lintegral`s is valid because `ENNReal.ofReal C` is finite.

This module does **not** prove the local mean-oscillation-to-Gagliardo comparison used inside Lemma 4.1. Its similar name should not be read as covering that earlier bridge.

Verdict: `PASS, CONDITIONAL FINAL-APPLICATION HELPER`.

## Hidden-premise and proof-soundness review

No project-owned structures or Prop aliases occur in these theorem statements. Each logical input is exposed directly. The conditional premises fall into two legitimate groups:

- generic lemma hypotheses proved from earlier scalar facts at the point of use (`Phi` monotonicity, recurrence, nonnegative mass, decay bounds);
- the final pointwise `V` estimate, which belongs to an earlier independently proved source result and is explicitly documented as such.

None can be retained as an extra binder in the eventual exact source-facing theorem. The source theorem's proof must produce and apply them internally.

Proof inspection found no reversed inequality, lost coefficient, illegal endpoint, division without a nonzero denominator, or circular recurrence. All divisions have positivity/nonzero proofs. The `Ioc (0,1]` choices match the source's improper integral and do not introduce an atom at zero. The split of layer-cake parameter space into `(0,1]` and `(1,infinity)` covers `(0,infinity)` exactly.

## Coverage and open proof obligations

These helpers cover:

1. exponent and contraction arithmetic;
2. discrete recurrence iteration;
3. interpolation from geometric radii to all radii;
4. assembly of scalar tail decay;
5. a general weighted inverse-power moment estimate;
6. the downstream `Du` versus `V(Du)` fractional-energy comparison.

They do not cover:

1. defining `E(r)` and `Phi(t)` from the source oscillation and proving measurability/finiteness;
2. the finite covering argument establishing source (4.4);
3. Tonelli over centers and ball-intersection geometry establishing (4.5);
4. integration of (4.5) and rearrangement into the recurrence (4.7);
5. construction of the measure `nu` with `nu((0,r])=Phi(r)`, or an equivalent direct weighted integral argument;
6. the local mean-oscillation-to-explicit-Gagliardo bridge identified in the source audit;
7. final rescaling and exact assembly of the source-facing theorem;
8. the `M=0` stronger corollary;
9. Proposition 3.1, Gehring, the `V` inequalities, and the final Theorem 1.1 application.

Accordingly, these declarations are proved ingredients, not evidence that Lemma 4.1 or the manuscript section is proved.

## Concrete findings ledger

| ID | Severity/status | Finding | Required disposition |
|---|---|---|---|
| H1 | Coverage gap, survived | No helper in the audited set derives the source recurrence from the ball-oscillation hypothesis. | Keep the source theorem unproved until the covering/Tonelli/hole-filling bridge is implemented. |
| H2 | Coverage gap, survived | `WeightedMoment` assumes a measure distribution bound but does not construct the Stieltjes measure of `Phi`. | Prove the construction/identity or use a direct weighted-integral argument. |
| H3 | Coverage gap, survived | `FractionalComparison` concerns the downstream `Du`/`V(Du)` step, not the mean-oscillation/Gagliardo bridge needed by Lemma 4.1. | Implement the direct variance/center-intersection/layer-cake bridge or an audited equivalent. |
| H4 | Naming risk, informational | The name `FractionalComparison` could be mistaken for coverage of H3, although its module docstring accurately limits its role. | Preserve the documented dependency distinction in the graph and review package. |

There are no correctness findings against the implemented theorem statements or proofs.

## Build and axiom evidence

A transient file imported `TailDecay`, `WeightedMoment`, and `FractionalComparison` and ran `#print axioms` on all seventeen declarations. It compiled successfully. Every declaration reported exactly:

`[propext, Classical.choice, Quot.sound]`.

The marker scan found no `sorry`, `admit`, `axiom`, `opaque`, `unsafe`, or `set_option maxHeartbeats` in the six audited modules. The transient probe was deleted after recording the output.

## Closeout

- Declaration inventory complete: yes, 17/17.
- Exact source-step correspondence checked: yes.
- Hidden premise review complete: yes.
- Proof bodies inspected: yes.
- Narrow compilation and axiom census complete: yes.
- Open coverage gaps distinguished from correctness findings: yes.
- Full source theorem proved: no, and not claimed.
