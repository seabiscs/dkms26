# Focused source audit: Section 4 self-improvement

## Verdict and scope

The abstract Lemma 4.1 is mathematically coherent as stated. Its hole-filling iteration and final scaling have been checked. The only non-elementary step in the manuscript proof is the cited local mean-oscillation characterization of `W^{s,2}`; it can be replaced by a direct Tonelli argument controlling the explicit Gagliardo double integral. This replacement is recorded below and avoids making the Dorronsoro citation an axiom or a theorem premise.

The final application to Theorem 1.1 is not self-contained in this section. It is conditional on the earlier relative Carleson estimate (Proposition 3.1), higher integrability/Gehring estimate (1.4), and the two `V` inequalities (2.3). A Lean file proving only the abstract lemma must not claim the final theorem or treat those earlier results as assumptions of the abstract lemma.

Audit tier: focused tier 2, source reconstruction and adversarial proof check. Permission envelope: read frozen source and reference; write only this report; no Lean/code edits, graph construction, commits, network, or destructive operations.

## Frozen inputs

- `outputs/self-improvement-lean/source/self-improvement.tex`, frozen-v1 SHA-256 `7f218e9763a8e92c344ec7e1f6a7d1d6b0ea5ca81fae924d7d237903c92a3644`.
- `outputs/self-improvement-lean/source/reference.txt`, manifest SHA-256 `ca07c7ca2f799428e70b9d84a9abfa2923c811d7b5df8c8b1c46bd5c7ce394c9`; relevant source pages 9–12, with conventions and Theorem 1.1 on pages 1–4.
- `work/self-improvement/source-manifest.json`, which explicitly says that no earlier Carleson theorem is assumed proved.

The TeX hash was independently recomputed with `sha256sum` and matched the manifest. This report does not approve a Lean declaration; no exact Lean target had yet been supplied.

## Exact mathematical contract reconstructed from the source

Ambient conventions: `n` is the Euclidean domain dimension, `m` is an arbitrary finite target dimension, `Omega` is open in `R^n`, balls are open Euclidean balls, `(g)_{x,r}` is the normalized ball average, and

`H_g(x,r) = (1 / |B(x,r)|) integral_{B(x,r)} |g(y) - (g)_{x,r}|^2 dy`.

The explicit fractional seminorm convention from source page 4 is

`[g]_{W^{s,2}(U)}^2 = integral_U integral_U |g(x)-g(y)|^2 / |x-y|^(n+2s) dy dx`.

The quantifier/constant order required by the sentence “where `c=c(n,K,sigma,s)`” is:

1. choose `n`, `K >= 1`, `sigma > 0`, and `s` with `0 < s < min(s0,sigma/2)`;
2. choose one finite `c = c(n,K,sigma,s)`;
3. only then universally quantify `m`, `Omega`, `g`, `mu`, `M`, and the conclusion ball data `x0,R`.

Thus `c` must be uniform in `m`, `Omega`, `g`, `mu`, `M`, `x0`, and `R`. In particular, putting `M` before `c` would weaken the source statement. `M` is fixed for the global hypothesis but is not a dependency of `c`.

Source premises:

- `g in L^2_loc(Omega; R^m)`;
- `mu in L^1_loc(Omega)`, with `mu >= 0` almost everywhere;
- fixed `K >= 1`, `M >= 0`, `sigma > 0`;
- for every `x0,R` such that `B(x0,4R) compactly contained in Omega` and `0<R<=1`, equation (4.1) holds exactly with normalized `H_g`, ordinary (unnormalized) outer integrals, and the factor `K |B_{4R}|`.

Define

`s0 = log(1 + log(4)/(4^n K)) / (2 log(16))`.

Conclusions:

- for every `0<s<min(s0,sigma/2)`, `g in W^{s,2}_loc(Omega;R^m)`;
- for every `B(x0,8R) compactly contained in Omega`, `0<R<=1`, the explicit Gagliardo seminorm on `B(x0,R)` is at most

  `c R^(-2s) [ integral_{B(x0,8R)} |g|^2 + M R^sigma integral_{B(x0,8R)} mu ]`.

The source proof additionally states a stronger `M=0` result: every `0<s<s0` is allowed and the constant is `c(n,K,s)`, independent of `sigma`. This is not part of the displayed lemma statement. It should be a separate theorem/corollary if formalized, rather than silently strengthening or changing the main target.

## Proof audit

### Hole filling and exponent

The fixed-ball definitions and covering bound are sound. Integrating (4.1) over centers produces

`Phi(t) <= 4^n K E(4t) + 4^n B t^sigma`.

Integrating for `r<t<4r` gives

`(log 4) Phi(r) <= c_* (Phi(16r)-Phi(r)) + C B r^sigma`, with `c_*=4^n K`.

Rearrangement yields `Phi(r) <= theta Phi(16r)+C B r^sigma`, where

`theta=c_*/(c_*+log 4)` and `log(1/theta)/log 16 = 2s0`.

The discrete iteration and interpolation by monotonicity correctly give `Phi(r) <= C A r^gamma` for every `gamma<min(2s0,sigma)`. The Stieltjes integration-by-parts identity then gives `integral_0^1 r^(-2s) dPhi(r) < infinity` when `2s<gamma`.

### Direct local mean-oscillation to Gagliardo bridge

This proves the manuscript's cited step without an external Besov theorem. Let

`D(r) = integral_{u in B1} integral_{v in B1, |u-v|<=r} |g(u)-g(v)|^2 dv du`.

The variance identity on a ball is

`H_g(c,r) = [1/(2|B_r|^2)] integral_{B(c,r)} integral_{B(c,r)} |g(u)-g(v)|^2 du dv`.

For `u,v in B1` with `|u-v|<=r`, the set of centers `c` for which both points lie in `B(c,r)` is `B(u,r) intersect B(v,r)`. It has measure at least `a_n r^n` (for example it contains the ball of radius `r/2` about `(u+v)/2`), and every such center belongs to `B_{1+r}`. Tonelli therefore gives

`E(r) = integral_{B_{1+r}} H_g(c,r) dc >= a'_n r^(-n) D(r)`,

so `D(r) <= C_n r^n E(r)`.

For `0<|u-v|<=1`, layer cake gives

`|u-v|^(-n-2s) <= C(n,s) integral_{|u-v|}^1 r^(-n-2s) dr/r + C(n,s)`.

After Tonelli and the estimate for `D(r)`,

`integral_{B1} integral_{B1, |u-v|<=1} |g(u)-g(v)|^2 / |u-v|^(n+2s)`

`<= C(n,s) integral_0^1 r^(-2s) E(r) dr/r + C(n,s) ||g||^2_{L2(B1)}`.

Pairs with `|u-v|>1` contribute at most `C ||g||^2_{L2(B1)}`. Since `dPhi(r)=E(r)dr/r`, this is exactly the required bridge. It uses only Tonelli, ball geometry, the variance identity, and elementary kernel integration.

### Scaling

For `g_R(y)=g(x0+Ry)` and `mu_R(y)=mu(x0+Ry)`, the hypothesis scales with `M_R=M R^sigma`, while `K` and `sigma` remain fixed. The seminorm scaling is

`[g_R]^2_{W^{s,2}(B1)} = R^(2s-n) [g]^2_{W^{s,2}(B(x0,R))}`.

Also `integral_{B8}|g_R|^2=R^(-n) integral_{B(x0,8R)}|g|^2`, and similarly for `mu`. Multiplication by `R^(n-2s)` yields precisely (4.3). No scale-dependent constant is introduced.

## Final application and distinct dependencies

The page-12 application requires the following results external to Lemma 4.1:

1. Proposition 3.1 / (3.2): the relative Carleson estimate, supplying (4.1) for `g=V(Du)` and `mu=1+|Du|^q`, with `K=K(data)`, `sigma=min(alpha,q-p)`, and an error coefficient depending on `(data,L0,alpha,q)`.
2. Higher integrability (1.4): `Du in L^q_loc`, needed for local integrability of `mu`.
3. The second inequality in (2.3): `|V(z)|^2 <= C(1+|z|^p)`, needed for `V(Du) in L^2_loc` and to replace the abstract `L^2` term.
4. The first inequality in (2.3): `|z-z0|^p <= C|V(z)-V(z0)|^2`, applied pointwise to convert the `V(Du)` Gagliardo seminorm to the `Du` seminorm.
5. Elementary absorption of `R^sigma integral 1` into `integral (1+|Du|^p)` for `R<=1`.

Until these are separately proved and audited, the final theorem is `CONDITIONAL/UNVERIFIED-INPUT`, even if the abstract lemma is fully proved. Source citations and the manuscript's later remark that the section has been Lean-formalized do not establish any Lean proof.

## Findings ledger and adversarial checks

| ID | Anchor at frozen-v1 | Initial concern | Refutation attempt | Status |
|---|---|---|---|---|
| F1 | TeX lines 185–196, “standard Littlewood--Paley characterization” | External bridge might be an unformalized gap. | Constructed the direct center-intersection/Tonelli proof above. | Concern refuted mathematically; Lean still needs this bridge proved. |
| F2 | TeX lines 201–243, “Final rescaling” | Possible missing powers of `R`. | Recomputed hypothesis and Gagliardo scaling explicitly. | Refuted; scaling is exact. |
| F3 | TeX lines 197–198, “When M=0...” | Stronger exponent/constant may be mixed into the formal target. | Checked that the error term disappears before the `sigma`-dependent geometric sum. | Valid stronger corollary, but distinct from displayed Lemma 4.1. |
| F4 | TeX lines 246–267, “Apply Lemma ... to Proposition...” | Final result could be claimed from the abstract lemma alone. | Expanded every point-of-use input above. | Survived: final application is conditional on four substantive earlier results plus absorption. |
| F5 | TeX lines 37–38, “c=c(n,K,sigma,s)” | Constant could accidentally depend on later data. | Traced all fixed-ball, bridge, and scaling constants. | Source requires `c` before `m,Omega,g,mu,M,R,x0`; no contrary dependence found. |

No counterexample or mathematical error was found in the abstract lemma. The direct bridge is proof support, not authorization to alter the source-facing statement.

## Lean target review checklist for the forthcoming exact command

An exact declaration should fail source fidelity if any of the following occurs:

- `c` is quantified after `m`, `Omega`, `g`, `mu`, `M`, `R`, or `x0`;
- `M`, `R`, `x0`, or the ball is fixed only for the hypothesis rather than universally quantified there;
- normalized and unnormalized integrals are interchanged;
- `H_g` is replaced by a generic supplied function or its variance identity is assumed;
- the conclusion uses an abstract `W` predicate without also matching the source's explicit Gagliardo seminorm estimate;
- `mu>=0`, local integrability, open-domain/compact-containment, or `0<R<=1` is dropped;
- the final application imports Proposition 3.1, Gehring, or a `V` bridge as a new theorem premise rather than applying a separately proved result;
- the `M=0` strengthening is used to alter the general displayed lemma.

Five-bin binder classification and declaration fidelity remain pending until the exact Lean command is received. No source dependency graph should be anchored before that declaration is approved.

## Closeout

- Frozen inputs recorded and hashes matched: yes.
- Exact source contract reconstructed: yes.
- Constant uniformity and quantifier order recorded: yes.
- Hole filling, exponent, and rescaling checked: yes.
- External Besov step independently replaced by a direct proof: yes.
- Final application dependencies separated: yes.
- Exact Lean declaration audited: pending, because it was not yet supplied.
- Formal proof/axiom closure: not audited and not claimed.
