# Global source-only root-closure review: Lemma 4.1

Reviewer: `section4_graph_global_review`  
Date: 2026-09-10  
Verdict: **FAIL — two conditional-premise discharge obligations are absent from the graph**

## Review boundary

I read the complete raw sources `source/self-improvement.tex` and `source/reference.txt`, the declaration header of `Frozen/SelfImprovement.lean` only through the theorem statement, the identity fields in `frozen-manifest.json`, and `DEPGRAPH.md` / `DEPGRAPH_COVERAGE.md`. I did not inspect the frozen proof body as evidence, implementation Lean modules, proof-status or axiom material, extractor rationale, or previous review reports. This is a source-topology review and makes no claim about Lean proof status.

The canonical root locator is TeX lines 5–39, with the ambient provenance at reference lines 24–31. The proof closure is TeX lines 41–244, corroborated by reference lines 538–729. The post-lemma application at TeX lines 246–267 / reference lines 731–760 and the `M=0` strengthening at TeX lines 197–198 are correctly outside the approved root.

## Root identity and statement verdict

`selfimprovement`: **PASS for identity and all four source-statement fields; FAIL for effective topology closure.**

The graph, manifest, and frozen declaration header agree on:

- manifest anchor `self-improvement-v1`;
- file `Frozen/SelfImprovement.lean`;
- export `AffineCarleson.meanOscillation_selfImprovement`;
- contract `mean-oscillation-self-improvement@1`;
- ABI SHA-256 `d674c7a7c39e732be5b485fd2f30c7b0b6de0be5b33c17b71616a2a5d9ac0086`.

The root accurately records the source hypotheses, outer-to-inner placement of the constant before the output dimension and data, the two conclusion conjuncts, the Euclidean/normalized mean-oscillation carrier, the fractional kernel exponent `n+2s`, and the dependencies of `s₀` and `c`. The source's pointwise notation `μ≥0` is represented by the frozen measurable-function normalization as almost-everywhere nonnegativity; this carrier normalization is visible rather than hidden. The root is the only frozen node, and all non-roots have `FROZEN_*: -`.

All 19 nodes are reachable from the root. There are no route nodes and the proof supplies no alternative derivations that should be modeled as OR routes. The sole external boundary is the cited Dorronsoro Littlewood–Paley/Besov characterization. No standing assumption leaf is required.

## Findings requiring correction

### G1. Missing discharge of the external theorem's exponent range

Node `dorronsoro-local-mean-oscillation` records the invocation hypothesis `0<s<1`, reflecting the paper's fractional-Sobolev convention. Node `fixed-ball-fractional` applies that conditional external result but depends only on `weighted-oscillation-moment` and the external node. Its local hypothesis `0<s<min{s₀,σ/2}` does imply `s<1` from the displayed formula for `s₀`, `n≥2`, and `K≥1`, but neither the source nor the graph exposes that discharge. Under the substantive-step threshold, this is an independently failing real/log/power obligation and must be represented. It must remain a `SOURCE_GAP`; this review does not invent its proof.

Required new node fragment:

```text
NODE: fractional-exponent-admissibility
KIND: step
TITLE: Admissibility of the fractional exponent for the external characterization
STATEMENT_SOURCE: source/self-improvement.tex#eq:exponent@L22-L28
PROOF_SOURCE: source/self-improvement.tex#fixed-ball-fractional@L177-L196
CONTRACT_ID: selfimprovement.fractional-exponent-admissibility
CONTRACT_VERSION: 1
SOURCE_HYPOTHESES: n≥2; K≥1; s₀=log(1+log 4/(4^n K))/(2 log 16); 0<s<min{s₀,σ/2}
SOURCE_QUANTIFIERS: ∀ admissible n,K,σ,s
SOURCE_CONCLUSION: 0<s<1
CONSTANT_SCOPE: no new constants
FROZEN_FILE: -
FROZEN_DECL: -
FROZEN_ANCHOR_ID: -
FROZEN_ABI_SHA256: -
DEPS: -
ROUTES: -
ROUTE_FOR: -
TOPOLOGY_STATUS: PROPOSED
EXTRACTOR: section4_graph
REVIEWER: -
LEAN_STATUS: NOT_STARTED
LEAN_REF: -
LEAN_NOTE: -
NOTE: SOURCE_GAP: the source invokes the standard characterization without checking from (4.2), n≥2, and K≥1 that the selected s lies in its stated 0<s<1 range.
```

Required amendment to `fixed-ball-fractional`:

```text
DEPS: weighted-oscillation-moment, fractional-exponent-admissibility, dorronsoro-local-mean-oscillation
EDGE: fractional-exponent-admissibility | source/self-improvement.tex#fixed-ball-fractional@L185-L196 | discharges the 0<s<1 range required by the invoked fractional characterization
```

### G2. Rescaling does not discharge all premises needed to reapply Step 1

Node `apply-fixed-ball-after-scaling` invokes the conditional fixed-ball result. The existing `scaled-relative-hypothesis` establishes the transformed relative estimate and coefficient, while `scaled-data` establishes definitions and `B₈ compactly contained in Ω_R`. Neither node concludes that `g_R∈L²_loc(Ω_R;R^m)`, `μ_R∈L¹_loc(Ω_R)`, and `μ_R≥0` almost everywhere. These are direct premises of Step 1. They follow by affine pullback, but TeX lines 201–235 do not state the argument. Because this is a carrier and integrability transfer under scaling, it is a substantive omitted bridge and must remain a `SOURCE_GAP` node.

Required new node fragment:

```text
NODE: scaled-local-data-admissibility
KIND: step
TITLE: Local integrability and nonnegativity survive rescaling
STATEMENT_SOURCE: source/self-improvement.tex#scaled-data@L201-L209
PROOF_SOURCE: source/self-improvement.tex#apply-fixed-ball@L210-L235
CONTRACT_ID: selfimprovement.scaled-local-data-admissibility
CONTRACT_VERSION: 1
SOURCE_HYPOTHESES: g∈L²_loc(Ω;R^m); μ∈L¹_loc(Ω); μ≥0; Ω_R,g_R,μ_R are defined by the displayed affine rescaling; R>0
SOURCE_QUANTIFIERS: ∀ admissible x₀,R and rescaled compact subsets
SOURCE_CONCLUSION: g_R∈L²_loc(Ω_R;R^m), μ_R∈L¹_loc(Ω_R), and μ_R≥0 almost everywhere on Ω_R
CONSTANT_SCOPE: no new constants
FROZEN_FILE: -
FROZEN_DECL: -
FROZEN_ANCHOR_ID: -
FROZEN_ABI_SHA256: -
DEPS: scaled-data
ROUTES: -
ROUTE_FOR: -
EDGE: scaled-data | source/self-improvement.tex#apply-fixed-ball@L201-L235 | uses the affine definitions of Ω_R, g_R, and μ_R to transfer the local data hypotheses
TOPOLOGY_STATUS: PROPOSED
EXTRACTOR: section4_graph
REVIEWER: -
LEAN_STATUS: NOT_STARTED
LEAN_REF: -
LEAN_NOTE: -
NOTE: SOURCE_GAP: the source reapplies Step 1 without stating the affine-pullback argument preserving local L²/L¹ membership and nonnegativity.
```

Required amendment to `apply-fixed-ball-after-scaling`:

```text
DEPS: scaled-relative-hypothesis, scaled-local-data-admissibility, fixed-ball-fractional
EDGE: scaled-local-data-admissibility | source/self-improvement.tex#apply-fixed-ball@L235-L241 | discharges the rescaled local L²/L¹ and nonnegativity premises of Step 1
```

## Existing-node and edge verdicts

The following existing nodes and all their recorded EDGE use sites pass against the source: `oscillation-tail-definitions`, `tailfinite`, `averaged-lower-bound`, `averaged-upper-bounds`, `tailinequality`, `tailintegration`, `contract`, `discrete-tail-decay`, `continuous-tail-decay`, `weighted-oscillation-moment`, `scaled-data`, `scaled-oscillation-identity`, `scaled-relative-hypothesis`, `final-rescaling-estimate`, and `local-compact-membership`.

`dorronsoro-local-mean-oscillation`: **PASS as an external boundary**, with its existing unresolved exact-hypothesis/normalization question correctly retained as `SOURCE_GAP`.

`fixed-ball-fractional`: **FAIL only for G1**. Its two existing edges correctly point to the consumer at TeX lines 185–196.

`apply-fixed-ball-after-scaling`: **FAIL only for G2**. Its existing edges correctly locate the transformed relative estimate and the invocation of Step 1.

The three currently recorded source gaps are faithful and must remain: the exact localized Dorronsoro input, the unexpanded final scaling identities (including the `R^{n-2s}` cancellation), and passage from ball estimates to arbitrary compact-set local fractional energy (including cross-ball pairs). No proof for any of these is supplied here.

## Coverage verdicts

All current inventory dispositions are accurate except that the two omitted bridges have no inventory item. Add:

```text
ITEM: tex-fractional-exponent-admissibility
KIND: proof-region
SOURCE: source/self-improvement.tex#fixed-ball-fractional@L177-L196
DISPOSITION: NODE fractional-exponent-admissibility
REASON: omitted discharge of the 0<s<1 premise for the cited fractional characterization
COVERAGE_STATUS: PROPOSED
EXTRACTOR: section4_graph
REVIEWER: -

ITEM: tex-scaled-local-data-admissibility
KIND: proof-region
SOURCE: source/self-improvement.tex#apply-fixed-ball@L201-L235
DISPOSITION: NODE scaled-local-data-admissibility
REASON: omitted affine-pullback transfer of local integrability and nonnegativity before Step 1 is reapplied
COVERAGE_STATUS: PROPOSED
EXTRACTOR: section4_graph
REVIEWER: -
```

After these additions the expected dashboard is 21 nodes, 28 edges, 36 coverage items, five explicit source gaps, one external boundary, no routes, and no nodes outside root closure. The existing linter currently reaches only the expected publication-gate failure for missing `GLOBAL_REVIEWER` and `GLOBAL_REVIEW_REF`; those fields must not be filled until G1 and G2 are merged and independently adjudicated.

## Final unresolved questions

1. What exact localized Dorronsoro theorem, extension mechanism, and normalization justify the inequality invoked at TeX lines 185–196?
2. The source omits the proof that its exponent range lies inside `0<s<1`; retain G1 as a source gap unless an authoritative source passage is added.
3. The source omits preservation of local integrability and nonnegativity under its affine rescaling; retain G2 as a source gap unless an authoritative source passage is added.
4. The final quantitative rescaling identities and the compact-set localization argument remain source gaps already represented by the graph.

## Corrected-closure re-review

Re-review date: 2026-09-10  
Final source-topology verdict: **PASS**

I re-traced the effective 21-node, 28-edge closure from `selfimprovement` against TeX lines 5–244 and the corroborating reference text, including every conditional application and every EDGE consumer locator. The two required repairs are present and correct:

- `fractional-exponent-admissibility` exposes, without inventing a proof, the omitted discharge of `0<s<1`; `fixed-ball-fractional` now depends on it at the Dorronsoro use site.
- `scaled-local-data-admissibility` exposes, without inventing a proof, the omitted affine-pullback transfer of local L²/L¹ membership and nonnegativity; `apply-fixed-ball-after-scaling` now depends on it at the Step 1 use site.

Both new nodes have reviewed coverage items and all non-anchor frozen fields remain `-`. The root identity, source hypotheses, quantifier order, conclusion, carrier normalizations, and constant scopes remain unchanged and correct. All 21 nodes are in the root closure; all 28 dependencies are conjunctive direct uses; no source OR route is present; the Dorronsoro node remains the single external boundary; there are no hidden standing assumptions or out-of-closure nodes. The seven exclusions remain appropriate. The final unresolved list is exactly the five explicit `SOURCE_GAP` nodes: Dorronsoro localization/normalization, exponent admissibility, scaled local-data admissibility, final quantitative rescaling, and compact-set localization. No additional substantive source step is missing.

The generated dashboard is stale: its queue still labels the two new nodes `PROPOSED`, although their effective records and coverage entries are `REVIEWED`. This is a mechanical publication correction only: regenerate the dashboard, then record `GLOBAL_REVIEWER: section4_graph_global_review` and set `GLOBAL_REVIEW_REF` to this report. Subject to those metadata/dashboard updates, the corrected graph passes global source-only review.
