# Affine scaling audit

## Scope and verdict

Read-only, refute-first audit of:

- `AffineChangeVariables.lean`
- `AffineIntegral.lean`
- `AffineFractional.lean`
- `RadiusChangeVariables.lean`
- `AffineBallGeometry.lean`

against the rescaling step in `source/self-improvement.tex` lines 200–243.
`AffineRelative.lean` and the final root assembly were excluded as requested.

**Verdict: PASS.** I found no reversed Jacobian, carrier mismatch, hidden
finiteness hypothesis, incorrect fractional exponent, failure at infinite
ENNReal values, or deficient normalized-ball containment in these modules.
This is a source-boundary audit of the scaling layer, not closure of the frozen
root theorem.

## Refutation checks

### Jacobian direction and ball transformation: pass

For `T(y)=x₀+Ry`, `affineScale_preimage_ballSet` proves exactly
`T⁻¹(B(Tc,Rr))=B(c,r)` (`AffineChangeVariables.lean` lines 14–29).  Its proof
works in the source carrier `Fin n → ℝ` and expands `ballSet` as the sum of
coordinate squares, giving the factor `R²` before cancelling it using `R>0`.

`map_affineScale_volume` states
`map T volume = ofReal((R^n)⁻¹) • volume` (lines 31–47).  This is the correct
pushforward direction: integrating a target function after `T` over normalized
coordinates yields `R⁻ⁿ` times its integral over the physical image.  The
subsequent formulas preserve this direction:

- `setLIntegral_affineScale` has coefficient `ofReal((R^n)⁻¹)`
  (`AffineChangeVariables.lean` lines 49–63).
- `setIntegral_affineScale` has real coefficient `(R^n)⁻¹`
  (`AffineIntegral.lean` lines 34–54).
- the pair formula has two inverse-Jacobian factors
  (`AffineFractional.lean` lines 12–38).

This matches the source's change of variables followed by division by `R^n`
at lines 210–226.

### Coordinate carrier and Euclidean geometry: pass

All affine maps act on the plain coordinate carrier `Fin n → ℝ`, exactly the
carrier used by the frozen statement.  Balls are transported through the
coordinate-squared `ballSet`, so no accidental use of the function space's
sup norm enters the ball identities.  The fractional kernel uses
`sqrt (∑j (x j-y j)^2)`, also exactly the source Euclidean distance
(`AffineFractional.lean` lines 40–50).  Thus the topological representation of
the finite-dimensional carrier does not alter the metric quantity being
scaled.

### Bochner integral and normalized oscillation identities: pass

`setIntegral_affineScale` is stated for an arbitrary real-valued function and
does not add an integrability or measurability assumption.  This is legitimate
for Mathlib's Bochner integral convention: the measurable equivalence and
measure scaling transport integrability, and in the nonintegrable case both
sides use the integral's zero convention.  The coefficient is converted from
ENNReal to real only after proving `R^n>0` (`AffineIntegral.lean` lines 38–54).

The local transport lemmas for `MemLp` and `IntegrableOn` use the exact mapped
restricted measure and only the finite scalar side condition
`ofReal((R^n)⁻¹) ≠ ⊤` (`AffineIntegral.lean` lines 56–102).  They do not assume
the desired scaled conclusions.

`ballOscillation_affineScale` proves the source identity
`H_{g_R}(c,r)=H_g(x₀+Rc,Rr)` exactly (`AffineIntegral.lean` lines 104–155).
It separately transports the ball mass, each coordinate mean, and the outer
variance integral.  Positivity of both Jacobian and physical ball mass is
derived from `R>0` and `r>0`; no regularity or integrability hypothesis on `g`
is inserted.  The identity therefore respects the same Bochner convention on
both sides.

### ENNReal finite and infinite cases: pass

`setLIntegral_affineScale` and the pair formula use nonnegative integrals, so
they remain exact when the integral is `⊤`.  Moving the constant through a
lintegral requires only that the Jacobian factor is not `⊤`, which is proved
directly from `ofReal`; the integral itself is never assumed finite
(`AffineChangeVariables.lean` lines 49–63; `AffineFractional.lean` lines
21–38).

Likewise, `fractionalEnergy_affineScale` factors constants through ENNReal
integrals with `ofReal_ne_top` and never cancels an unknown energy.  Its equality
therefore covers both finite and infinite fractional energies
(`AffineFractional.lean` lines 71–85).

### Fractional coefficient: pass

Under `x=x₀+Ru`, the numerator is unchanged as a value of the scaled function,
the denominator contributes `R^(n+2s)`, and the two inverse Jacobians contribute
`R^(-2n)`.  Consequently normalized energy equals
`R^(n+2s-2n)=R^(2s-n)` times physical energy.  This is exactly the theorem
statement at `AffineFractional.lean` lines 40–50.  Lines 60–70 prove the same
exponent algebra using positive-base `Real.rpow`; there is no integer/real-power
coercion gap.

### Radius logarithmic invariance: pass

`setLIntegral_Ioo_mul` proves the ordinary radius substitution with coefficient
`ofReal(R⁻¹)` and interval `(0,Rt)` (`RadiusChangeVariables.lean` lines 14–31).
`radius_lintegral_div_scale` then rewrites
`H(Rr)/r = R·H(Rr)/(Rr)` and cancels the finite positive ENNReal factors
`ofReal R` and `ofReal R⁻¹` (`RadiusChangeVariables.lean` lines 33–57).
The final equality is the exact invariance of `dr/r`; no finite-integral premise
is used, so the calculation also holds at `⊤`.

### Normalized and rescaled ball inclusions: pass

For `0<t≤1` and `c∈B(0,1+2t)`, the triangle estimate gives
`B(c,4t)⊆B(0,8)` (`AffineBallGeometry.lean` lines 25–30):
`4t + dist(c,0) < 1+6t ≤ 7 < 8`.  The proof uses the project's explicit
Euclidean `toLp 2` geometry lemma, so it is consistent with `ballSet`.

The affine image theorem then gives
`B(x₀+Rc,4(Rt))⊆B(x₀,8R)` for every `R>0`, `0<t≤1`
(`AffineBallGeometry.lean` lines 32–39).  This is the containment needed to
apply the physical relative hypothesis in the source's normalized domain.
The separate source condition `R≤1`, needed to conclude `Rt≤1`, properly
belongs to the consumer of these geometry lemmas rather than to the inclusion
itself.

## Mechanical verification

A transient probe imported all five modules and checked the exact public
exports relevant to the audit: the preimage, pushforward, single and pair
lintegral, Bochner integral, `MemLp`, `IntegrableOn`, oscillation, fractional
energy, radius, affine image, and two containment declarations.  All fifteen
checked exports depend only on `[propext, Classical.choice, Quot.sound]`.
The probe exited successfully and was deleted.  No audited source file was
modified.

## Boundary

These modules establish the exact analytic and geometric rescaling identities
used in source lines 200–243.  They do not by themselves show that the original
relative hypothesis transfers to scaled data, that local representatives meet
the unit theorem's hypotheses, or that the final compact-local conclusion
holds.  Those obligations remain outside this audit.
