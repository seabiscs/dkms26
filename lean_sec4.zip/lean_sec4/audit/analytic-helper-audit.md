# Independent audit of analytic helper modules

## Verdict

`IMPLEMENTATION_SOUNDNESS: PASS` for all 26 theorems and one definition in the six modules at the hashes below.

`SOURCE_STEP_CORRESPONDENCE: PASS (internal/conditional)`.

`FULL_ABSTRACT_LEMMA_COVERAGE: INCOMPLETE`.

No actual correctness defect, hidden theorem premise, normalization drift, norm mismatch, or scaling error was found. Each module compiles independently with no warning. A marker scan found no `sorry`, `admit`, `axiom`, `opaque`, `unsafe`, or heartbeat override. Representative load-bearing exports from every module have only the standard Mathlib axioms `propext`, `Classical.choice`, and `Quot.sound`.

These are proved internal tools. They neither declare nor prove the source-facing abstract self-improvement theorem. The candidate source statement remains unapproved and unfrozen, and no closure status follows from this report.

## Audited snapshots

| Module | SHA-256 | Declarations |
|---|---|---:|
| `Geometry.lean` | `8324ac90e170e4c181ffb7fc93ecb6d7422ea2918f504d60c8f1c0485d43bfde` | 12 theorems |
| `Variance.lean` | `9689685eb9dfdc0758d5c714b0db8151afec0b1f11807e7ba3a72b12f3eaa9d0` | 1 definition, 6 theorems |
| `HoleFilling.lean` | `2c886fab78ec9f177fccfee74303fa03970ea5cf26de5b4deecca54f1011470b` | 2 theorems |
| `TailDecay.lean` | `09ee60291000f5a435ca17a7889274a1e105e5edd6c848fbdcecef55a3405d35` | 1 theorem |
| `TailMoment.lean` | `a76ba40a97b3838d3f74ec944f908cb83df3d76edd6dca0b03cdfcae2cb33740` | 1 theorem |
| `Scaling.lean` | `406ce314a13bb1b5a42149d95f27510188c909533bbc272ea4fd593fdce3db1e` | 4 theorems |

Source comparison used `source/self-improvement.tex` SHA-256 `7f218e9763a8e92c344ec7e1f6a7d1d6b0ea5ca81fae924d7d237903c92a3644`, chiefly proof lines 43–196 and 201–243. This audit did not inspect the separately authored `TailMeasure.lean` and `Kernel.lean`; they are assigned to another independent reviewer.

## Geometry audit

The source carrier `Fin n -> R` inherits the product/sup metric in Lean, while the manuscript uses Euclidean distance. `Geometry.lean` handles this correctly and explicitly: every metric argument transports coordinates by `WithLp.toLp 2` into `EuclideanSpace R (Fin n)`. The foundational identity

`dist (toLp 2 x) (toLp 2 y)^2 = sum_i (x_i-y_i)^2`

matches the literal `ballSet` predicate, so no accidental sup-norm ball enters any source argument.

The main declarations correspond as follows:

- `mem_ballSet_iff_euclidean_dist` and `euclidean_preimage_ball` identify the literal source ball with the true Euclidean metric ball.
- `ballSet_subset_of_dist_add_le`, `ballSet_subset_ballSet`, and `moving_ballSet_subset` give the triangle/monotonicity containments used when integrating over moving centers.
- `volume_ballSet_eq_euclidean` and `volume_ballSet_center` transfer Haar-volume facts without changing normalization.
- `volume_ballSet_mul` gives exactly the dimension factor `a^n`; with `a=4` it produces the source ratio `|B_{4t}|/|B_t|=4^n`.
- `volume_ballSet_inter_lower` proves the common-center lower bound using the midpoint ball of radius `r/2`, hence the uniform factor `2^{-n}` required by the direct Gagliardo bridge.
- `compact_finite_ballSet_cover` is the qualitative finite covering tool. For the fixed set `B_2` and radius one, a chosen finite cover and its cardinal depend only on `n`, so this is sufficient in principle for the source's `c(n)` dependence; later assembly must make that choice before all function and domain data.
- `common_centers_subset_moving_ball` correctly puts all common centers for a pair in `B_1` inside `B_{1+r}`.

Adversarial checks:

1. The midpoint proof uses the Euclidean metric on `toLp 2`, not the ambient coordinate sup norm: pass.
2. Volume preservation under `toLp 2` prevents a dimension-dependent linear-map Jacobian from being lost: pass.
3. The intersection lower bound assumes distance `<=r`, exactly the near-pair window; the contained midpoint ball has radius `r/2`: pass.
4. `moving_ballSet_subset` has sufficient slack: `dist(0,x)<a+r<=a+t`, then adding a point distance `<t` gives `<a+2t`: pass.

Status: `PROVED INTERNAL GEOMETRY`. The fixed-ball cover still needs to be instantiated and threaded through the source-uniform constant construction.

## Variance audit

`normalizedMean mu f = (integral f dmu) / mu.real univ` is the exact finite-measure average. The hypotheses `[IsFiniteMeasure mu]` and `mu univ != 0` ensure that `mu.real univ` is finite and strictly positive. There is no division-by-zero or infinite-mass fallback.

The scalar identity

`integral (f-mean)^2 = integral f^2 - (integral f)^2 / mass`

has the correct normalization. It yields the minimizing estimate against zero, and the componentwise finite sum exactly represents the squared Euclidean target norm. The pairwise identity is also normalized correctly:

`double integral (f(x)-f(y))^2 = 2 mass * integral (f-mean)^2`.

Thus for a normalized oscillation `H=(1/mass) integral |g-mean|^2`, the pair integral is `2 mass^2 H`, with no missing mass or factor two. This is the identity required to turn center integration into a lower bound for near-pair energy.

All uses of linearity are guarded by `MemLp 2`, from which the file derives both `L1` and square integrability under a finite measure. The coordinate-summed version requires each coordinate in `MemLp`; finiteness of `Fin m` makes this equivalent to vector-valued `L2`.

Status: `PROVED INTERNAL VARIANCE`. A later bridge must instantiate `mu` as the restricted volume on a positive-radius ball and reconcile `normalizedMean` with the exact source `mean` definition.

## Hole-filling audit

`holeFilling_rearrange` proves the elementary implication

`x <= C(y-x)+e  =>  x <= [C/(C+1)]y + e/(C+1)`

under exactly `C>=0`. The positive denominator is proved; no sign premise on `x,y,e` is needed.

`holeFilling_rearrange_source` substitutes `C=4^n K/log 4` and returns the exact contraction

`4^n K/(4^n K+log 4)`.

The transformed error coefficient `e log 4/(4^n K+log 4)` is algebraically exact. The manuscript hides this harmless factor in `c`; later assembly may absorb it into its produced error constant. `K>=1` is the source premise and proves all required positivity.

Status: `PROVED INTERNAL ALGEBRA`.

## Updated tail-decay audit

At the current hash, `tail_decay_of_contract` no longer carries the redundant explicit `0<sigma` premise. This is correct: `0<gamma` and `gamma<sigma`, both derived from `gamma<min(2s0,sigma)`, already imply it.

The recurrence, contraction ratio, grid `16^{-k}`, error base `16^{-sigma}`, geometric-series denominator, and interpolation loss `16^gamma` all remain exact. Its conditional inputs are produced proof facts (`Phi(1)>=0`, monotonicity, nonnegative error coefficient, and recurrence), not permissible extra binders of the source-facing theorem.

Status: `PROVED CONDITIONAL INTERNAL ASSEMBLY`.

## Tail-moment audit and constant uniformity

`weightedMoment_of_contract` chooses

`C = 16^gamma * (1 + 16^{-sigma}/(16^{-gamma}-theta)) * gamma/(gamma-2s)`

after `n,K,sigma,s` and before `nu,B`. The intermediate `gamma` is obtained only from the source exponent window. Therefore the existential constant depends only on `n,K,sigma,s`; it is uniform in the measure `nu`, its total mass, the recurrence error coefficient `B`, and all future function/domain/ball data.

The theorem correctly requires finite mass only on `(0,1]`. This suffices to make every cumulative mass below radius one finite and to justify `ENNReal.toReal` monotonicity. The recurrence uses those real cumulative masses; the conclusion returns to an extended nonnegative integral, so it does not assume the desired weighted integrability.

The absorption

`Phi(1) + B*b/(a-theta) <= (1+b/(a-theta)) (Phi(1)+B)`

is valid with all factors nonnegative. Applying `inversePower_weightedMoment_le` with `q=2s` gives the correct factor `gamma/(gamma-2s)`. No scale, measure, or error dependence enters `C`.

The theorem is still conditional on constructing the actual density measure and proving its cumulative recurrence. That condition belongs in proof assembly and must not become a source theorem premise.

Status: `PROVED UNIFORM INTERNAL HELPER`.

## Scaling and diagonal audit

`affineScale_sqrt_distance` proves the exact distance scaling for `R>0`, including the correct removal of `abs R`.

`fractionalKernel_affineScale` proves pointwise

`reference kernel = R^(n+2s) * physical kernel`.

This direction is correct. After the two Jacobian factors in a double change of variables it gives

`[g_R]^2 = R^(2s-n) [g]^2`,

and hence the manuscript's `R^{-2s}` final estimate after scaling the volume terms by `R^{-n}`.

The identity holds on the diagonal as written. Both numerators vanish when `y=z`; Lean's real division by zero makes both kernel fractions zero. Multiplication by the strictly positive finite scale factor preserves equality. The `ENNReal.ofReal` version uses the nonnegativity of `R^(n+2s)` and is exact.

`affineScale_mem_ballSet_iff` correctly scales the literal squared-coordinate ball predicate. It remains valid for arbitrary `r` because both radii are squared, while all source uses later have positive `r`.

The module documentation correctly limits scope: it contains pointwise algebra only. It does not prove the measurable affine change-of-variables or its Jacobian for single and double integrals.

Status: `PROVED POINTWISE SCALING`; integral rescaling remains open.

## Coverage ledger

| Source proof component | Current audited support | Status |
|---|---|---|
| Literal Euclidean ball geometry | `Geometry` | Covered |
| Ball-volume ratio and common-center lower bound | `Geometry` | Covered |
| Mean minimizes square error | `Variance` | Covered abstractly |
| Pairwise variance identity | `Variance` | Covered abstractly |
| Algebra from (4.6) to (4.7) | `HoleFilling` | Covered |
| Recurrence iteration and continuous decay | `TailDecay` plus prior scalar helpers | Covered conditionally |
| Decay to weighted moment with uniform constant | `TailMoment` | Covered conditionally |
| Pointwise affine distance/kernel/ball scaling | `Scaling` | Covered |
| Dimension-only finite cover of `B_2` by unit balls | Qualitative finite cover suffices after fixed-ball instantiation | Covered in principle; assembly open |
| Measurability/finiteness of source `E` and `Phi` | No assembly in this set | Open |
| Integrated source hypothesis giving (4.5) | Ingredients only; no Tonelli assembly | Open |
| Integration of (4.5) over `t` giving (4.6) | No bridge in this set | Open |
| Actual tail density measure and cumulative identity | Outside audit (`TailMeasure`) | Pending separate review |
| Near-pair energy to Gagliardo integral | Geometry/variance ingredients only | Open |
| Single/double affine change of variables | Pointwise scaling only | Open |
| Exact source-facing theorem assembly | None | Open and blocked on statement approval/freeze |

## Findings ledger

| ID | Severity/status | Finding | Consequence |
|---|---|---|---|
| A1 | Coverage gap, survived | Geometry and variance prove the components of the center-Tonelli estimate but no theorem assembles them for the actual oscillation. | Source (4.5) remains unproved. |
| A2 | Coverage gap, survived | No audited theorem integrates (4.5) across `r<t<4r` to obtain (4.6). | The recurrence cannot yet be fed into `TailDecay`. |
| A3 | Coverage gap, survived | Scaling proves only pointwise identities, with no affine change-of-variables/Jacobian theorem. | Final rescaling in source Step 2 remains unproved. |
| A4 | Process boundary | The source-facing statement is not author-approved or frozen. | No helper may establish source-node closure or authorize a dependency graph root. |

No reportable correctness finding applies to the audited implementations themselves.

## Verification evidence

Each of the six files was independently checked with

`lake env lean AffineCarleson/SelfImprovement/<Module>.lean`.

All six commands exited zero with no output or warning. Representative `#print axioms` checks were run for:

- `volume_ballSet_inter_lower`;
- `integral_integral_sum_sub_sq`;
- `holeFilling_rearrange_source`;
- `tail_decay_of_contract`;
- `weightedMoment_of_contract`;
- `fractionalKernel_affineScale_ofReal`.

Every result contained only `propext`, `Classical.choice`, and `Quot.sound`. The temporary probe was deleted.

## Closeout

- Current hashes pinned: yes.
- Declaration inventory complete: yes, 27/27.
- Euclidean-versus-sup-norm issue checked: yes, correct explicit `toLp 2` use.
- Variance normalization and factor two checked: yes.
- Tail-moment constant dependence checked: yes, uniform in all later data.
- Scaling direction and diagonal checked: yes.
- Coverage gaps recorded without upgrading proof status: yes.
- Source theorem approved, frozen, or proved: no.
