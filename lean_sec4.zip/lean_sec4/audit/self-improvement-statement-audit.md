# Exact target audit: `meanOscillation_selfImprovement`

## Verdict

`DECLARATION_FIDELITY: PASS`

`ELABORATION_IDENTITY: PASS` for candidate SHA-256 `58cc205979733e42ab1153778ef4be714b341359a4703a04a35243aed47f49c2`.

`PROOF_STATUS: UNPROVED_CANDIDATE` — the exact command elaborates only with its displayed `sorry`. It has not been author-approved, manifested, or frozen, so this audit does not assign `FROZEN_UNPROVED` or any proved/axiom-closed status.

`SECTION_STATUS: OPEN` — the stronger `M=0` corollary and final application to Theorem 1.1 are deliberately outside this declaration and remain downstream.

The declaration faithfully encodes the complete displayed abstract Lemma 4.1: both local fractional regularity and the quantitative estimate. I found no `EXCESS` hypothesis and no semantic mismatch in its four meaning-carrying `let`s. Compilation is evidence only of elaboration, not proof.

## Frozen evidence and scope

- Candidate command: `work/self-improvement/command.txt`, SHA-256 `58cc205979733e42ab1153778ef4be714b341359a4703a04a35243aed47f49c2`.
- Source TeX: `outputs/self-improvement-lean/source/self-improvement.tex`, SHA-256 `7f218e9763a8e92c344ec7e1f6a7d1d6b0ea5ca81fae924d7d237903c92a3644`, especially lines 5–39.
- Source transcription: `outputs/self-improvement-lean/source/reference.txt`, SHA-256 `ca07c7ca2f799428e70b9d84a9abfa2923c811d7b5df8c8b1c46bd5c7ce394c9`, pages 3–4 and 9–12.
- Independent reconstruction and proof audit: `work/self-improvement/source-audit.md`.

Audit scope is the exact theorem command, including expanded local-integrability premises, all `let` bodies, and both conjuncts of the conclusion. Provider implementation and proof correctness are not audited. No source goal has been landed or frozen.

## Source-to-Lean correspondence

The source chooses `c=c(n,K,sigma,s)`. Lean places `exists c` after exactly `n,K,sigma,s` and their source/standing range conditions, and before `m,Omega,g,mu,M,x0,R`. Hence the bound is uniform in every datum omitted by the source's dependency list.

`R^m` is represented by `Fin m -> R`, and squared Euclidean norms by finite sums of coordinate squares. Open Euclidean balls are represented literally by strict squared-distance inequalities. All balls occur under a positive-radius binder, so the algebraic behavior of `r^2` at nonpositive radii does not change the source statement.

The compact-containment notation is represented by `closure (ball x0 (k*R)) subset Omega`. In finite-dimensional Euclidean space this is equivalent to the source's ball compactly contained in the open set: the closed ball is compact automatically. No compactness premise has been omitted.

Both potentially improper nonnegative integrals are `ENNReal` `lintegral`s. This preserves the source's finiteness content. The finite right sides are embedded by `ENNReal.ofReal`; local integrability and nonnegativity ensure their mathematical nonnegativity on every ball at point of use.

## Complete five-bin binder table

The table expands the two local-integrability predicates and the global relative estimate rather than treating them as opaque bundles.

| # | Lean binder / logical component | Bin | Source meaning and anchor |
|---:|---|---|---|
| 1 | `n : Nat` | TYPING | Domain dimension of `R^n`; source global convention, pages 1–4. |
| 2 | `hn : 2 <= n` | STANDING | Manuscript standing convention `n,N >= 2`, source page 1; not an added analytic premise. |
| 3 | `K : R` | SOURCE | Fixed parameter in Lemma 4.1, TeX lines 3, 20–24. |
| 4 | `sigma : R` | SOURCE | Fixed parameter, TeX lines 3, 20–24. |
| 5 | `s : R` | SOURCE | The universally chosen conclusion exponent, TeX lines 27–28. |
| 6 | `hK : 1 <= K` | SOURCE | TeX line 21. |
| 7 | `hSigma : 0 < sigma` | SOURCE | TeX line 21. |
| 8 | `hs : 0 < s` | SOURCE | TeX line 28. |
| 9 | `hs_upper : s < min(s0,sigma/2)` | SOURCE | Exact exponent window, with exact `s0`, TeX lines 22–28. |
| 10 | existential `c : R` | SOURCE | Quantitative constant witness, TeX lines 31–38. |
| 11 | `0 < c` | SOURCE | Standard positive-constant convention; harmless explicit content of `c=c(...)`. |
| 12 | `m : Nat` | TYPING | Target dimension in `R^m`, TeX line 6. Quantifying `m=0` only includes the trivial zero-dimensional instance and creates no stronger hypothesis or weaker source case. |
| 13 | `Omega : Set (Fin n -> R)` | TYPING | Source domain carrier, TeX lines 6, 20, 37. |
| 14 | `IsOpen Omega` | STANDING | `Omega` is open under the manuscript conventions, source page 1. |
| 15 | `g : R^n -> R^m` | SOURCE | TeX line 6. |
| 16 | `mu : R^n -> R` | SOURCE | TeX line 7. |
| 17 | `M : R` | SOURCE | Fixed error coefficient, TeX lines 16, 21. It occurs after `c`, enforcing independence. |
| 18 | `0 <= M` | SOURCE | TeX line 21. |
| 19 | local-`L2` test set `A` | SOURCE | Expansion of `g in L2_loc(Omega;R^m)`, TeX line 6. |
| 20 | `IsCompact A` | SOURCE | Compact-subset criterion for local `L2`. |
| 21 | `A subset Omega` | SOURCE | Compact-subset criterion for local `L2`. |
| 22 | coordinate `alpha : Fin m` | TYPING | Finite-coordinate expansion of vector-valued local `L2`. |
| 23 | `MemLp (g_alpha) 2 (volume.restrict A)` | SOURCE | Exact local square-integrability premise; finite coordinates are equivalent to Euclidean vector-valued local `L2`. |
| 24 | local-`L1` test set `A` | SOURCE | Expansion of `mu in L1_loc(Omega)`, TeX line 7. |
| 25 | `IsCompact A` | SOURCE | Compact-subset criterion for local `L1`. |
| 26 | `A subset Omega` | SOURCE | Compact-subset criterion for local `L1`. |
| 27 | `IntegrableOn mu A` | SOURCE | Exact local integrability premise. |
| 28 | `mu >= 0` almost everywhere on `Omega` | SOURCE | TeX line 7; a.e. is the measure-theoretically exact reading for integral statements. |
| 29 | relative-estimate center `x0` | SOURCE | Universal center in (4.1), TeX lines 14–20. |
| 30 | relative-estimate radius `R` | SOURCE | Universal radius in (4.1). |
| 31 | `0 < R` | SOURCE | TeX line 20. |
| 32 | `R <= 1` | SOURCE | TeX line 20. |
| 33 | `closure (ball x0 (4*R)) subset Omega` | SOURCE | Exact finite-dimensional rendering of `B(x0,4R) compactly contained in Omega`, TeX line 20. |
| 34 | relative Carleson inequality | SOURCE | Equation (4.1), TeX lines 11–19, with normalized oscillation, unnormalized outer integrals, `K |B_4R|`, and `M R^sigma integral mu`. |

Counts across all rows: `SOURCE = 28`, `STANDING = 2`, `TYPING = 4`, `RULED = 0`, `EXCESS = 0`. Rows 10–11 describe the existential source witness and its property; excluding that conclusion witness from “logical input” counts gives `SOURCE = 26`, `STANDING = 2`, `TYPING = 4`, hence 32 logical inputs.

## Meaning-carrying `let` audit

| `let` | Source comparison | Verdict |
|---|---|---|
| `ball x r = {y | sum_i (y_i-x_i)^2 < r^2}` | Literal open Euclidean ball. Positive radii are enforced at every source use. | PASS |
| `mean x r alpha = volume(ball x r).toReal^-1 * integral_(ball x r) g_alpha` | Literal normalized ball average, componentwise. Finite-dimensional componentwise Bochner integrals equal the vector average. | PASS |
| `osc x r = volume(ball x r).toReal^-1 * integral_(ball x r) sum_alpha (g_alpha-mean_alpha)^2` | Literal `H_g`: normalized average of squared Euclidean deviation from the ball mean. | PASS |
| `fractionalEnergy A` | Literal source Gagliardo double integral with numerator `|g(x)-g(y)|^2` and denominator `|x-y|^(n+2s)`, represented by `Real.rpow(sqrt(sum distance-coordinate squares))`. | PASS |

At `x=y`, Lean's real division convention makes `0/0=0`. The diagonal is Lebesgue-null for `n>=2` (indeed for positive dimension), so this convention does not alter the integral.

No project-owned predicate or assumption bundle hides additional premises. The declaration uses standard Mathlib notions (`MemLp`, `IntegrableOn`, `lintegral`, volume, closure, finite sums, and real powers) directly.

## Conclusion audit

The first conjunct

`forall compact A subset Omega, fractionalEnergy A < top`

faithfully renders `g in W^{s,2}_loc(Omega;R^m)` together with the already assumed local `L2` condition. For open `Omega`, every compact subset lies in a relatively compact neighborhood, and conversely finite energy on all compact subsets gives the usual local criterion. This is a definitional bridge necessitated by the absence of a suitable generic exported fractional-Sobolev predicate; it neither strengthens the theorem on source cases nor drops finiteness.

The second conjunct reproduces (4.3) literally:

- universal `x0,R`, `0<R<=1`;
- `B(x0,8R)` compactly contained in `Omega`;
- the explicit energy on `B(x0,R)`;
- factor `c R^(-2s)`;
- `integral |g|^2 + M R^sigma integral mu` on `B(x0,8R)`.

The conclusion center and radius occur after the constant and all function data. There is no hidden choice of `c` per ball.

## Adversarial checks

1. **Could `c` depend on `M` or the target dimension?** No. The existential closes before `m,Omega,g,mu,M`; all later data are under its universal scope.
2. **Could the Bochner integral silently turn an improper source left side into zero?** No. The hypothesis left side and conclusion energy use `lintegral`. Bochner integrals remain only where the source assumes local integrability and expects finite ball integrals: mean, oscillation numerator, and RHS data terms.
3. **Does `closure(ball) subset Omega` omit compactness?** No. Closed bounded balls in `Fin n -> R` are compact. With positive radius this is the exact compact-containment condition.
4. **Is local fractional regularity weaker because it is stated only on compact sets?** No. In an open finite-dimensional domain it is equivalent to the usual `W^{s,2}_loc` condition, given the separately encoded local `L2` premise.
5. **Does componentwise local `L2` permit a vector norm failure?** No. `Fin m` is finite, so the sum of finitely many locally integrable squares is locally integrable.
6. **Is the denominator exponent or normalization wrong?** No. `sqrt(sum_i (x_i-y_i)^2)` is Euclidean distance and the exponent is exactly `n+2s`; the source seminorm contains no normalization factor.
7. **Is the source's stronger `M=0` statement lost?** It is not part of displayed (4.3)'s formal theorem contract. It remains a valid separate downstream corollary and cannot block approval of this exact abstract lemma.
8. **Are earlier Proposition 3.1, Gehring, or `V` estimates smuggled in?** No. None is a binder. They remain required only for the downstream final application.

All initial concerns were refuted by the exact quantifier structure, finite-dimensional topology, or literal body expansion. There is no reportable semantic finding.

## Verification evidence

Independent command:

`cd outputs/self-improvement-lean && lake env lean ../../work/self-improvement/command.txt`

Result: exit code 0, with only `command.txt:13:8: warning: declaration uses sorry`.

This establishes that the exact candidate parses and elaborates in the stated environment. It does not establish the theorem, source dependency closure, or axiom cleanliness.

## Approval boundary

The command is suitable for author source-statement approval as the exact Lean target for displayed Lemma 4.1. After approval it may be versioned and frozen under the repository process. No dependency graph should be anchored to this audit report itself, and no proof implementation should be credited until the exact frozen export is sealed and independently checked.
