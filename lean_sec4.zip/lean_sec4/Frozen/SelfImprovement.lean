import AffineCarleson.SelfImprovement.Proof

noncomputable section
set_option autoImplicit false
open MeasureTheory

namespace AffineCarleson

/-- The abstract self-improvement lemma: the source Carleson-type hypothesis
implies local fractional regularity and the quantitative Gagliardo estimate.
The constant is chosen before the output dimension, domain, functions,
error coefficient, center, and radius. -/
theorem meanOscillation_selfImprovement
    (n : ℕ) (hn : 2 ≤ n)
    (K σ s : ℝ) (hK : 1 ≤ K) (hσ : 0 < σ) (hs : 0 < s)
    (hs_upper : s < min
      (Real.log (1 + Real.log 4 / ((4 : ℝ) ^ n * K)) / (2 * Real.log 16))
      (σ / 2)) :
    ∃ c : ℝ, 0 < c ∧
      ∀ (m : ℕ) (Ω : Set (Fin n → ℝ)), IsOpen Ω →
      ∀ (g : (Fin n → ℝ) → Fin m → ℝ) (μ : (Fin n → ℝ) → ℝ)
        (M : ℝ), 0 ≤ M →
      (∀ A : Set (Fin n → ℝ), IsCompact A → A ⊆ Ω →
        ∀ α : Fin m, MemLp (fun y => g y α) 2 (volume.restrict A)) →
      (∀ A : Set (Fin n → ℝ), IsCompact A → A ⊆ Ω → IntegrableOn μ A) →
      (∀ᵐ y ∂volume.restrict Ω, 0 ≤ μ y) →
      let ball : (Fin n → ℝ) → ℝ → Set (Fin n → ℝ) :=
        fun x r => {y | ∑ i, (y i - x i) ^ 2 < r ^ 2}
      let mean : (Fin n → ℝ) → ℝ → Fin m → ℝ :=
        fun x r α => (volume (ball x r)).toReal⁻¹ * (∫ y in ball x r, g y α)
      let osc : (Fin n → ℝ) → ℝ → ℝ := fun x r =>
        (volume (ball x r)).toReal⁻¹ *
          (∫ y in ball x r, ∑ α, (g y α - mean x r α) ^ 2)
      let fractionalEnergy : Set (Fin n → ℝ) → ENNReal := fun A =>
        ∫⁻ x in A, ∫⁻ y in A,
          ENNReal.ofReal ((∑ α, (g x α - g y α) ^ 2) /
            Real.rpow (Real.sqrt (∑ i, (x i - y i) ^ 2)) ((n : ℝ) + 2 * s))
      (∀ (x₀ : Fin n → ℝ) (R : ℝ), 0 < R → R ≤ 1 →
        closure (ball x₀ (4 * R)) ⊆ Ω →
        (∫⁻ x in ball x₀ R, ∫⁻ r in Set.Ioo (0 : ℝ) R,
          ENNReal.ofReal (osc x r / r)) ≤
        ENNReal.ofReal (K * (volume (ball x₀ (4 * R))).toReal * osc x₀ (4 * R) +
          M * Real.rpow R σ * (∫ y in ball x₀ (4 * R), μ y))) →
      (∀ A : Set (Fin n → ℝ), IsCompact A → A ⊆ Ω → fractionalEnergy A < ⊤) ∧
      (∀ (x₀ : Fin n → ℝ) (R : ℝ), 0 < R → R ≤ 1 →
        closure (ball x₀ (8 * R)) ⊆ Ω →
        fractionalEnergy (ball x₀ R) ≤
          ENNReal.ofReal (c * Real.rpow R (-2 * s) *
            ((∫ y in ball x₀ (8 * R), ∑ α, (g y α) ^ 2) +
              M * Real.rpow R σ * (∫ y in ball x₀ (8 * R), μ y)))) := by
  exact Internal.meanOscillation_selfImprovement n hn K σ s hK hσ hs hs_upper

end AffineCarleson
