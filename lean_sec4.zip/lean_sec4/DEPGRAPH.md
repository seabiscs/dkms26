# Proof dependency database — mean-oscillation self-improvement

GRAPH_VERSION: 4
ROOTS: selfimprovement
CORPUS: source/self-improvement.tex sha256:7f218e9763a8e92c344ec7e1f6a7d1d6b0ea5ca81fae924d7d237903c92a3644; source/reference.txt sha256:ca07c7ca2f799428e70b9d84a9abfa2923c811d7b5df8c8b1c46bd5c7ce394c9
CONVENTIONS: Euclidean open balls in R^n; |B_r| is Lebesgue volume; (g)_{x,r} and \mint are normalized ball means; Hosc is normalized squared Euclidean vector oscillation; fractional seminorm uses kernel |x-y|^(-n-2s); local means every compact subset of Ω; constants may change only within the dependencies stated by each record
STANDING_ASSUMPTIONS: -
EXTERNAL_POLICY: Cited results are explicit external leaf nodes; routine Tonelli, change of variables, integration by parts, finite coverings, and elementary geometric-series facts are internal steps when substantively used.
FROZEN_ANCHORS: selfimprovement
FROZEN_MANIFEST: frozen-manifest.json | sha256:1ee8d5d5a3324f7720076b4233b653a6219ed5ba04f29cafbc764423f4a65596
WRITER: section4_graph
GLOBAL_REVIEWER: section4_graph_global_review
GLOBAL_REVIEW_REF: audit/section4-graph-global-review.md

The dependency direction is `NODE -> prerequisite`. `DEPS` is conjunctive.

## Nodes

NODE: selfimprovement
KIND: lemma
TITLE: Mean-oscillation self-improvement
STATEMENT_SOURCE: source/self-improvement.tex#selfimprovement@L5-L39
PROOF_SOURCE: source/self-improvement.tex#selfimprovement-proof@L41-L244
CONTRACT_ID: mean-oscillation-self-improvement
CONTRACT_VERSION: 1
SOURCE_HYPOTHESES: n ≥ 2; Ω ⊆ R^n open; g ∈ L²_loc(Ω;R^m); μ ∈ L¹_loc(Ω), μ ≥ 0 a.e.; K ≥ 1, M ≥ 0, σ > 0 fixed; for every x₀,R with B(x₀,4R) compactly contained in Ω and 0 < R ≤ 1, the displayed relative mean-oscillation estimate (4.1) holds; 0 < s < min{s₀,σ/2}, with s₀ given by (4.2)
SOURCE_QUANTIFIERS: ∀ n≥2; ∀ K≥1, σ>0, s with 0<s<min{s₀,σ/2}; ∃ c>0 depending only on n,K,σ,s; ∀ m, open Ω, g, μ, M≥0 satisfying the local hypotheses and (4.1); conjunction of local membership and ∀ x₀,R with 0<R≤1 and B(x₀,8R) compactly contained in Ω
SOURCE_CONCLUSION: g ∈ W^{s,2}_loc(Ω;R^m), and [g]²_{W^{s,2}(B(x₀,R))} ≤ c R^{-2s}[∫_{B(x₀,8R)}|g|² + M R^σ∫_{B(x₀,8R)}μ]
CONSTANT_SCOPE: s₀ depends exactly on n,K through (4.2); c depends only on n,K,σ,s and is chosen before m,Ω,g,μ,M,x₀,R
FROZEN_FILE: Frozen/SelfImprovement.lean
FROZEN_DECL: AffineCarleson.meanOscillation_selfImprovement
FROZEN_ANCHOR_ID: self-improvement-v1
FROZEN_ABI_SHA256: d674c7a7c39e732be5b485fd2f30c7b0b6de0be5b33c17b71616a2a5d9ac0086
DEPS: final-rescaling-estimate, local-compact-membership
ROUTES: -
ROUTE_FOR: -
EDGE: final-rescaling-estimate | source/self-improvement.tex#final-rescaling@L235-L243 | supplies the quantitative conclusion for every admissible ball
EDGE: local-compact-membership | source/self-improvement.tex#lemma-conclusion@L27-L38 | supplies the separate qualitative local-membership conjunct required by the statement
TOPOLOGY_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review
LEAN_STATUS: NOT_STARTED
LEAN_REF: -
LEAN_NOTE: -
NOTE: STATEMENT_SOURCE gives the exact standalone statement; its ambient n≥2/open-Ω setting is separately inventoried at source/reference.txt L24-L31 because the schema permits one statement locator. Joint frozen root; the M=0 strengthening at TeX L197-L198 and the later application to Theorem 1.1 at TeX L246-L267 are outside this root contract.

NODE: oscillation-tail-definitions
KIND: definition
TITLE: Fixed-ball tail quantities
STATEMENT_SOURCE: source/self-improvement.tex#fixed-ball-definitions@L43-L55
PROOF_SOURCE: source/self-improvement.tex#fixed-ball-definitions@L43-L55
CONTRACT_ID: selfimprovement.fixed-ball-tail
CONTRACT_VERSION: 1
SOURCE_HYPOTHESES: x₀=0 and R=1; 0<r,t≤1
SOURCE_QUANTIFIERS: define E(r), Φ(t), ℬ, and 𝒜 on the fixed ball B₈
SOURCE_CONCLUSION: E(r)=∫_{B_{1+r}}Hosc_g(x,r)dx; Φ(t)=∫₀ᵗE(r)dr/r; ℬ=M∫_{B₈}μ; 𝒜=∫_{B₈}|g|²+ℬ
CONSTANT_SCOPE: definitions contain no new constants
FROZEN_FILE: -
FROZEN_DECL: -
FROZEN_ANCHOR_ID: -
FROZEN_ABI_SHA256: -
DEPS: -
ROUTES: -
ROUTE_FOR: -
TOPOLOGY_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review
LEAN_STATUS: NOT_STARTED
LEAN_REF: -
LEAN_NOTE: -
NOTE: -

NODE: tailfinite
KIND: step
TITLE: Initial tail finiteness bound
STATEMENT_SOURCE: source/self-improvement.tex#eq:tailfinite@L56-L77
PROOF_SOURCE: source/self-improvement.tex#eq:tailfinite@L56-L77
CONTRACT_ID: selfimprovement.tailfinite
CONTRACT_VERSION: 1
SOURCE_HYPOTHESES: fixed-ball setting and the relative estimate (4.1)
SOURCE_QUANTIFIERS: for the finite cover x₁,…,x_J of B₂ with J≤c(n)
SOURCE_CONCLUSION: Φ(1) ≤ c(n,K)𝒜; hence Φ is finite and nondecreasing on (0,1]
CONSTANT_SCOPE: cover size depends only on n; bound depends only on n,K
FROZEN_FILE: -
FROZEN_DECL: -
FROZEN_ANCHOR_ID: -
FROZEN_ABI_SHA256: -
DEPS: oscillation-tail-definitions
ROUTES: -
ROUTE_FOR: -
EDGE: oscillation-tail-definitions | source/self-improvement.tex#eq:tailfinite@L66-L74 | uses Φ and 𝒜 to state and bound the covered integrals
TOPOLOGY_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review
LEAN_STATUS: NOT_STARTED
LEAN_REF: -
LEAN_NOTE: -
NOTE: The source directly reapplies the root's conditional hypothesis; theorem-local hypotheses are not graph leaves.

NODE: averaged-lower-bound
KIND: step
TITLE: Tonelli lower bound after averaging centres
STATEMENT_SOURCE: source/self-improvement.tex#averaged-lower-bound@L78-L102
PROOF_SOURCE: source/self-improvement.tex#averaged-lower-bound@L78-L102
CONTRACT_ID: selfimprovement.averaged-lower-bound
CONTRACT_VERSION: 1
SOURCE_HYPOTHESES: fixed-ball setting; 0<t≤1/4
SOURCE_QUANTIFIERS: ∀ t with 0<t≤1/4
SOURCE_CONCLUSION: the centre-averaged left side of (4.1) is at least |B_t|Φ(t)
CONSTANT_SCOPE: none
FROZEN_FILE: -
FROZEN_DECL: -
FROZEN_ANCHOR_ID: -
FROZEN_ABI_SHA256: -
DEPS: oscillation-tail-definitions
ROUTES: -
ROUTE_FOR: -
EDGE: oscillation-tail-definitions | source/self-improvement.tex#averaged-lower-bound@L87-L101 | identifies the lower integral with volume(B_t) times Φ(t)
TOPOLOGY_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review
LEAN_STATUS: NOT_STARTED
LEAN_REF: -
LEAN_NOTE: -
NOTE: -

NODE: averaged-upper-bounds
KIND: step
TITLE: Oscillation and error upper bounds
STATEMENT_SOURCE: source/self-improvement.tex#averaged-upper-bounds@L104-L124
PROOF_SOURCE: source/self-improvement.tex#averaged-upper-bounds@L104-L124
CONTRACT_ID: selfimprovement.averaged-upper-bounds
CONTRACT_VERSION: 1
SOURCE_HYPOTHESES: fixed-ball setting; μ≥0; 0<t≤1/4
SOURCE_QUANTIFIERS: ∀ t with 0<t≤1/4
SOURCE_CONCLUSION: averaged right side of (4.1) is bounded by K|B_{4t}|E(4t)+|B_{4t}|ℬt^σ
CONSTANT_SCOPE: K and σ remain the fixed theorem parameters
FROZEN_FILE: -
FROZEN_DECL: -
FROZEN_ANCHOR_ID: -
FROZEN_ABI_SHA256: -
DEPS: oscillation-tail-definitions
ROUTES: -
ROUTE_FOR: -
EDGE: oscillation-tail-definitions | source/self-improvement.tex#averaged-upper-bounds@L108-L123 | rewrites the two upper terms using E and ℬ
TOPOLOGY_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review
LEAN_STATUS: NOT_STARTED
LEAN_REF: -
LEAN_NOTE: -
NOTE: -

NODE: tailinequality
KIND: lemma
TITLE: One-scale tail inequality
STATEMENT_SOURCE: source/self-improvement.tex#eq:tailinequality@L125-L131
PROOF_SOURCE: source/self-improvement.tex#tail-average-proof@L78-L131
CONTRACT_ID: selfimprovement.tailinequality
CONTRACT_VERSION: 1
SOURCE_HYPOTHESES: fixed-ball setting; 0<t≤1/4
SOURCE_QUANTIFIERS: ∀ t with 0<t≤1/4
SOURCE_CONCLUSION: Φ(t) ≤ c_*E(4t)+4^nℬt^σ, where c_*=4^nK
CONSTANT_SCOPE: c_* depends exactly on n,K
FROZEN_FILE: -
FROZEN_DECL: -
FROZEN_ANCHOR_ID: -
FROZEN_ABI_SHA256: -
DEPS: averaged-lower-bound, averaged-upper-bounds
ROUTES: -
ROUTE_FOR: -
EDGE: averaged-lower-bound | source/self-improvement.tex#eq:tailinequality@L125-L130 | dividing the averaged inequality by volume(B_t) uses its lower bound
EDGE: averaged-upper-bounds | source/self-improvement.tex#eq:tailinequality@L125-L130 | dividing the averaged inequality by volume(B_t) uses both upper bounds
TOPOLOGY_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review
LEAN_STATUS: NOT_STARTED
LEAN_REF: -
LEAN_NOTE: -
NOTE: -

NODE: tailintegration
KIND: step
TITLE: Integrated scale recurrence
STATEMENT_SOURCE: source/self-improvement.tex#eq:tailintegration@L132-L153
PROOF_SOURCE: source/self-improvement.tex#eq:tailintegration@L132-L153
CONTRACT_ID: selfimprovement.tailintegration
CONTRACT_VERSION: 1
SOURCE_HYPOTHESES: fixed-ball setting; 0<r≤1/16
SOURCE_QUANTIFIERS: ∀ r with 0<r≤1/16
SOURCE_CONCLUSION: (log 4)Φ(r) ≤ c_*[Φ(16r)-Φ(r)]+c(n,σ)ℬr^σ
CONSTANT_SCOPE: c_* depends on n,K; error constant depends only on n,σ
FROZEN_FILE: -
FROZEN_DECL: -
FROZEN_ANCHOR_ID: -
FROZEN_ABI_SHA256: -
DEPS: tailinequality, tailfinite
ROUTES: -
ROUTE_FOR: -
EDGE: tailinequality | source/self-improvement.tex#eq:tailintegration@L132-L145 | integrates the one-scale inequality over r<t<4r
EDGE: tailfinite | source/self-improvement.tex#eq:tailintegration@L140-L152 | uses monotonicity of Φ and its integral identities
TOPOLOGY_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review
LEAN_STATUS: NOT_STARTED
LEAN_REF: -
LEAN_NOTE: -
NOTE: -

NODE: contract
KIND: step
TITLE: Hole-filling contraction
STATEMENT_SOURCE: source/self-improvement.tex#contract@L154-L160
PROOF_SOURCE: source/self-improvement.tex#contract@L154-L160
CONTRACT_ID: selfimprovement.contraction
CONTRACT_VERSION: 1
SOURCE_HYPOTHESES: fixed-ball setting; 0<r≤1/16
SOURCE_QUANTIFIERS: ∀ r with 0<r≤1/16
SOURCE_CONCLUSION: Φ(r) ≤ θΦ(16r)+cℬr^σ, θ=c_*/(c_*+log 4)<1
CONSTANT_SCOPE: θ depends exactly on n,K; c depends on n,K,σ
FROZEN_FILE: -
FROZEN_DECL: -
FROZEN_ANCHOR_ID: -
FROZEN_ABI_SHA256: -
DEPS: tailintegration
ROUTES: -
ROUTE_FOR: -
EDGE: tailintegration | source/self-improvement.tex#contract@L154-L159 | algebraically rearranges the integrated recurrence into a contraction
TOPOLOGY_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review
LEAN_STATUS: NOT_STARTED
LEAN_REF: -
LEAN_NOTE: -
NOTE: The named classical hole-filling step is the displayed algebraic rearrangement here; the subsequent iteration is represented separately.

NODE: discrete-tail-decay
KIND: step
TITLE: Iteration on dyadic-sixteen scales
STATEMENT_SOURCE: source/self-improvement.tex#discrete-tail-decay@L161-L169
PROOF_SOURCE: source/self-improvement.tex#discrete-tail-decay@L161-L169
CONTRACT_ID: selfimprovement.discrete-tail-decay
CONTRACT_VERSION: 1
SOURCE_HYPOTHESES: 0<γ<min{β,σ}
SOURCE_QUANTIFIERS: ∀ k≥0; ∀ γ with 0<γ<min{β,σ}
SOURCE_CONCLUSION: setting β=log(1/θ)/log16=2s₀ and r_k=16^{-k}, Φ(r_k)≤θ^kΦ(1)+cℬΣ_{j=1}^kθ^{k-j}16^{-jσ}, and the geometric sum is ≤c_γ r_k^γ
CONSTANT_SCOPE: c_γ depends on n,K,σ,γ through θ and the geometric sum
FROZEN_FILE: -
FROZEN_DECL: -
FROZEN_ANCHOR_ID: -
FROZEN_ABI_SHA256: -
DEPS: contract
ROUTES: -
ROUTE_FOR: -
EDGE: contract | source/self-improvement.tex#discrete-tail-decay@L161-L169 | iterates the contraction at r_k=16^{-k}
TOPOLOGY_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review
LEAN_STATUS: NOT_STARTED
LEAN_REF: -
LEAN_NOTE: -
NOTE: -

NODE: continuous-tail-decay
KIND: step
TITLE: Continuous-scale tail decay
STATEMENT_SOURCE: source/self-improvement.tex#continuous-tail-decay@L170-L176
PROOF_SOURCE: source/self-improvement.tex#continuous-tail-decay@L170-L176
CONTRACT_ID: selfimprovement.continuous-tail-decay
CONTRACT_VERSION: 1
SOURCE_HYPOTHESES: 0<γ<min{2s₀,σ}; 0<r≤1
SOURCE_QUANTIFIERS: ∀ γ in the stated interval; ∀ r with 0<r≤1
SOURCE_CONCLUSION: Φ(r)≤c_γ𝒜r^γ
CONSTANT_SCOPE: c_γ depends on n,K,σ,γ
FROZEN_FILE: -
FROZEN_DECL: -
FROZEN_ANCHOR_ID: -
FROZEN_ABI_SHA256: -
DEPS: discrete-tail-decay, tailfinite
ROUTES: -
ROUTE_FOR: -
EDGE: discrete-tail-decay | source/self-improvement.tex#continuous-tail-decay@L170-L175 | transfers the discrete estimate to an arbitrary scale by monotonicity
EDGE: tailfinite | source/self-improvement.tex#continuous-tail-decay@L170-L175 | substitutes the initial bound Φ(1)≤c𝒜
TOPOLOGY_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review
LEAN_STATUS: NOT_STARTED
LEAN_REF: -
LEAN_NOTE: -
NOTE: -

NODE: weighted-oscillation-moment
KIND: step
TITLE: Weighted oscillation integral
STATEMENT_SOURCE: source/self-improvement.tex#weighted-oscillation-moment@L177-L184
PROOF_SOURCE: source/self-improvement.tex#weighted-oscillation-moment@L177-L184
CONTRACT_ID: selfimprovement.weighted-oscillation-moment
CONTRACT_VERSION: 1
SOURCE_HYPOTHESES: 0<s<min{s₀,σ/2}; choose γ with 2s<γ<min{2s₀,σ}
SOURCE_QUANTIFIERS: ∀ admissible s; ∃ admissible γ
SOURCE_CONCLUSION: ∫₀¹r^{-2s}dΦ(r)≤c(n,K,σ,s)𝒜
CONSTANT_SCOPE: final constant depends only on n,K,σ,s; γ is chosen from those parameters
FROZEN_FILE: -
FROZEN_DECL: -
FROZEN_ANCHOR_ID: -
FROZEN_ABI_SHA256: -
DEPS: continuous-tail-decay, tailfinite
ROUTES: -
ROUTE_FOR: -
EDGE: continuous-tail-decay | source/self-improvement.tex#weighted-oscillation-moment@L177-L183 | gives the vanishing boundary term and integrability after integration by parts
EDGE: tailfinite | source/self-improvement.tex#weighted-oscillation-moment@L181-L183 | supplies the Φ(1) endpoint term
TOPOLOGY_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review
LEAN_STATUS: NOT_STARTED
LEAN_REF: -
LEAN_NOTE: -
NOTE: -

NODE: dorronsoro-local-mean-oscillation
KIND: external
TITLE: Local Littlewood–Paley/Besov mean-oscillation characterization
STATEMENT_SOURCE: external:DorBesov#Theorems-1-and-2
PROOF_SOURCE: external:DorBesov#proof
CONTRACT_ID: external.dorronsoro.local-mean-oscillation
CONTRACT_VERSION: cited-1985
SOURCE_HYPOTHESES: exact hypotheses are not stated in the manuscript; the invocation has g∈L²_loc in the fixed-ball setting, 0<s<1, and a finite weighted mean-oscillation integral
SOURCE_QUANTIFIERS: exact external quantifier order is not stated in the manuscript
SOURCE_CONCLUSION: [g]²_{W^{s,2}(B₁)}≤c(n,s)(||g||²_{L²(B₂)}+∫₀¹r^{-2s}dΦ(r))
CONSTANT_SCOPE: c depends only on n,s
FROZEN_FILE: -
FROZEN_DECL: -
FROZEN_ANCHOR_ID: -
FROZEN_ABI_SHA256: -
DEPS: -
ROUTES: -
ROUTE_FOR: -
TOPOLOGY_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review
LEAN_STATUS: EXTERNAL
LEAN_REF: -
LEAN_NOTE: -
NOTE: SOURCE_GAP: the cited source is named only as Dorronsoro, Theorems 1 and 2; the manuscript does not state the exact localized theorem, its spatial domain for the oscillations sampled by Φ, a boundary-extension mechanism, or the normalization matching this displayed inequality.

NODE: fixed-ball-fractional
KIND: application
TITLE: Fixed-ball fractional estimate
STATEMENT_SOURCE: source/self-improvement.tex#fixed-ball-fractional@L185-L196
PROOF_SOURCE: source/self-improvement.tex#fixed-ball-fractional@L185-L196
CONTRACT_ID: selfimprovement.fixed-ball-fractional
CONTRACT_VERSION: 1
SOURCE_HYPOTHESES: fixed-ball setting; 0<s<min{s₀,σ/2}
SOURCE_QUANTIFIERS: ∀ admissible s
SOURCE_CONCLUSION: [g]²_{W^{s,2}(B₁)}≤c(n,K,σ,s)𝒜
CONSTANT_SCOPE: c depends only on n,K,σ,s
FROZEN_FILE: -
FROZEN_DECL: -
FROZEN_ANCHOR_ID: -
FROZEN_ABI_SHA256: -
DEPS: weighted-oscillation-moment, fractional-exponent-admissibility, dorronsoro-local-mean-oscillation
ROUTES: -
ROUTE_FOR: -
EDGE: weighted-oscillation-moment | source/self-improvement.tex#fixed-ball-fractional@L189-L194 | substitutes the weighted oscillation bound into the characterization
EDGE: fractional-exponent-admissibility | source/self-improvement.tex#fixed-ball-fractional@L185-L196 | discharges the 0<s<1 range required by the invoked fractional characterization
EDGE: dorronsoro-local-mean-oscillation | source/self-improvement.tex#fixed-ball-fractional@L185-L196 | invokes the cited local mean-oscillation characterization
TOPOLOGY_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review
LEAN_STATUS: NOT_STARTED
LEAN_REF: -
LEAN_NOTE: -
NOTE: -

NODE: fractional-exponent-admissibility
KIND: step
TITLE: Admissibility of the fractional exponent for the external characterization
STATEMENT_SOURCE: source/self-improvement.tex#eq:exponent@L22-L28
PROOF_SOURCE: source/self-improvement.tex#fixed-ball-fractional@L177-L196
CONTRACT_ID: selfimprovement.fractional-exponent-admissibility
CONTRACT_VERSION: 1
SOURCE_HYPOTHESES: n≥2; K≥1; s₀=log(1+log 4/(4^n K))/(2 log 16); 0<s<min{s₀,σ/2}
SOURCE_QUANTIFIERS: ∀ admissible n,K,σ,s
SOURCE_CONCLUSION: 0<s<1
CONSTANT_SCOPE: no new constants
FROZEN_FILE: -
FROZEN_DECL: -
FROZEN_ANCHOR_ID: -
FROZEN_ABI_SHA256: -
DEPS: -
ROUTES: -
ROUTE_FOR: -
TOPOLOGY_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review
LEAN_STATUS: NOT_STARTED
LEAN_REF: -
LEAN_NOTE: -
NOTE: SOURCE_GAP: the source invokes the standard characterization without checking from (4.2), n≥2, and K≥1 that the selected s lies in its stated 0<s<1 range.

NODE: scaled-data
KIND: definition
TITLE: Rescaled domain and data
STATEMENT_SOURCE: source/self-improvement.tex#scaled-data@L201-L209
PROOF_SOURCE: source/self-improvement.tex#scaled-data@L201-L213
CONTRACT_ID: selfimprovement.scaled-data
CONTRACT_VERSION: 1
SOURCE_HYPOTHESES: B(x₀,8R) compactly contained in Ω; 0<R≤1
SOURCE_QUANTIFIERS: ∀ admissible x₀,R
SOURCE_CONCLUSION: Ω_R=(Ω-x₀)/R, g_R(y)=g(x₀+Ry), μ_R(y)=μ(x₀+Ry), and B₈ compactly contained in Ω_R
CONSTANT_SCOPE: K,σ remain unchanged under scaling
FROZEN_FILE: -
FROZEN_DECL: -
FROZEN_ANCHOR_ID: -
FROZEN_ABI_SHA256: -
DEPS: -
ROUTES: -
ROUTE_FOR: -
TOPOLOGY_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review
LEAN_STATUS: NOT_STARTED
LEAN_REF: -
LEAN_NOTE: -
NOTE: -

NODE: scaled-oscillation-identity
KIND: step
TITLE: Mean oscillation is preserved by spatial scaling
STATEMENT_SOURCE: source/self-improvement.tex#scaled-oscillation-identity@L210-L214
PROOF_SOURCE: source/self-improvement.tex#scaled-oscillation-identity@L210-L214
CONTRACT_ID: selfimprovement.scaled-oscillation-identity
CONTRACT_VERSION: 1
SOURCE_HYPOTHESES: scaled data as defined; ρ>0
SOURCE_QUANTIFIERS: ∀ z and ρ>0
SOURCE_CONCLUSION: Hosc_{g_R}(z,ρ)=Hosc_g(x₀+Rz,Rρ)
CONSTANT_SCOPE: no new constants
FROZEN_FILE: -
FROZEN_DECL: -
FROZEN_ANCHOR_ID: -
FROZEN_ABI_SHA256: -
DEPS: scaled-data
ROUTES: -
ROUTE_FOR: -
EDGE: scaled-data | source/self-improvement.tex#scaled-oscillation-identity@L210-L214 | substitutes the definitions of g_R and the rescaled domain in the normalized mean oscillation
TOPOLOGY_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review
LEAN_STATUS: NOT_STARTED
LEAN_REF: -
LEAN_NOTE: -
NOTE: The source calls this a change-of-variables identity and displays its result without further calculation.

NODE: scaled-local-data-admissibility
KIND: step
TITLE: Local integrability and nonnegativity survive rescaling
STATEMENT_SOURCE: source/self-improvement.tex#scaled-data@L201-L209
PROOF_SOURCE: source/self-improvement.tex#apply-fixed-ball@L210-L235
CONTRACT_ID: selfimprovement.scaled-local-data-admissibility
CONTRACT_VERSION: 1
SOURCE_HYPOTHESES: g∈L²_loc(Ω;R^m); μ∈L¹_loc(Ω); μ≥0; Ω_R,g_R,μ_R are defined by the displayed affine rescaling; R>0
SOURCE_QUANTIFIERS: ∀ admissible x₀,R and rescaled compact subsets
SOURCE_CONCLUSION: g_R∈L²_loc(Ω_R;R^m), μ_R∈L¹_loc(Ω_R), and μ_R≥0 almost everywhere on Ω_R
CONSTANT_SCOPE: no new constants
FROZEN_FILE: -
FROZEN_DECL: -
FROZEN_ANCHOR_ID: -
FROZEN_ABI_SHA256: -
DEPS: scaled-data
ROUTES: -
ROUTE_FOR: -
EDGE: scaled-data | source/self-improvement.tex#apply-fixed-ball@L201-L235 | uses the affine definitions of Ω_R, g_R, and μ_R to transfer the local data hypotheses
TOPOLOGY_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review
LEAN_STATUS: NOT_STARTED
LEAN_REF: -
LEAN_NOTE: -
NOTE: SOURCE_GAP: the source reapplies Step 1 without stating the affine-pullback argument preserving local L²/L¹ membership and nonnegativity.

NODE: scaled-relative-hypothesis
KIND: step
TITLE: Relative hypothesis is preserved by scaling
STATEMENT_SOURCE: source/self-improvement.tex#scaled-relative-hypothesis@L210-L234
PROOF_SOURCE: source/self-improvement.tex#scaled-relative-hypothesis@L210-L234
CONTRACT_ID: selfimprovement.scaled-relative-hypothesis
CONTRACT_VERSION: 1
SOURCE_HYPOTHESES: B(z₀,4ρ) compactly contained in Ω_R; 0<ρ≤1
SOURCE_QUANTIFIERS: ∀ z₀,ρ satisfying the stated conditions
SOURCE_CONCLUSION: g_R,μ_R satisfy (4.1) with K,σ unchanged and M_R=MR^σ
CONSTANT_SCOPE: K and σ are unchanged; the new error coefficient is exactly MR^σ
FROZEN_FILE: -
FROZEN_DECL: -
FROZEN_ANCHOR_ID: -
FROZEN_ABI_SHA256: -
DEPS: scaled-data, scaled-oscillation-identity
ROUTES: -
ROUTE_FOR: -
EDGE: scaled-data | source/self-improvement.tex#scaled-relative-hypothesis@L210-L233 | uses the definitions of Ω_R, g_R, and μ_R, the ball/domain correspondence, and the integral change of variables
EDGE: scaled-oscillation-identity | source/self-improvement.tex#scaled-relative-hypothesis@L215-L227 | rewrites every oscillation term after applying (4.1) at centre x₀+Rz₀ and radius Rρ
TOPOLOGY_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review
LEAN_STATUS: NOT_STARTED
LEAN_REF: -
LEAN_NOTE: -
NOTE: -

NODE: apply-fixed-ball-after-scaling
KIND: application
TITLE: Apply the fixed-ball estimate to rescaled data
STATEMENT_SOURCE: source/self-improvement.tex#apply-fixed-ball@L235-L242
PROOF_SOURCE: source/self-improvement.tex#apply-fixed-ball@L235-L242
CONTRACT_ID: selfimprovement.apply-fixed-ball
CONTRACT_VERSION: 1
SOURCE_HYPOTHESES: scaled data satisfy (4.1) with M_R=MR^σ; 0<s<min{s₀,σ/2}
SOURCE_QUANTIFIERS: ∀ admissible x₀,R,s
SOURCE_CONCLUSION: [g_R]²_{W^{s,2}(B₁)}≤c[∫_{B₈}|g_R|²+MR^σ∫_{B₈}μ_R]
CONSTANT_SCOPE: c depends only on n,K,σ,s
FROZEN_FILE: -
FROZEN_DECL: -
FROZEN_ANCHOR_ID: -
FROZEN_ABI_SHA256: -
DEPS: scaled-relative-hypothesis, scaled-local-data-admissibility, fixed-ball-fractional
ROUTES: -
ROUTE_FOR: -
EDGE: scaled-relative-hypothesis | source/self-improvement.tex#apply-fixed-ball@L235-L241 | discharges the conditional hypothesis for the rescaled data
EDGE: scaled-local-data-admissibility | source/self-improvement.tex#apply-fixed-ball@L235-L241 | discharges the rescaled local L²/L¹ and nonnegativity premises of Step 1
EDGE: fixed-ball-fractional | source/self-improvement.tex#apply-fixed-ball@L235-L241 | invokes Step 1 on g_R,μ_R,M_R
TOPOLOGY_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review
LEAN_STATUS: NOT_STARTED
LEAN_REF: -
LEAN_NOTE: -
NOTE: -

NODE: final-rescaling-estimate
KIND: step
TITLE: Rescale the fractional estimate back
STATEMENT_SOURCE: source/self-improvement.tex#final-rescaling@L243-L243
PROOF_SOURCE: source/self-improvement.tex#final-rescaling@L243-L243
CONTRACT_ID: selfimprovement.final-rescaling
CONTRACT_VERSION: 1
SOURCE_HYPOTHESES: B(x₀,8R) compactly contained in Ω; 0<R≤1; rescaled fixed-ball estimate
SOURCE_QUANTIFIERS: ∀ admissible x₀,R,s
SOURCE_CONCLUSION: [g]²_{W^{s,2}(B(x₀,R))}≤cR^{-2s}[∫_{B(x₀,8R)}|g|²+MR^σ∫_{B(x₀,8R)}μ]
CONSTANT_SCOPE: c depends only on n,K,σ,s
FROZEN_FILE: -
FROZEN_DECL: -
FROZEN_ANCHOR_ID: -
FROZEN_ABI_SHA256: -
DEPS: apply-fixed-ball-after-scaling, scaled-data
ROUTES: -
ROUTE_FOR: -
EDGE: apply-fixed-ball-after-scaling | source/self-improvement.tex#final-rescaling@L243-L243 | rescales the established unit-ball inequality
EDGE: scaled-data | source/self-improvement.tex#final-rescaling@L243-L243 | uses the definitions of g_R, μ_R and Ω_R in the change of variables
TOPOLOGY_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review
LEAN_STATUS: NOT_STARTED
LEAN_REF: -
LEAN_NOTE: -
NOTE: SOURCE_GAP: the source asserts “Rescaling back” without displaying the fractional-seminorm and integral scaling identities, including the R^{n-2s} cancellation.

NODE: local-compact-membership
KIND: step
TITLE: Pass from ball estimates to local compact-set membership
STATEMENT_SOURCE: source/self-improvement.tex#lemma-conclusion@L27-L38
PROOF_SOURCE: source/self-improvement.tex#proof-close@L235-L244
CONTRACT_ID: selfimprovement.local-compact-membership
CONTRACT_VERSION: 1
SOURCE_HYPOTHESES: Ω open; quantitative estimate holds on every ball B(x₀,R) with B(x₀,8R) compactly contained in Ω
SOURCE_QUANTIFIERS: ∀ compact A⊆Ω
SOURCE_CONCLUSION: [g]_{W^{s,2}(A)} is finite, hence g∈W^{s,2}_loc(Ω;R^m)
CONSTANT_SCOPE: no uniform compact-set constant is stated
FROZEN_FILE: -
FROZEN_DECL: -
FROZEN_ANCHOR_ID: -
FROZEN_ABI_SHA256: -
DEPS: final-rescaling-estimate
ROUTES: -
ROUTE_FOR: -
EDGE: final-rescaling-estimate | source/self-improvement.tex#proof-close@L235-L244 | the omitted localization step must derive compact-set finiteness from the family of ball estimates
TOPOLOGY_STATUS: REVIEWED
EXTRACTOR: section4_graph
REVIEWER: section4_graph_local_review
LEAN_STATUS: NOT_STARTED
LEAN_REF: -
LEAN_NOTE: -
NOTE: SOURCE_GAP: the proof ends after the ball estimate and does not supply the finite-cover/partition argument needed for the separately stated compact-set local-membership conclusion, including cross-ball pairs in the fractional energy.

<!-- BEGIN PROOF DEPGRAPH GENERATED -->
Regenerated by `proof_depgraph.py`; do not hand-edit.

### Dashboard

* Total nodes: **21**
* Frozen anchors: **1**
* Versioned statement contracts: **21**
* Total edges: **28**
* Root-closure nodes: **21**
* Dependency leaves in root closure: **4**
* Assumption boundary leaves: **0**
* External boundary leaves: **1**
* Alternative routes: **0**
* Topology review queue: **0**
* Explicit source gaps: **5**
* Coverage items: **36**; excluded: **7**

### Roots

* `selfimprovement` [REVIEWED; frozen] — contract `mean-oscillation-self-improvement@1`

### Topology review queue

* _(none)_

### Dependency leaves in root closure

* `dorronsoro-local-mean-oscillation` [REVIEWED] — Local Littlewood–Paley/Besov mean-oscillation characterization
* `fractional-exponent-admissibility` [REVIEWED] — Admissibility of the fractional exponent for the external characterization
* `oscillation-tail-definitions` [REVIEWED] — Fixed-ball tail quantities
* `scaled-data` [REVIEWED] — Rescaled domain and data

### Assumption boundary leaves

* _(none)_

### External boundary leaves

* `dorronsoro-local-mean-oscillation` [REVIEWED] — Local Littlewood–Paley/Besov mean-oscillation characterization

### Uncovered graph nodes

* _(none)_

### Nodes outside every root closure

* _(none)_

### Explicit source gaps

* `dorronsoro-local-mean-oscillation` [REVIEWED] — Local Littlewood–Paley/Besov mean-oscillation characterization
* `final-rescaling-estimate` [REVIEWED] — Rescale the fractional estimate back
* `fractional-exponent-admissibility` [REVIEWED] — Admissibility of the fractional exponent for the external characterization
* `local-compact-membership` [REVIEWED] — Pass from ball estimates to local compact-set membership
* `scaled-local-data-admissibility` [REVIEWED] — Local integrability and nonnegativity survive rescaling
<!-- END PROOF DEPGRAPH GENERATED -->
