#!/usr/bin/env python3
"""Fail-closed frozen-anchor and quarantine policy checks."""
from pathlib import Path
import hashlib
import json
import re


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def strip_comments(text):
    depth, i, out = 0, 0, []
    while i < len(text):
        pair = text[i:i + 2]
        if pair == "/-": depth += 1; i += 2
        elif depth and pair == "-/": depth -= 1; i += 2
        elif depth: i += 1
        elif pair == "--":
            i = text.find("\n", i)
            if i == -1: break
        else: out.append(text[i]); i += 1
    require(depth == 0, "Unclosed block comment")
    return "".join(out)


def imports(text):
    result = set()
    for line in strip_comments(text).splitlines():
        match = re.match(r"^\s*(?:(?:public|private)\s+)?import\s+(.+?)\s*$", line)
        if match:
            names = match.group(1).split()
            require(all(re.fullmatch(r"[A-Za-z0-9_.]+", name) for name in names),
                    "Unsupported import syntax requires explicit policy review")
            result.update(names)
    return result


FORBIDDEN = re.compile(r"\b(sorry|admit|axiom|sorryAx|unsafe|native_decide)\b")
SELF_IMPROVEMENT_APPROVED_SHA256 = "58cc205979733e42ab1153778ef4be714b341359a4703a04a35243aed47f49c2"
SELF_IMPROVEMENT_ABI_SHA256 = "d674c7a7c39e732be5b485fd2f30c7b0b6de0be5b33c17b71616a2a5d9ac0086"
SELF_IMPROVEMENT_SOURCE_SHA256 = "7f218e9763a8e92c344ec7e1f6a7d1d6b0ea5ca81fae924d7d237903c92a3644"
SELF_IMPROVEMENT_SEALED_BODY = ("by\n  exact Internal.meanOscillation_selfImprovement "
                                "n hn K σ s hK hσ hs hs_upper")


def validate_anchor_bytes(anchor, frozen_bytes, approved_bytes):
    """Validate the only permitted draft-to-sealed byte transition."""
    require(sha(approved_bytes) == anchor["author_approval"]["command_sha256"],
            "Approved command hash mismatch")
    allowed = anchor["allowed_body"].encode()
    require(approved_bytes.count(allowed) == 1, "Approved command lacks its unique registered body")
    if anchor["state"] == "DRAFT_SORRY":
        require(sha(frozen_bytes) == anchor["frozen_file_sha256"], "Draft frozen bytes changed")
        require(frozen_bytes == approved_bytes, "Frozen draft differs byte-for-byte from approved command")
        return "DRAFT_SORRY"
    require(anchor["state"] == "PROVED", f"Unsupported anchor state: {anchor['state']}")
    sealed_body = anchor["expected_sealed_proof_body"].encode()
    expected = approved_bytes.replace(allowed, sealed_body)
    require(frozen_bytes == expected, "Sealed file is not the approved command with only its body replaced")
    require(sha(frozen_bytes) == anchor["sealed_file_sha256"], "Sealed frozen bytes/hash mismatch")
    require(anchor.get("proof_status") == "PROVED", "Sealed anchor proof status mismatch")
    return "PROVED"


def validate_marker_policy(path, text, draft_path=None, allowed_body=None):
    code = strip_comments(text)
    markers = list(FORBIDDEN.finditer(code))
    if path == draft_path:
        require(allowed_body is not None and code.count(allowed_body) == 1,
                f"Draft body mismatch in {path}")
        require([m.group(0) for m in markers] == ["sorry"],
                f"Unauthorized trust marker in {path}")
    else:
        require(not markers, f"Forbidden proof/trust marker in {path}")
    require(not re.search(r"set_option\s+.*(?:maxHeartbeats|maxRecDepth)", code),
            f"Budget override in {path}")


def validate_import_policy(module_text, forbidden_modules, exceptions):
    graph = {module: imports(text) for module, text in module_text.items()}
    for module, direct in graph.items():
        bad = (direct & forbidden_modules) - exceptions.get(module, set())
        require(not bad, f"Prohibited direct import by {module}: {sorted(bad)}")
    for origin in graph:
        if origin in forbidden_modules: continue
        seen, todo = set(), list(graph[origin])
        while todo:
            target = todo.pop()
            if target in seen: continue
            seen.add(target)
            if target in forbidden_modules and target not in exceptions.get(origin, set()):
                raise RuntimeError(f"Prohibited transitive import by {origin}: {target}")
            todo.extend(graph.get(target, ()))


def validate(root):
    manifest = json.loads((root / "frozen-manifest.json").read_text())
    anchors = manifest["anchors"]
    frozen_paths = sorted(p.relative_to(root).as_posix() for p in (root / "Frozen").rglob("*.lean"))
    owner_paths = [a["path"] for a in anchors]
    require(len(owner_paths) == len(set(owner_paths)), "Duplicate frozen path owner")
    require(len({a["id"] for a in anchors}) == len(anchors), "Duplicate anchor id")
    require(len({a["export"] for a in anchors}) == len(anchors), "Duplicate frozen export")
    require(sorted(owner_paths) == frozen_paths,
            f"Every Frozen file needs exactly one owner: {set(owner_paths) ^ set(frozen_paths)}")
    targets = [a for a in anchors if a["id"] == "self-improvement-v1"]
    require(len(targets) == 1, "Expected exactly one self-improvement-v1 owner")
    target = targets[0]
    require(target["author_approval"]["command_sha256"] == SELF_IMPROVEMENT_APPROVED_SHA256,
            "Self-improvement approval identity changed")
    require(target["abi_sha256"] == SELF_IMPROVEMENT_ABI_SHA256,
            "Self-improvement approved ABI identity changed")
    require(target["allowed_body"] == "by\n  sorry", "Registered draft body changed")
    if target["state"] == "PROVED":
        require(target["expected_sealed_proof_body"] == SELF_IMPROVEMENT_SEALED_BODY,
                "Registered sealed proof body changed")
    target_path = root / target["path"]
    approved = (root / target["approved_command_path"]).read_bytes()
    state = validate_anchor_bytes(target, target_path.read_bytes(), approved)
    source = target["source"]
    require(source["sha256"] == SELF_IMPROVEMENT_SOURCE_SHA256,
            "Self-improvement source identity changed")
    require(sha((root / source["path"]).read_bytes()) == source["sha256"], "Pinned source changed")
    all_files = sorted((root / "AffineCarleson").rglob("*.lean"))
    all_files += sorted((root / "Frozen").rglob("*.lean"))
    all_files += [root / "AffineCarleson.lean"]
    draft_rel = target_path.relative_to(root).as_posix() if state == "DRAFT_SORRY" else None
    for path in all_files:
        validate_marker_policy(path.relative_to(root).as_posix(), path.read_text(),
                               draft_rel, target["allowed_body"])
    module_text = {p.relative_to(root).with_suffix("").as_posix().replace("/", "."): p.read_text()
                   for p in all_files}
    if state == "DRAFT_SORRY":
        forbidden = {target["quarantine"]["frozen_module"], target["provider_module"]}
        validate_import_policy(module_text, forbidden,
                               {target["quarantine"]["frozen_module"]: {target["provider_module"]}})
    else:
        validate_import_policy(module_text, set(), {})
        graph = {module: imports(text) for module, text in module_text.items()}
        seen, todo = set(), list(graph.get("AffineCarleson", ()))
        while todo:
            module = todo.pop()
            if module in seen: continue
            seen.add(module); todo.extend(graph.get(module, ()))
        require({"Frozen.SelfImprovement", target["provider_module"]} <= seen,
                "Sealed theorem/provider are omitted from the production aggregate closure")
    return manifest, all_files, target


def negative_regressions():
    rejected = []
    for name, action in (
        ("unregistered_sorry", lambda: validate_marker_policy("X.lean", "theorem x : True := by sorry")),
        ("prohibited_import", lambda: validate_import_policy(
            {"Production": "import Frozen.SelfImprovement\n", "Frozen.SelfImprovement": ""},
            {"Frozen.SelfImprovement"}, {})),
        ("multi_module_import", lambda: validate_import_policy(
            {"Production": "import Mathlib Frozen.SelfImprovement\n"},
            {"Frozen.SelfImprovement"}, {})),
        ("transitive_provider_import", lambda: validate_import_policy(
            {"Production": "import Intermediate\n",
             "Intermediate": "import AffineCarleson.SelfImprovement.Proof\n"},
            {"AffineCarleson.SelfImprovement.Proof"}, {})),
    ):
        try: action()
        except RuntimeError: rejected.append(name)
    require(rejected == ["unregistered_sorry", "prohibited_import", "multi_module_import",
                         "transitive_provider_import"], "Negative regression passed")
    approved = b"theorem t : True := by\n  sorry\n"
    base = {"allowed_body": "by\n  sorry", "author_approval": {"command_sha256": sha(approved)},
            "frozen_file_sha256": sha(approved), "proof_status": "FROZEN_UNPROVED"}
    require(validate_anchor_bytes({**base, "state": "DRAFT_SORRY"}, approved, approved) ==
            "DRAFT_SORRY", "Synthetic draft state failed")
    sealed_body = "by\n  exact True.intro"
    sealed = approved.replace(base["allowed_body"].encode(), sealed_body.encode())
    proved = {**base, "state": "PROVED", "proof_status": "PROVED",
              "expected_sealed_proof_body": sealed_body, "sealed_file_sha256": sha(sealed)}
    require(validate_anchor_bytes(proved, sealed, approved) == "PROVED", "Synthetic seal failed")
    try:
        validate_anchor_bytes(proved, sealed.replace(b"True.intro", b"by trivial"), approved)
        raise RuntimeError("Unauthorized synthetic sealed body passed")
    except RuntimeError as error:
        require(str(error) != "Unauthorized synthetic sealed body passed",
                "Unauthorized synthetic sealed body passed")
    rejected.append("unauthorized_sealed_body")
    return rejected
