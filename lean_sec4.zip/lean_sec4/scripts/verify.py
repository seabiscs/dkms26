#!/usr/bin/env python3
"""Verify the project in either registered draft or exactly sealed state."""
from pathlib import Path
import argparse, json, os, re, subprocess, tempfile
from check_frozen import negative_regressions, require, sha, validate

ROOT = Path(__file__).resolve().parents[1]


def run(args, allowed_warning=None):
    result = subprocess.run(args, cwd=ROOT, text=True, capture_output=True,
                            env={**os.environ, "LEAN_NUM_THREADS": "2"})
    output = result.stdout + result.stderr
    require(result.returncode == 0, f"Command failed: {' '.join(args)}\n{output}")
    warnings = re.findall(r"^.*warning:.*$", output, re.M)
    if allowed_warning is None:
        require(not warnings, f"Compiler warning:\n{output}")
    else:
        require(len(warnings) == 1 and re.search(allowed_warning, warnings[0]),
                f"Expected exactly one matching draft warning, got:\n{output}")
    return output


def module_name(path):
    return path.relative_to(ROOT).with_suffix("").as_posix().replace("/", ".")


def temp_lean(code):
    f = tempfile.NamedTemporaryFile(mode="w", suffix=".lean", prefix="VerificationProbe",
                                    dir=ROOT, encoding="utf-8", delete=False)
    f.write(code); f.close()
    return Path(f.name)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-directory", type=Path, default=ROOT / "verification-output")
    args = parser.parse_args()
    output_dir = args.output_directory.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "summary.json").unlink(missing_ok=True)
    frozen_manifest, all_files, target = validate(ROOT)
    regressions = negative_regressions()
    manifest = json.loads((ROOT / "verification-manifest.json").read_text())
    is_draft = target["state"] == "DRAFT_SORRY"
    expected_release_state = "FROZEN_UNPROVED" if is_draft else "PROVED"
    require(manifest["new_source"]["state"] == expected_release_state, "Release/anchor state mismatch")
    require(manifest["new_source"]["source_theorem_proved"] is (not is_draft),
            "Release proof flag/anchor state mismatch")
    require(manifest["new_source"]["anchor_id"] == target["id"], "Target anchor mismatch")
    require((ROOT / "lean-toolchain").read_text().strip() == manifest["toolchain"], "Toolchain changed")
    lock = json.loads((ROOT / "lake-manifest.json").read_text())
    locked_mathlib = next(p for p in lock["packages"] if p["name"] == "mathlib")
    require(locked_mathlib["rev"] == manifest["mathlib_revision"], "Mathlib lock changed")
    mathlib = ROOT / ".lake/packages/mathlib"
    require(mathlib.exists(), "Pinned Mathlib checkout is missing")
    require(run(["git", "-C", str(mathlib), "rev-parse", "HEAD"]).strip() ==
            manifest["mathlib_revision"], "Mathlib checkout differs from pin")
    require(not run(["git", "-C", str(mathlib), "status", "--porcelain=v1",
                     "--untracked-files=no"]).strip(), "Mathlib tracked sources are modified")
    inherited = next(a for a in frozen_manifest["anchors"] if a["id"] == manifest["inherited_anchor_id"])
    inherited_file = ROOT / inherited["path"]
    require(sha(inherited_file.read_bytes()) == inherited["release_file_sha256"], "Inherited theorem changed")
    statement_path = ROOT / inherited["approved_statement_path"]
    require(sha(statement_path.read_bytes()) == inherited["approved_statement_sha256"], "Approved statement changed")
    frozen_text = inherited_file.read_text()
    actual = frozen_text[frozen_text.index("theorem affine_projection_characterization"):frozen_text.rindex(" := by")]
    require(actual == statement_path.read_text().rstrip("\n"), "Inherited public statement changed")

    forbidden = ({target["quarantine"]["frozen_module"], target["provider_module"]}
                 if is_draft else set())
    proved_files = [p for p in all_files if module_name(p) not in forbidden]
    proved_modules = {module_name(p) for p in proved_files}
    print("Building every proved project module...", flush=True)
    (output_dir / "build.log").write_text(run(["lake", "build", *sorted(proved_modules)]))
    if is_draft:
        print("Compiling the quarantined draft with its single expected warning...", flush=True)
        (output_dir / "draft-build.log").write_text(
            run(["lake", "env", "lean", target["path"]], r"declaration uses [`']sorry[`']"))

    proved_imports = "\n".join(f"import {module}" for module in sorted(proved_modules))
    probe = f'''{proved_imports}
run_cmd do
  let ci ← Lean.getConstInfo `{inherited["export"]}
  Lean.logInfo s!"INHERITED_TYPE_BEGIN\\n{{repr ci.type}}\\nINHERITED_TYPE_END"
run_cmd do
  let env ← Lean.getEnv
  for mod in env.header.moduleNames do
    if (`AffineCarleson).isPrefixOf mod || (`Frozen).isPrefixOf mod then
      Lean.logInfo s!"PROJECT_MODULE|{{mod}}"
  for (name, _) in env.constants do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.header.moduleNames[idx.toNat]!
      if (`AffineCarleson).isPrefixOf mod || (`Frozen).isPrefixOf mod then
        let axioms ← Lean.collectAxioms name
        for ax in axioms do
          unless ax == `propext || ax == `Classical.choice || ax == `Quot.sound do
            throwError "Unapproved axiom {{ax}} in {{name}}"
        Lean.logInfo s!"AXIOM_CENSUS|{{mod}}|{{name}}|{{axioms.toList}}"
'''
    temporary = temp_lean(probe)
    try: audit = run(["lake", "env", "lean", str(temporary)])
    finally: temporary.unlink(missing_ok=True)
    raw_type = audit.split("INHERITED_TYPE_BEGIN\n", 1)[1].split("\nINHERITED_TYPE_END", 1)[0]
    require(sha(raw_type.encode()) == inherited["abi_sha256"], "Inherited theorem ABI changed")
    imported = set(re.findall(r"^PROJECT_MODULE\|(.+)$", audit, re.M))
    require(imported == proved_modules, f"Proved import inventory mismatch: {imported ^ proved_modules}")
    census = re.findall(r"^AXIOM_CENSUS\|(.+)$", audit, re.M)
    require(any(f"|{inherited['export']}|" in row for row in census), "Inherited export absent")
    (output_dir / "axioms.tsv").write_text("module|declaration|axioms\n" + "\n".join(sorted(census)) + "\n")

    target_module = Path(target["path"]).with_suffix("").as_posix().replace("/", ".")
    target_probe = f'''import {target_module}
run_cmd do
  let ci ← Lean.getConstInfo `{target["export"]}
  Lean.logInfo s!"TARGET_TYPE_BEGIN\\n{{repr ci.type}}\\nTARGET_TYPE_END"
  let axioms ← Lean.collectAxioms `{target["export"]}
  Lean.logInfo s!"TARGET_AXIOMS|{{axioms.toList}}"
'''
    temporary = temp_lean(target_probe)
    try: target_audit = run(["lake", "env", "lean", str(temporary)])
    finally: temporary.unlink(missing_ok=True)
    target_type = target_audit.split("TARGET_TYPE_BEGIN\n", 1)[1].split("\nTARGET_TYPE_END", 1)[0]
    require(sha(target_type.encode()) == target["abi_sha256"], "Self-improvement theorem ABI changed")
    target_axioms = re.search(r"^TARGET_AXIOMS\|(.+)$", target_audit, re.M)
    require(target_axioms, "Self-improvement axiom report absent")
    if is_draft:
        require("sorryAx" in target_axioms.group(1), "Expected draft sorryAx absent")
        (output_dir / "draft-axioms.log").write_text(target_audit)
    else:
        require("sorryAx" not in target_axioms.group(1), "Sealed theorem retains sorryAx")
        require(any(f"|{target['export']}|" in row for row in census), "Sealed export absent from census")
        (output_dir / "sealed-axioms.log").write_text(target_audit)

    print("Replaying only proved project modules with Lean's kernel checker...", flush=True)
    replay = run(["lake", "env", "leanchecker", "--verbose", *sorted(proved_modules)])
    (output_dir / "kernel-replay.log").write_text(replay)
    replayed = set(re.findall(r"^replaying (.+)$", replay, re.M)) & proved_modules
    require(replayed == proved_modules, f"Proved kernel replay mismatch: {replayed ^ proved_modules}")
    summary = {
        "result": "PASS", "verification_scope": ("All proved modules plus draft identity/elaboration"
            if is_draft else "All project modules including the sealed theorem and provider"),
        "DRAFT_ANCHORS": 1 if is_draft else 0, "PROVED_ANCHORS": 1 if is_draft else 2,
        "UNREGISTERED_SORRIES": 0, "DRAFT_IMPORT_VIOLATIONS": 0, "SEALED_THIS_TURN": 0 if is_draft else 1,
        "self_improvement_anchor": target["path"], "self_improvement_proof_status": expected_release_state,
        "declaration_fidelity": "PASS", "draft_allowlist": "PASS" if is_draft else "N/A_PROVED",
        "self_improvement_abi_sha256": target["abi_sha256"],
        "draft_expected_sorryAx_observed": True if is_draft else False,
        "self_improvement_axiom_closure": "NOT_RUN_NOT_PROVED" if is_draft else "PASS",
        "inherited_proved_anchor_unchanged": "PASS", "inherited_abi_sha256": inherited["abi_sha256"],
        "proved_modules": len(proved_modules), "proved_declarations_checked_including_generated": len(census),
        "proved_axiom_census": "PASS", "proved_kernel_replay": "PASS",
        "negative_regressions": {name: "REJECTED_AS_EXPECTED" for name in regressions},
        "toolchain": manifest["toolchain"], "mathlib_revision": manifest["mathlib_revision"],
        "module_sha256": {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in all_files}}
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__": main()
