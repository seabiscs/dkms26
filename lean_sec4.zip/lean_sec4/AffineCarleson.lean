import Frozen.AffineProjection
import Frozen.SelfImprovement
import AffineCarleson.AffineReproduction
import AffineCarleson.AffineDifferentiation
import AffineCarleson.SelfImprovement

/-! Audited affine projection and mean-oscillation self-improvement. -/
