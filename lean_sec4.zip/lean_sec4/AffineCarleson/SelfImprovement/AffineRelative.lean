import AffineCarleson.SelfImprovement.AffineIntegral
import AffineCarleson.SelfImprovement.BallMeasurability
import AffineCarleson.SelfImprovement.RadiusChangeVariables
import Mathlib.MeasureTheory.Measure.Prod

/-! Exact affine transport of the relative oscillation estimate. -/

noncomputable section
set_option autoImplicit false

open Set MeasureTheory
open scoped ENNReal

namespace AffineCarleson.Internal

theorem relativeOscillationLIntegral_affineScale {n m : ℕ}
    (g : (Fin n → ℝ) → Fin m → ℝ)
    (hg : ∀ i, Measurable (fun y ↦ g y i)) (x₀ c : Fin n → ℝ)
    {R t : ℝ} (hR : 0 < R) :
    (∫⁻ x in ballSet c t, ∫⁻ r in Ioo (0 : ℝ) t,
      ENNReal.ofReal
        (ballOscillation x r (fun y ↦ g (fun i ↦ x₀ i + R * y i)) / r)) =
      ENNReal.ofReal (R ^ n)⁻¹ *
        ∫⁻ x in ballSet (fun i ↦ x₀ i + R * c i) (R * t),
          ∫⁻ r in Ioo (0 : ℝ) (R * t),
            ENNReal.ofReal (ballOscillation x r g / r) := by
  let T : (Fin n → ℝ) → (Fin n → ℝ) := fun y i ↦ x₀ i + R * y i
  let F : (Fin n → ℝ) → ENNReal := fun x ↦
    ∫⁻ r in Ioo (0 : ℝ) (R * t), ENNReal.ofReal (ballOscillation x r g / r)
  have hball := measurable_ballOscillation g hg
  have hosc : Measurable (fun p : (Fin n → ℝ) × ℝ ↦
      ENNReal.ofReal (ballOscillation p.1 p.2 g / p.2)) :=
    (hball.div measurable_snd).ennreal_ofReal
  have hF : Measurable F := by
    let Q : (Fin n → ℝ) × ℝ → ENNReal := fun p ↦
      if p.2 ∈ Ioo (0 : ℝ) (R * t)
      then ENNReal.ofReal (ballOscillation p.1 p.2 g / p.2) else 0
    have hQ : Measurable Q := by
      exact hosc.ite (measurableSet_Ioo.preimage measurable_snd) measurable_const
    have hm : Measurable (fun x : Fin n → ℝ ↦ ∫⁻ r : ℝ, Q (x, r)) :=
      hQ.lintegral_prod_right'
    convert hm using 1
    funext x
    dsimp only [F, Q]
    rw [← lintegral_indicator measurableSet_Ioo]
    apply lintegral_congr
    intro r
    simp only [indicator_apply]
  have hradius (x : Fin n → ℝ) :
      (∫⁻ r in Ioo (0 : ℝ) t,
        ENNReal.ofReal
          (ballOscillation x r (fun y ↦ g (T y)) / r)) = F (T x) := by
    have hp : Measurable (fun r : ℝ ↦ (T x, r)) :=
      measurable_const.prodMk measurable_id
    have hHcomp : Measurable
        ((fun p : (Fin n → ℝ) × ℝ ↦ ballOscillation p.1 p.2 g) ∘
          fun r : ℝ ↦ (T x, r)) := hball.comp hp
    have hH : Measurable (fun r ↦ ballOscillation (T x) r g) := hHcomp
    have hs := radius_lintegral_div_scale
      (fun r ↦ ballOscillation (T x) r g) hH hR t
    calc
      _ = ∫⁻ r in Ioo (0 : ℝ) t,
          ENNReal.ofReal (ballOscillation (T x) (R * r) g / r) := by
        apply setLIntegral_congr_fun measurableSet_Ioo
        intro r hr
        change ENNReal.ofReal
          (ballOscillation x r (fun y ↦ g (fun i ↦ x₀ i + R * y i)) / r) = _
        rw [ballOscillation_affineScale g x₀ x hR hr.1]
      _ = F (T x) := hs
  calc
    _ = ∫⁻ x in ballSet c t, F (T x) := lintegral_congr hradius
    _ = _ := setLIntegral_affineScale F hF x₀ c hR

theorem relativeOscillation_le_affineScale {n m : ℕ}
    (g : (Fin n → ℝ) → Fin m → ℝ)
    (hg : ∀ i, Measurable (fun y ↦ g y i))
    (μ : (Fin n → ℝ) → ℝ) (x₀ c : Fin n → ℝ)
    {R t K M σ : ℝ} (hR : 0 < R) (ht : 0 < t)
    (hrel :
      (∫⁻ x in ballSet (fun i ↦ x₀ i + R * c i) (R * t),
        ∫⁻ r in Ioo (0 : ℝ) (R * t),
          ENNReal.ofReal (ballOscillation x r g / r)) ≤
        ENNReal.ofReal
          (K * (volume (ballSet (fun i ↦ x₀ i + R * c i) (4 * (R * t)))).toReal *
              ballOscillation (fun i ↦ x₀ i + R * c i) (4 * (R * t)) g +
            M * (R * t) ^ σ *
              ∫ y in ballSet (fun i ↦ x₀ i + R * c i) (4 * (R * t)), μ y)) :
      (∫⁻ x in ballSet c t, ∫⁻ r in Ioo (0 : ℝ) t,
        ENNReal.ofReal
          (ballOscillation x r (fun y ↦ g (fun i ↦ x₀ i + R * y i)) / r)) ≤
        ENNReal.ofReal
          (K * (volume (ballSet c (4 * t))).toReal *
              ballOscillation c (4 * t) (fun y ↦ g (fun i ↦ x₀ i + R * y i)) +
            (M * R ^ σ) * t ^ σ *
              ∫ y in ballSet c (4 * t), μ (fun i ↦ x₀ i + R * y i)) := by
  let T : (Fin n → ℝ) → (Fin n → ℝ) := fun y i ↦ x₀ i + R * y i
  let cT : Fin n → ℝ := T c
  let J : ℝ := (R ^ n)⁻¹
  have hJ : 0 ≤ J := (inv_pos.mpr (pow_pos hR n)).le
  have hmass : (volume (ballSet c (4 * t))).toReal =
      J * (volume (ballSet cT (4 * (R * t)))).toReal := by
    have h := setIntegral_affineScale (fun _ : Fin n → ℝ ↦ (1 : ℝ))
      x₀ c hR (r := 4 * t)
    simpa only [T, cT, J, mul_assoc, mul_left_comm, integral_const,
      measureReal_def, Measure.restrict_apply_univ, smul_eq_mul, mul_one] using h
  have hosc :
      ballOscillation c (4 * t) (fun y ↦ g (T y)) =
        ballOscillation cT (4 * (R * t)) g := by
    have h := ballOscillation_affineScale g x₀ c hR
      (r := 4 * t) (mul_pos (by norm_num) ht)
    simpa only [T, cT, mul_assoc, mul_left_comm] using h
  have hint :
      (∫ y in ballSet c (4 * t), μ (T y)) =
        J * ∫ y in ballSet cT (4 * (R * t)), μ y := by
    have h := setIntegral_affineScale μ x₀ c hR (r := 4 * t)
    simpa only [T, cT, J, mul_assoc, mul_left_comm] using h
  have hrpow : (R * t) ^ σ = R ^ σ * t ^ σ :=
    Real.mul_rpow hR.le ht.le
  have hrhs :
      K * (volume (ballSet c (4 * t))).toReal *
            ballOscillation c (4 * t) (fun y ↦ g (T y)) +
          (M * R ^ σ) * t ^ σ * ∫ y in ballSet c (4 * t), μ (T y) =
        J *
          (K * (volume (ballSet cT (4 * (R * t)))).toReal *
              ballOscillation cT (4 * (R * t)) g +
            M * (R * t) ^ σ * ∫ y in ballSet cT (4 * (R * t)), μ y) := by
    rw [hmass, hosc, hint, hrpow]
    ring
  rw [relativeOscillationLIntegral_affineScale g hg x₀ c hR]
  calc
    ENNReal.ofReal (R ^ n)⁻¹ *
          (∫⁻ x in ballSet cT (R * t), ∫⁻ r in Ioo (0 : ℝ) (R * t),
            ENNReal.ofReal (ballOscillation x r g / r)) ≤
        ENNReal.ofReal (R ^ n)⁻¹ *
          ENNReal.ofReal
            (K * (volume (ballSet cT (4 * (R * t)))).toReal *
                ballOscillation cT (4 * (R * t)) g +
              M * (R * t) ^ σ * ∫ y in ballSet cT (4 * (R * t)), μ y) :=
      mul_le_mul_right hrel _
    _ = _ := by
      rw [← ENNReal.ofReal_mul hJ, ← hrhs]

end AffineCarleson.Internal
