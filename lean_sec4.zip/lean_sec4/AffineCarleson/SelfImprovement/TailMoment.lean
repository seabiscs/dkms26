import AffineCarleson.SelfImprovement.TailDecay
import AffineCarleson.SelfImprovement.WeightedMoment

/-!
# Weighted moments from the hole-filling recurrence

This file connects scalar tail decay to the inverse-power moment bound.
-/

open Set MeasureTheory

namespace AffineCarleson.Internal

theorem weightedMoment_of_contract (n : ℕ) (K σ s : ℝ) (hK : 1 ≤ K) (hs : 0 < s)
    (hsmax : s < min
      (Real.log (1 + Real.log 4 / ((4 : ℝ) ^ n * K)) / (2 * Real.log 16)) (σ / 2)) :
    ∃ C : ℝ, 0 < C ∧ ∀ (ν : Measure ℝ) (B : ℝ), 0 ≤ B → ν (Ioc 0 1) ≠ ⊤ →
      (∀ r ∈ Ioc (0 : ℝ) (1 / 16),
        (ν (Ioc 0 r)).toReal ≤
          ((4 : ℝ) ^ n * K / ((4 : ℝ) ^ n * K + Real.log 4)) *
              (ν (Ioc 0 (16 * r))).toReal + B * r ^ σ) →
      ∫⁻ r in Ioc (0 : ℝ) 1, ENNReal.ofReal (r ^ (-(2 * s))) ∂ν ≤
        ENNReal.ofReal (C * ((ν (Ioc 0 1)).toReal + B)) := by
  let s₀ := Real.log (1 + Real.log 4 / ((4 : ℝ) ^ n * K)) / (2 * Real.log 16)
  obtain ⟨γ, hqγ, hγmax⟩ := exists_exponent_between
    (hsmax.trans_le (min_le_left _ _)) (hsmax.trans_le (min_le_right _ _))
  have hγ : 0 < γ := (by linarith : 0 < 2 * s).trans hqγ
  have hγmax' : γ < min (2 * s₀) σ := hγmax
  let θ := (4 : ℝ) ^ n * K / ((4 : ℝ) ^ n * K + Real.log 4)
  let a := Real.rpow 16 (-γ)
  let b := Real.rpow 16 (-σ)
  let D := Real.rpow 16 γ * (1 + b / (a - θ))
  let C := D * (γ / (γ - 2 * s))
  have hθa : θ < a := by
    apply iterationRatio_lt_rpow_neg n hK
    exact hγmax'.trans_le (min_le_left _ _)
  have hD : 0 < D := by
    have hb : 0 < b := Real.rpow_pos_of_pos (by norm_num) _
    have hden : 0 < a - θ := sub_pos.mpr hθa
    dsimp [D]
    positivity
  have hC : 0 < C := by
    dsimp [C]
    exact mul_pos hD (div_pos hγ (sub_pos.mpr hqγ))
  refine ⟨C, hC, ?_⟩
  intro ν B hB hfinite hcontract
  let Φ := fun r : ℝ ↦ (ν (Ioc 0 r)).toReal
  have hΦone : 0 ≤ Φ 1 := ENNReal.toReal_nonneg
  have hmono : MonotoneOn Φ (Ioc (0 : ℝ) 1) := by
    intro x hx y hy hxy
    apply ENNReal.toReal_mono
    · exact ne_of_lt ((measure_mono (Ioc_subset_Ioc_right hy.2)).trans_lt
        (lt_top_iff_ne_top.mpr hfinite))
    · exact measure_mono (Ioc_subset_Ioc_right hxy)
  have hdecay := tail_decay_of_contract Φ n K σ γ B hK hγ hγmax' hB hΦone hmono hcontract
  have hA : 0 ≤ D * ((ν (Ioc 0 1)).toReal + B) := by positivity
  have hmom := inversePower_weightedMoment_le hA (by linarith : 0 < 2 * s) hqγ
    (ν := ν) (fun r hr hr1 ↦ by
      have hmr : ν (Ioc 0 r) ≠ ⊤ :=
        ne_of_lt ((measure_mono (Ioc_subset_Ioc_right hr1)).trans_lt
          (lt_top_iff_ne_top.mpr hfinite))
      rw [← ENNReal.ofReal_toReal hmr]
      apply ENNReal.ofReal_le_ofReal
      calc
        (ν (Ioc 0 r)).toReal ≤
            Real.rpow 16 γ *
              ((ν (Ioc 0 1)).toReal + B * b / (a - θ)) * Real.rpow r γ := by
          simpa only [Φ, a, b, θ] using hdecay r ⟨hr, hr1⟩
        _ ≤ D * ((ν (Ioc 0 1)).toReal + B) * r ^ γ := by
          have hm : 0 ≤ (ν (Ioc 0 1)).toReal := ENNReal.toReal_nonneg
          have hb : 0 ≤ b := (Real.rpow_pos_of_pos (by norm_num) _).le
          have hden : 0 < a - θ := sub_pos.mpr hθa
          have hd : 0 ≤ b / (a - θ) := div_nonneg hb hden.le
          have habsorb :
              (ν (Ioc 0 1)).toReal + B * b / (a - θ) ≤
                (1 + b / (a - θ)) * ((ν (Ioc 0 1)).toReal + B) := by
            calc
              (ν (Ioc 0 1)).toReal + B * b / (a - θ) =
                  (ν (Ioc 0 1)).toReal + B * (b / (a - θ)) := by ring
              _ ≤ (ν (Ioc 0 1)).toReal + B +
                  b / (a - θ) * ((ν (Ioc 0 1)).toReal + B) := by
                nlinarith [mul_nonneg hm hd]
              _ = (1 + b / (a - θ)) * ((ν (Ioc 0 1)).toReal + B) := by ring
          dsimp [D]
          have hp16 : 0 ≤ Real.rpow 16 γ := (Real.rpow_pos_of_pos (by norm_num) γ).le
          have hpr : 0 ≤ Real.rpow r γ := Real.rpow_nonneg hr.le γ
          calc
            Real.rpow 16 γ *
                ((ν (Ioc 0 1)).toReal + B * b / (a - θ)) * Real.rpow r γ ≤
                Real.rpow 16 γ *
                  ((1 + b / (a - θ)) * ((ν (Ioc 0 1)).toReal + B)) *
                    Real.rpow r γ :=
              mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left habsorb hp16) hpr
            _ = (Real.rpow 16 γ * (1 + b / (a - θ))) *
                ((ν (Ioc 0 1)).toReal + B) * Real.rpow r γ := by ring)
  simpa only [C, mul_assoc, mul_left_comm, mul_comm] using hmom

end AffineCarleson.Internal
