import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Tactic

/-!
# Hole-filling algebra

Algebraic rearrangement of the tail inequality into a contractive recurrence.
-/

namespace AffineCarleson.Internal

/-- Moving the self-term in a hole-filling inequality to the left produces a
contraction with ratio `C / (C + 1)`. -/
theorem holeFilling_rearrange
    {x y e C : ℝ} (hC : 0 ≤ C) (h : x ≤ C * (y - x) + e) :
    x ≤ C / (C + 1) * y + e / (C + 1) := by
  have hden : 0 < C + 1 := by linarith
  have hmain : x ≤ (C * y + e) / (C + 1) :=
    (le_div_iff₀ hden).2 (by linarith)
  calc
    x ≤ (C * y + e) / (C + 1) := hmain
    _ = C / (C + 1) * y + e / (C + 1) := by ring

/-- The exact hole-filling rearrangement for the source coefficient
`4ⁿ K / log 4`. -/
theorem holeFilling_rearrange_source
    {x y e K : ℝ} (n : ℕ) (hK : 1 ≤ K)
    (h : x ≤ ((4 : ℝ) ^ n * K / Real.log 4) * (y - x) + e) :
    x ≤ ((4 : ℝ) ^ n * K / ((4 : ℝ) ^ n * K + Real.log 4)) * y +
      e * Real.log 4 / ((4 : ℝ) ^ n * K + Real.log 4) := by
  have hlog : 0 < Real.log (4 : ℝ) := Real.log_pos (by norm_num)
  have hcoeff : 0 ≤ (4 : ℝ) ^ n * K / Real.log 4 := by positivity
  have hrearranged := holeFilling_rearrange hcoeff h
  have hratio :
      ((4 : ℝ) ^ n * K / Real.log 4) /
          ((4 : ℝ) ^ n * K / Real.log 4 + 1) =
        (4 : ℝ) ^ n * K / ((4 : ℝ) ^ n * K + Real.log 4) := by
    field_simp
  have herror :
      e / ((4 : ℝ) ^ n * K / Real.log 4 + 1) =
        e * Real.log 4 / ((4 : ℝ) ^ n * K + Real.log 4) := by
    field_simp
  rw [hratio, herror] at hrearranged
  exact hrearranged

end AffineCarleson.Internal
