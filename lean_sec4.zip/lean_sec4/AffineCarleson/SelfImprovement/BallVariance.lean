import AffineCarleson.BallGeometry
import AffineCarleson.SelfImprovement.Variance

/-!
# Variance identities on Euclidean balls

ENNReal and normalized forms of the finite-dimensional pairwise variance
identity, specialized to the project's concrete `ballSet`.
-/

noncomputable section
open MeasureTheory Set
open scoped BigOperators ENNReal

namespace AffineCarleson.Internal

/-- The Bochner pairwise variance identity converted to an exact iterated
`lintegral` identity. All finiteness needed for the conversion follows from
the componentwise `MemLp 2` hypotheses. -/
theorem lintegral_lintegral_sum_sub_sq
    {α : Type*} [MeasurableSpace α] {μ : Measure α} {m : ℕ}
    [IsFiniteMeasure μ] (hμ : μ Set.univ ≠ 0)
    (g : α → Fin m → ℝ) (hg : ∀ i, MemLp (fun x ↦ g x i) 2 μ) :
    (∫⁻ x, ∫⁻ y, ENNReal.ofReal (∑ i, (g x i - g y i) ^ 2) ∂μ ∂μ) =
      ENNReal.ofReal (2 * μ.real Set.univ *
        ∫ x, ∑ i, (g x i - normalizedMean μ (fun y ↦ g y i)) ^ 2 ∂μ) := by
  have hinner : ∀ x,
      Integrable (fun y ↦ ∑ i, (g x i - g y i) ^ 2) μ := by
    intro x
    exact integrable_finsetSum Finset.univ fun i _ ↦
      ((memLp_const _).sub (hg i)).integrable_sq
  have houter_components : ∀ i,
      Integrable (fun x ↦ ∫ y, (g x i - g y i) ^ 2 ∂μ) μ :=
    fun i ↦ integrable_integral_sub_sq_right (hg i)
  have houter : Integrable (fun x ↦ ∫ y, ∑ i, (g x i - g y i) ^ 2 ∂μ) μ := by
    apply Integrable.congr
      (integrable_finsetSum Finset.univ fun i _ ↦ houter_components i)
    filter_upwards [] with x
    exact (integral_finsetSum Finset.univ (fun i _ ↦
      ((memLp_const _).sub (hg i)).integrable_sq)).symm
  have hinner_nonneg : ∀ x, 0 ≤ ∫ y, ∑ i, (g x i - g y i) ^ 2 ∂μ := by
    intro x
    exact integral_nonneg fun y ↦ Finset.sum_nonneg fun i _ ↦ sq_nonneg _
  calc
    (∫⁻ x, ∫⁻ y, ENNReal.ofReal (∑ i, (g x i - g y i) ^ 2) ∂μ ∂μ) =
        ∫⁻ x, ENNReal.ofReal (∫ y, ∑ i, (g x i - g y i) ^ 2 ∂μ) ∂μ := by
      apply lintegral_congr
      intro x
      symm
      exact ofReal_integral_eq_lintegral_ofReal (hinner x)
        (Filter.Eventually.of_forall fun y ↦ Finset.sum_nonneg fun i _ ↦ sq_nonneg _)
    _ = ENNReal.ofReal (∫ x, ∫ y, ∑ i, (g x i - g y i) ^ 2 ∂μ ∂μ) := by
      symm
      exact ofReal_integral_eq_lintegral_ofReal houter
        (Filter.Eventually.of_forall hinner_nonneg)
    _ = ENNReal.ofReal (2 * μ.real Set.univ *
        ∫ x, ∑ i, (g x i - normalizedMean μ (fun y ↦ g y i)) ^ 2 ∂μ) := by
      congr 1
      exact integral_integral_sum_sub_sq hμ g hg

/-- The normalized componentwise oscillation of `g` on a concrete Euclidean
ball, centered at its literal coordinate averages. -/
def ballOscillation {n m : ℕ} (x : Fin n → ℝ) (r : ℝ)
    (g : (Fin n → ℝ) → Fin m → ℝ) : ℝ :=
  (volume (ballSet x r)).toReal⁻¹ *
    ∫ u in ballSet x r, ∑ i,
      (g u i - (volume (ballSet x r)).toReal⁻¹ *
        ∫ v in ballSet x r, g v i) ^ 2

/-- Exact ENNReal pairwise-variance identity on `ballSet`. -/
theorem lintegral_pairwise_eq_ball_variance
    {n m : ℕ} (x : Fin n → ℝ) {r : ℝ} (hr : 0 < r)
    (g : (Fin n → ℝ) → Fin m → ℝ)
    (hg : ∀ i, MemLp (fun u ↦ g u i) 2 (volume.restrict (ballSet x r))) :
    (∫⁻ u in ballSet x r, ∫⁻ v in ballSet x r,
      ENNReal.ofReal (∑ i, (g u i - g v i) ^ 2)) =
      ENNReal.ofReal (2 * (volume (ballSet x r)).toReal *
        ∫ u in ballSet x r, ∑ i,
          (g u i - (volume (ballSet x r)).toReal⁻¹ *
            ∫ v in ballSet x r, g v i) ^ 2) := by
  let μ := volume.restrict (ballSet x r)
  let _ : IsFiniteMeasure μ :=
    isFiniteMeasure_restrict.mpr (volume_ballSet_ne_top x hr)
  have hμ : μ Set.univ ≠ 0 := by
    change volume.restrict (ballSet x r) Set.univ ≠ 0
    rw [Measure.restrict_apply_univ]
    exact (volume_ballSet_pos x hr).ne'
  have h := lintegral_lintegral_sum_sub_sq hμ g hg
  dsimp [μ] at h
  simpa only [Measure.restrict_apply_univ, measurableSet_ballSet,
    normalizedMean, Measure.real, div_eq_inv_mul] using h

/-- The normalized ball oscillation is nonnegative. -/
theorem ballOscillation_nonneg
    {n m : ℕ} (x : Fin n → ℝ) {r : ℝ} (hr : 0 < r)
    (g : (Fin n → ℝ) → Fin m → ℝ) :
    0 ≤ ballOscillation x r g := by
  unfold ballOscillation
  exact mul_nonneg (inv_pos.mpr (volume_ballSet_toReal_pos x hr)).le
    (integral_nonneg fun u ↦ Finset.sum_nonneg fun i _ ↦ sq_nonneg _)

/-- Mass times normalized oscillation is bounded by the uncentered second
moment on the ball. -/
theorem volume_mul_ballOscillation_le
    {n m : ℕ} (x : Fin n → ℝ) {r : ℝ} (hr : 0 < r)
    (g : (Fin n → ℝ) → Fin m → ℝ)
    (hg : ∀ i, MemLp (fun u ↦ g u i) 2 (volume.restrict (ballSet x r))) :
    (volume (ballSet x r)).toReal * ballOscillation x r g ≤
      ∫ u in ballSet x r, ∑ i, g u i ^ 2 := by
  let μ := volume.restrict (ballSet x r)
  let _ : IsFiniteMeasure μ :=
    isFiniteMeasure_restrict.mpr (volume_ballSet_ne_top x hr)
  have hμ : μ Set.univ ≠ 0 := by
    change volume.restrict (ballSet x r) Set.univ ≠ 0
    rw [Measure.restrict_apply_univ]
    exact (volume_ballSet_pos x hr).ne'
  have hmin := integral_sum_sub_normalizedMean_sq_le hμ g hg
  have hmass : (volume (ballSet x r)).toReal ≠ 0 :=
    (volume_ballSet_toReal_pos x hr).ne'
  unfold ballOscillation
  rw [← mul_assoc, mul_inv_cancel₀ hmass, one_mul]
  dsimp [μ] at hmin
  simpa only [Measure.restrict_apply_univ, measurableSet_ballSet,
    normalizedMean, Measure.real, div_eq_inv_mul] using hmin

end AffineCarleson.Internal
