import AffineCarleson.SelfImprovement.AffineChangeVariables
import Mathlib.MeasureTheory.Measure.Prod

/-! Exact affine rescaling of the double integral in fractional energy. -/

noncomputable section
set_option autoImplicit false
open Set MeasureTheory

namespace AffineCarleson.Internal

theorem setLIntegral_pair_affineScale {n : ℕ}
    (Q : (Fin n → ℝ) → (Fin n → ℝ) → ENNReal)
    (hQ : Measurable (Function.uncurry Q)) (x₀ c : Fin n → ℝ)
    {R r : ℝ} (hR : 0 < R) :
    (∫⁻ u in ballSet c r, ∫⁻ v in ballSet c r,
      Q (fun i ↦ x₀ i + R * u i) (fun i ↦ x₀ i + R * v i)) =
      (ENNReal.ofReal (R ^ n)⁻¹ * ENNReal.ofReal (R ^ n)⁻¹) *
        ∫⁻ x in ballSet (fun i ↦ x₀ i + R * c i) (R * r),
          ∫⁻ y in ballSet (fun i ↦ x₀ i + R * c i) (R * r), Q x y := by
  let T := fun y : Fin n → ℝ ↦ fun i ↦ x₀ i + R * y i
  let J := ENNReal.ofReal (R ^ n)⁻¹
  have hJ : J ≠ ⊤ := ENNReal.ofReal_ne_top
  have hrow (u : Fin n → ℝ) :
      (∫⁻ v in ballSet c r, Q (T u) (T v)) =
        J * ∫⁻ y in ballSet (T c) (R * r), Q (T u) y := by
    exact setLIntegral_affineScale (Q (T u))
      (hQ.comp (measurable_const.prodMk measurable_id)) x₀ c hR
  calc
    _ = ∫⁻ u in ballSet c r, J * ∫⁻ y in ballSet (T c) (R * r), Q (T u) y :=
      lintegral_congr hrow
    _ = J * ∫⁻ u in ballSet c r, ∫⁻ y in ballSet (T c) (R * r), Q (T u) y :=
      lintegral_const_mul' _ _ hJ
    _ = J * (J * ∫⁻ x in ballSet (T c) (R * r), ∫⁻ y in ballSet (T c) (R * r), Q x y) := by
      congr 1
      exact setLIntegral_affineScale (fun x ↦ ∫⁻ y in ballSet (T c) (R * r), Q x y)
        hQ.lintegral_prod_right' x₀ c hR
    _ = _ := (mul_assoc _ _ _).symm

theorem fractionalEnergy_affineScale {n m : ℕ}
    (g : (Fin n → ℝ) → Fin m → ℝ) (hg : ∀ i, Measurable (fun x ↦ g x i))
    (x₀ : Fin n → ℝ) {R : ℝ} (hR : 0 < R) (s : ℝ) :
    (∫⁻ u in ballSet (0 : Fin n → ℝ) 1, ∫⁻ v in ballSet (0 : Fin n → ℝ) 1,
      ENNReal.ofReal ((∑ i,
        (g (fun j ↦ x₀ j + R * u j) i - g (fun j ↦ x₀ j + R * v j) i) ^ 2) /
        (Real.sqrt (∑ j, (u j - v j) ^ 2)) ^ ((n : ℝ) + 2 * s))) =
      ENNReal.ofReal (R ^ (2 * s - (n : ℝ))) *
        ∫⁻ x in ballSet x₀ R, ∫⁻ y in ballSet x₀ R,
          ENNReal.ofReal ((∑ i, (g x i - g y i) ^ 2) /
            (Real.sqrt (∑ j, (x j - y j) ^ 2)) ^ ((n : ℝ) + 2 * s)) := by
  let Q := fun x y : Fin n → ℝ ↦
    ENNReal.ofReal ((∑ i, (g x i - g y i) ^ 2) /
      (Real.sqrt (∑ j, (x j - y j) ^ 2)) ^ ((n : ℝ) + 2 * s))
  have hQ : Measurable (Function.uncurry Q) := by
    apply Measurable.ennreal_ofReal
    apply Measurable.div
    · exact Finset.measurable_sum Finset.univ fun i _ ↦
        ((hg i).comp measurable_fst |>.sub ((hg i).comp measurable_snd)).pow_const 2
    · fun_prop
  let J := ENNReal.ofReal (R ^ n)⁻¹
  let P := ENNReal.ofReal (R ^ ((n : ℝ) + 2 * s))
  have hfactor : P * (J * J) = ENNReal.ofReal (R ^ (2 * s - (n : ℝ))) := by
    dsimp only [P, J]
    rw [← ENNReal.ofReal_mul (inv_nonneg.mpr (pow_nonneg hR.le n)),
      ← ENNReal.ofReal_mul (Real.rpow_nonneg hR.le _)]
    congr 1
    rw [← Real.rpow_natCast, ← Real.rpow_neg hR.le, ← Real.rpow_add hR,
      ← Real.rpow_add hR]
    congr 1
    ring
  calc
    _ = ∫⁻ u in ballSet (0 : Fin n → ℝ) 1, ∫⁻ v in ballSet (0 : Fin n → ℝ) 1,
        P * Q (fun i ↦ x₀ i + R * u i) (fun i ↦ x₀ i + R * v i) := by
      apply lintegral_congr
      intro u
      apply lintegral_congr
      intro v
      exact fractionalKernel_affineScale_ofReal g x₀ u v hR s
    _ = P * (∫⁻ u in ballSet (0 : Fin n → ℝ) 1, ∫⁻ v in ballSet (0 : Fin n → ℝ) 1,
        Q (fun i ↦ x₀ i + R * u i) (fun i ↦ x₀ i + R * v i)) := by
      simp_rw [lintegral_const_mul' P _ ENNReal.ofReal_ne_top]
    _ = P * ((J * J) * ∫⁻ x in ballSet x₀ R, ∫⁻ y in ballSet x₀ R, Q x y) := by
      rw [setLIntegral_pair_affineScale Q hQ x₀ 0 hR]
      simp only [Pi.zero_apply, mul_zero, add_zero, mul_one, J]
    _ = _ := by rw [← mul_assoc, hfactor]

end AffineCarleson.Internal
