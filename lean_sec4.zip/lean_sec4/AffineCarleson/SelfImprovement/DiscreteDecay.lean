import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Tactic

/-!
# Discrete decay

Elementary numeric estimates for iterating a contractive recurrence with
geometrically decaying error.
-/

namespace AffineCarleson.Internal

/-- A recurrence whose contraction and error bases are bounded by the same
geometric scale decays at that scale. -/
theorem discrete_decay
    (u : ℕ → ℝ) (θ a b B : ℝ)
    (hθ : 0 ≤ θ) (ha : 0 < a) (ha_one : a < 1) (hθa : θ < a)
    (hb : 0 ≤ b) (hba : b ≤ a) (hB : 0 ≤ B) (hu0 : 0 ≤ u 0)
    (hrec : ∀ k, u (k + 1) ≤ θ * u k + B * b ^ (k + 1)) :
    ∀ k, u k ≤ a ^ k * (u 0 + B * b / (a - θ)) := by
  have hden : 0 < a - θ := sub_pos.mpr hθa
  have hC : 0 ≤ u 0 + B * b / (a - θ) := by positivity
  have hstep : θ * (u 0 + B * b / (a - θ)) + B * b ≤
      a * (u 0 + B * b / (a - θ)) := by
    field_simp
    nlinarith [mul_nonneg hu0 hden.le]
  intro k
  induction k with
  | zero =>
      simp only [pow_zero, one_mul]
      exact le_add_of_nonneg_right (div_nonneg (mul_nonneg hB hb) hden.le)
  | succ k ih =>
      have hpow : b ^ k ≤ a ^ k := by
        exact pow_le_pow_left₀ hb hba k
      calc
        u (k + 1) ≤ θ * u k + B * b ^ (k + 1) := hrec k
        _ ≤ θ * (a ^ k * (u 0 + B * b / (a - θ))) + B * b ^ (k + 1) := by
          gcongr
        _ ≤ a ^ k * (θ * (u 0 + B * b / (a - θ)) + B * b) := by
          rw [pow_succ b]
          nlinarith [mul_le_mul_of_nonneg_left hpow hB]
        _ ≤ a ^ k * (a * (u 0 + B * b / (a - θ))) := by
          exact mul_le_mul_of_nonneg_left hstep (pow_nonneg ha.le k)
        _ = a ^ (k + 1) * (u 0 + B * b / (a - θ)) := by
          rw [pow_succ]
          ring

end AffineCarleson.Internal
