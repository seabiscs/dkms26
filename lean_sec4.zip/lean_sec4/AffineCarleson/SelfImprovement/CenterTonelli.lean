import AffineCarleson.SelfImprovement.Geometry
import Mathlib.MeasureTheory.Measure.Prod
import Mathlib.MeasureTheory.Integral.Lebesgue.Add

/-! Changing the center of integration for nonnegative integrals over source balls. -/

noncomputable section
set_option autoImplicit false
open Set MeasureTheory

namespace AffineCarleson.Internal

theorem mem_ballSet_comm {n : ℕ} (x y : Fin n → ℝ) (r : ℝ) :
    x ∈ ballSet y r ↔ y ∈ ballSet x r := by
  change (∑ i, (x i - y i) ^ 2 < r ^ 2) ↔ (∑ i, (y i - x i) ^ 2 < r ^ 2)
  have hsum : ∑ i, (x i - y i) ^ 2 = ∑ i, (y i - x i) ^ 2 := by
    apply Finset.sum_congr rfl
    intro i _
    ring
  rw [hsum]

theorem measurableSet_ballSet_relation {n : ℕ} (r : ℝ) :
    MeasurableSet {p : (Fin n → ℝ) × (Fin n → ℝ) | p.2 ∈ ballSet p.1 r} := by
  change MeasurableSet {p : (Fin n → ℝ) × (Fin n → ℝ) |
    (∑ i, (p.2 i - p.1 i) ^ 2) < r ^ 2}
  exact measurableSet_lt
    (by fun_prop : Measurable (fun p : (Fin n → ℝ) × (Fin n → ℝ) ↦
      ∑ i, (p.2 i - p.1 i) ^ 2)) measurable_const

/-- Tonelli converts integration over centers to the volume of possible centers.
Both sides are extended nonnegative integrals; no finiteness is assumed. -/
theorem lintegral_ballSet_centers {n : ℕ} (F : (Fin n → ℝ) → ENNReal)
    (hF : Measurable F) (A : Set (Fin n → ℝ)) (r : ℝ) :
    (∫⁻ c in A, ∫⁻ x in ballSet c r, F x) =
      ∫⁻ x, volume (A ∩ ballSet x r) * F x := by
  classical
  have hmeas : Measurable
      (fun p : (Fin n → ℝ) × (Fin n → ℝ) ↦ if p.2 ∈ ballSet p.1 r then F p.2 else 0) :=
    Measurable.ite (measurableSet_ballSet_relation r) (hF.comp measurable_snd) measurable_const
  calc
    (∫⁻ c in A, ∫⁻ x in ballSet c r, F x) =
        ∫⁻ c in A, ∫⁻ x, if x ∈ ballSet c r then F x else 0 := by
      apply lintegral_congr
      intro c
      exact (lintegral_indicator (measurableSet_ballSet c r) F).symm
    _ = ∫⁻ x, ∫⁻ c in A, if x ∈ ballSet c r then F x else 0 :=
      lintegral_lintegral_swap hmeas.aemeasurable
    _ = ∫⁻ x, volume (A ∩ ballSet x r) * F x := by
      apply lintegral_congr
      intro x
      have heq : (fun c ↦ if x ∈ ballSet c r then F x else 0) =
          (ballSet x r).indicator (fun _ ↦ F x) := by
        funext c
        simp only [Set.indicator, mem_ballSet_comm x c r]
      rw [heq, lintegral_indicator (measurableSet_ballSet x r), lintegral_const,
        Measure.restrict_apply_univ,
        Measure.restrict_apply (measurableSet_ballSet x r)]
      rw [inter_comm, mul_comm]

/-- A set containing every ball centered in `U` supplies the full ball mass
in the center integral. -/
theorem lintegral_ballSet_centers_lower {n : ℕ} (F : (Fin n → ℝ) → ENNReal)
    (hF : Measurable F) (A U : Set (Fin n → ℝ)) (hU : MeasurableSet U)
    {r : ℝ} (hr : 0 < r) (hinside : ∀ x ∈ U, ballSet x r ⊆ A) :
    volume (ballSet (0 : Fin n → ℝ) r) * (∫⁻ x in U, F x) ≤
      ∫⁻ c in A, ∫⁻ x in ballSet c r, F x := by
  rw [lintegral_ballSet_centers F hF]
  calc
    volume (ballSet (0 : Fin n → ℝ) r) * (∫⁻ x in U, F x) =
        ∫⁻ x in U, volume (ballSet (0 : Fin n → ℝ) r) * F x :=
      (lintegral_const_mul' _ _ (volume_ballSet_ne_top 0 hr)).symm
    _ = ∫⁻ x in U, volume (A ∩ ballSet x r) * F x := by
      apply setLIntegral_congr_fun hU
      intro x hx
      dsimp only
      rw [inter_eq_right.mpr (hinside x hx), volume_ballSet_center x hr]
    _ ≤ ∫⁻ x, volume (A ∩ ballSet x r) * F x := setLIntegral_le_lintegral _ _

/-- A domain containing all the balls bounds the integrated error term by
one ball volume times the integral over that domain. -/
theorem lintegral_ballSet_centers_upper {n : ℕ} (F : (Fin n → ℝ) → ENNReal)
    (hF : Measurable F) (A U : Set (Fin n → ℝ)) (hU : MeasurableSet U)
    {r : ℝ} (hr : 0 < r) (hinside : ∀ c ∈ A, ballSet c r ⊆ U) :
    (∫⁻ c in A, ∫⁻ x in ballSet c r, F x) ≤
      volume (ballSet (0 : Fin n → ℝ) r) * (∫⁻ x in U, F x) := by
  classical
  rw [lintegral_ballSet_centers F hF, ← lintegral_const_mul' _ _ (volume_ballSet_ne_top 0 hr),
    ← lintegral_indicator hU]
  apply lintegral_mono
  intro x
  dsimp only
  by_cases hx : x ∈ U
  · rw [indicator_of_mem hx]
    exact mul_le_mul' ((measure_mono inter_subset_right).trans_eq
      (volume_ballSet_center x hr)) le_rfl
  · rw [indicator_of_notMem hx]
    have hempty : A ∩ ballSet x r = ∅ := by
      apply eq_empty_iff_forall_notMem.mpr
      intro c hc
      exact hx (hinside c hc.1 ((mem_ballSet_comm c x r).mp hc.2))
    rw [hempty, measure_empty, zero_mul]

end AffineCarleson.Internal
