import AffineCarleson.SelfImprovement.Kernel
import Mathlib.Analysis.SpecialFunctions.Integrability.Basic

/-!
# Pointwise layer-cake bound for inverse-power kernels

This is the scalar pointwise ingredient for the direct Gagliardo estimate. No integral bound
for a pair density is assumed here.
-/

noncomputable section
set_option autoImplicit false

open Set MeasureTheory

namespace AffineCarleson.Internal

theorem inversePower_kernel_le_layerCake {a d z : ℝ} (ha : 0 < a) (hd : 0 ≤ d)
    (hz : 0 ≤ z) (hdiag : d = 0 → z = 0) :
    ENNReal.ofReal (z / d ^ a) ≤ ENNReal.ofReal z + ENNReal.ofReal a *
      (∫⁻ r in Ioo (0 : ℝ) 1,
        if d < r then ENNReal.ofReal (z * r ^ (-a - 1)) else 0) := by
  rcases hd.eq_or_lt with rfl | hdpos
  · simp only [hdiag rfl, zero_div, ENNReal.ofReal_zero, zero_le]
  by_cases hd_one : d ≤ 1
  · have hpow_int : IntegrableOn (fun r : ℝ ↦ r ^ (-a - 1)) (Ioo d 1) := by
      rw [← intervalIntegrable_iff_integrableOn_Ioo_of_le hd_one]
      apply intervalIntegral.intervalIntegrable_rpow
      exact Or.inr (by
        rw [Set.uIcc_of_le hd_one]
        exact fun h ↦ (not_le_of_gt hdpos h.1))
    have hzpow_int : IntegrableOn (fun r : ℝ ↦ z * r ^ (-a - 1)) (Ioo d 1) :=
      hpow_int.const_mul z
    have hzpow_nonneg : 0 ≤ᵐ[volume.restrict (Ioo d 1)] fun r : ℝ ↦ z * r ^ (-a - 1) := by
      filter_upwards [self_mem_ae_restrict measurableSet_Ioo] with r hr
      exact mul_nonneg hz (Real.rpow_nonneg (hd.trans hr.1.le) _)
    have hintegral_nonneg : 0 ≤ ∫ r in Ioo d 1, z * r ^ (-a - 1) :=
      integral_nonneg_of_ae hzpow_nonneg
    have hreal : z / d ^ a = z + a * ∫ r in Ioo d 1, z * r ^ (-a - 1) := by
      rw [div_eq_mul_inv, ← Real.rpow_neg hdpos.le, inversePower_eq_one_add_integral ha hdpos hd_one]
      rw [MeasureTheory.integral_const_mul]
      ring
    have hrestricted :
        (∫⁻ r in Ioo (0 : ℝ) 1,
          if d < r then ENNReal.ofReal (z * r ^ (-a - 1)) else 0) =
        ∫⁻ r in Ioo d 1, ENNReal.ofReal (z * r ^ (-a - 1)) := by
      have hset : Ioi d ∩ Ioo (0 : ℝ) 1 = Ioo d 1 := by
        ext r
        simp only [mem_inter_iff, mem_Ioi, mem_Ioo]
        constructor
        · exact fun h ↦ ⟨h.1, h.2.2⟩
        · exact fun h ↦ ⟨h.1, hd.trans_lt h.1, h.2⟩
      rw [← hset, ← setLIntegral_indicator measurableSet_Ioi]
      apply setLIntegral_congr_fun measurableSet_Ioo
      intro r hr
      simp only [Set.indicator, Set.mem_Ioi]
    rw [hreal, ENNReal.ofReal_add hz (mul_nonneg ha.le hintegral_nonneg),
      ENNReal.ofReal_mul ha.le,
      ofReal_integral_eq_lintegral_ofReal hzpow_int hzpow_nonneg, ← hrestricted]
  · have hd_one' : 1 ≤ d := le_of_not_ge hd_one
    have hreal : z / d ^ a ≤ z := by
      rw [div_eq_mul_inv, ← Real.rpow_neg hdpos.le]
      exact mul_le_of_le_one_right hz (inversePower_le_one ha hd_one')
    exact (ENNReal.ofReal_le_ofReal hreal).trans (le_add_right le_rfl)

end AffineCarleson.Internal
