import AffineCarleson.SelfImprovement.NearPairs
import AffineCarleson.SelfImprovement.KernelTonelli
import AffineCarleson.SelfImprovement.OscillationDensity

/-! The local comparison between fractional energy and weighted oscillation. -/

noncomputable section
set_option autoImplicit false
open Set MeasureTheory

namespace AffineCarleson.Internal

theorem ballPairs_le_energy {n m : ℕ} (x : Fin n → ℝ) {r : ℝ} (hr : 0 < r)
    (g : (Fin n → ℝ) → Fin m → ℝ)
    (hg : ∀ i, MemLp (fun u ↦ g u i) 2 (volume.restrict (ballSet x r))) :
    (∫⁻ u in ballSet x r, ∫⁻ v in ballSet x r,
      ENNReal.ofReal (∑ i, (g u i - g v i) ^ 2)) ≤
      ENNReal.ofReal (2 * (volume (ballSet x r)).toReal) *
        ∫⁻ u in ballSet x r, ENNReal.ofReal (∑ i, g u i ^ 2) := by
  rw [lintegral_pairwise_eq_ball_variance x hr g hg]
  have hmass : (volume (ballSet x r)).toReal ≠ 0 := (volume_ballSet_toReal_pos x hr).ne'
  have hvar := volume_mul_ballOscillation_le x hr g hg
  unfold ballOscillation at hvar
  rw [← mul_assoc, mul_inv_cancel₀ hmass, one_mul] at hvar
  have hi := integrable_finsetSum Finset.univ fun i _ ↦ (hg i).integrable_sq
  rw [← ofReal_integral_eq_lintegral_ofReal hi
    (Filter.Eventually.of_forall fun u ↦ Finset.sum_nonneg fun i _ ↦ sq_nonneg _),
    ← ENNReal.ofReal_mul (by positivity : 0 ≤ 2 * (volume (ballSet x r)).toReal)]
  apply ENNReal.ofReal_le_ofReal
  exact mul_le_mul_of_nonneg_left hvar (by positivity)

theorem kernelWeight_mul_ballMass {n : ℕ} (s : ℝ) {r : ℝ} (hr : 0 < r) :
    ENNReal.ofReal (r ^ (-((n : ℝ) + 2 * s) - 1)) *
        ENNReal.ofReal ((2 : ℝ) ^ (n + 1) * (volume (ballSet (0 : Fin n → ℝ) r)).toReal) =
      ENNReal.ofReal ((2 : ℝ) ^ (n + 1) * (volume (ballSet (0 : Fin n → ℝ) 1)).toReal) *
        ENNReal.ofReal (r ^ (-(2 * s) - 1)) := by
  have hV : (volume (ballSet (0 : Fin n → ℝ) r)).toReal =
      r ^ n * (volume (ballSet (0 : Fin n → ℝ) 1)).toReal := by
    have h := volume_ballSet_mul (0 : Fin n → ℝ) hr zero_lt_one
    rw [mul_one] at h
    rw [h, ENNReal.toReal_mul, ENNReal.toReal_ofReal (pow_nonneg hr.le n)]
  rw [hV, ← ENNReal.ofReal_mul (Real.rpow_nonneg hr.le _),
    ← ENNReal.ofReal_mul (by positivity :
      0 ≤ (2 : ℝ) ^ (n + 1) * (volume (ballSet (0 : Fin n → ℝ) 1)).toReal)]
  congr 1
  have hp : r ^ (-((n : ℝ) + 2 * s) - 1) * r ^ n = r ^ (-(2 * s) - 1) := by
    rw [← Real.rpow_natCast, ← Real.rpow_add hr]
    congr 1
    ring
  calc
    _ = ((2 : ℝ) ^ (n + 1) * (volume (ballSet (0 : Fin n → ℝ) 1)).toReal) *
        (r ^ (-((n : ℝ) + 2 * s) - 1) * r ^ n) := by ring
    _ = _ := by rw [hp]

theorem unitFractionalEnergy_le_weightedOscillation {n m : ℕ}
    (g : (Fin n → ℝ) → Fin m → ℝ)
    (hgmeas : ∀ i, Measurable (fun u ↦ g u i))
    (hg : ∀ i, MemLp (fun u ↦ g u i) 2
      (volume.restrict (ballSet (0 : Fin n → ℝ) 8)))
    {s : ℝ} (hs : 0 < s) :
    (∫⁻ u in ballSet (0 : Fin n → ℝ) 1, ∫⁻ v in ballSet (0 : Fin n → ℝ) 1,
      ENNReal.ofReal ((∑ i, (g u i - g v i) ^ 2) /
        (Real.sqrt (∑ i, (u i - v i) ^ 2)) ^ ((n : ℝ) + 2 * s))) ≤
      ENNReal.ofReal (2 * (volume (ballSet (0 : Fin n → ℝ) 1)).toReal) *
        (∫⁻ u in ballSet (0 : Fin n → ℝ) 8, ENNReal.ofReal (∑ i, g u i ^ 2)) +
      ENNReal.ofReal (((n : ℝ) + 2 * s) * (2 : ℝ) ^ (n + 1) *
        (volume (ballSet (0 : Fin n → ℝ) 1)).toReal) *
        (∫⁻ r in Ioo (0 : ℝ) 1, ENNReal.ofReal (r ^ (-(2 * s) - 1)) *
          ∫⁻ c in ballSet (0 : Fin n → ℝ) (1 + r),
            ENNReal.ofReal (ballOscillation c r g)) := by
  let Q := fun u v : Fin n → ℝ ↦ ∑ i, (g u i - g v i) ^ 2
  have hQ : Measurable (Function.uncurry Q) :=
    Finset.measurable_sum Finset.univ fun i _ ↦
      ((hgmeas i).comp measurable_fst |>.sub ((hgmeas i).comp measurable_snd)).pow_const 2
  have hQnonneg (u v) : 0 ≤ Q u v := Finset.sum_nonneg fun i _ ↦ sq_nonneg _
  have hQdiag (u) : Q u u = 0 := by simp only [Q, sub_self, zero_pow (by decide : 2 ≠ 0), Finset.sum_const_zero]
  have ha : 0 < (n : ℝ) + 2 * s := by positivity
  have hkernel := lintegral_inversePower_kernel_le_layerCake Q hQ hQnonneg hQdiag
    (ballSet 0 1) (measurableSet_ballSet 0 1) ha
  have hdist (u v : Fin n → ℝ) :
      Real.sqrt (∑ i, (u i - v i) ^ 2) =
        dist (WithLp.toLp 2 u : EuclideanSpace ℝ (Fin n)) (WithLp.toLp 2 v) := by
    rw [← euclidean_dist_sq, Real.sqrt_sq dist_nonneg]
  simp_rw [← hdist] at hkernel
  have hsub : ballSet (0 : Fin n → ℝ) 1 ⊆ ballSet 0 8 :=
    ballSet_subset_ballSet 0 zero_lt_one (by norm_num)
  have hbase := ballPairs_le_energy (0 : Fin n → ℝ) zero_lt_one g
    (fun i ↦ (hg i).mono_measure (Measure.restrict_mono hsub le_rfl))
  have henergy : (∫⁻ u in ballSet (0 : Fin n → ℝ) 1, ENNReal.ofReal (∑ i, g u i ^ 2)) ≤
      ∫⁻ u in ballSet (0 : Fin n → ℝ) 8, ENNReal.ofReal (∑ i, g u i ^ 2) :=
    lintegral_mono' (Measure.restrict_mono hsub le_rfl) le_rfl
  have hweight :
      (∫⁻ r in Ioo (0 : ℝ) 1, ENNReal.ofReal (r ^ (-((n : ℝ) + 2 * s) - 1)) *
        (∫⁻ u in ballSet (0 : Fin n → ℝ) 1, ∫⁻ v in ballSet (0 : Fin n → ℝ) 1,
          if Real.sqrt (∑ i, (u i - v i) ^ 2) < r then ENNReal.ofReal (Q u v) else 0)) ≤
      ENNReal.ofReal ((2 : ℝ) ^ (n + 1) * (volume (ballSet (0 : Fin n → ℝ) 1)).toReal) *
        (∫⁻ r in Ioo (0 : ℝ) 1, ENNReal.ofReal (r ^ (-(2 * s) - 1)) *
          ∫⁻ c in ballSet (0 : Fin n → ℝ) (1 + r), ENNReal.ofReal (ballOscillation c r g)) := by
    rw [← lintegral_const_mul' _ _ ENNReal.ofReal_ne_top]
    apply setLIntegral_mono' measurableSet_Ioo
    intro r hr
    have hnear := nearPairs_le_oscillation g hgmeas hg hr.1 hr.2.le
    simp_rw [← hdist] at hnear
    calc
      _ ≤ ENNReal.ofReal (r ^ (-((n : ℝ) + 2 * s) - 1)) *
          (ENNReal.ofReal ((2 : ℝ) ^ (n + 1) * (volume (ballSet (0 : Fin n → ℝ) r)).toReal) *
            ∫⁻ c in ballSet (0 : Fin n → ℝ) (1 + r), ENNReal.ofReal (ballOscillation c r g)) :=
        mul_le_mul_right hnear _
      _ = _ := by rw [← mul_assoc, kernelWeight_mul_ballMass s hr.1, mul_assoc]
  calc
    _ ≤ _ := hkernel
    _ ≤ ENNReal.ofReal (2 * (volume (ballSet (0 : Fin n → ℝ) 1)).toReal) *
        (∫⁻ u in ballSet (0 : Fin n → ℝ) 8, ENNReal.ofReal (∑ i, g u i ^ 2)) +
        ENNReal.ofReal ((n : ℝ) + 2 * s) *
          (ENNReal.ofReal ((2 : ℝ) ^ (n + 1) * (volume (ballSet (0 : Fin n → ℝ) 1)).toReal) *
            (∫⁻ r in Ioo (0 : ℝ) 1, ENNReal.ofReal (r ^ (-(2 * s) - 1)) *
              ∫⁻ c in ballSet (0 : Fin n → ℝ) (1 + r),
                ENNReal.ofReal (ballOscillation c r g))) :=
      add_le_add (hbase.trans (mul_le_mul_right henergy _)) (mul_le_mul_right hweight _)
    _ = _ := by
      rw [← mul_assoc, ← ENNReal.ofReal_mul ha.le]
      congr 3
      ring

theorem weightedOscillation_eq_densityMoment {n m : ℕ}
    (g : (Fin n → ℝ) → Fin m → ℝ)
    (hgmeas : ∀ i, Measurable (fun u ↦ g u i))
    (hg : ∀ i, MemLp (fun u ↦ g u i) 2
      (volume.restrict (ballSet (0 : Fin n → ℝ) 8))) (s : ℝ) :
    (∫⁻ r in Ioo (0 : ℝ) 1, ENNReal.ofReal (r ^ (-(2 * s) - 1)) *
      ∫⁻ c in ballSet (0 : Fin n → ℝ) (1 + r),
        ENNReal.ofReal (ballOscillation c r g)) =
      ∫⁻ r in Ioo (0 : ℝ) 1, ENNReal.ofReal (r ^ (-(2 * s)) *
        (∫ c in ballSet (0 : Fin n → ℝ) (1 + r), ballOscillation c r g) / r) := by
  apply setLIntegral_congr_fun measurableSet_Ioo
  intro r hr
  dsimp only
  rw [← ofReal_oscillationDensity_eq_lintegral g hgmeas hg hr.1 hr.2.le,
    ← ENNReal.ofReal_mul (Real.rpow_nonneg hr.1.le _)]
  congr 1
  have hp : r ^ (-(2 * s) - 1) = r ^ (-(2 * s)) / r := by
    rw [sub_eq_add_neg, Real.rpow_add hr.1, Real.rpow_neg_one, div_eq_mul_inv]
  rw [hp]
  ring

theorem unitFractionalEnergy_le_densityMoment {n m : ℕ}
    (g : (Fin n → ℝ) → Fin m → ℝ)
    (hgmeas : ∀ i, Measurable (fun u ↦ g u i))
    (hg : ∀ i, MemLp (fun u ↦ g u i) 2
      (volume.restrict (ballSet (0 : Fin n → ℝ) 8)))
    {s : ℝ} (hs : 0 < s) :
    (∫⁻ u in ballSet (0 : Fin n → ℝ) 1, ∫⁻ v in ballSet (0 : Fin n → ℝ) 1,
      ENNReal.ofReal ((∑ i, (g u i - g v i) ^ 2) /
        (Real.sqrt (∑ i, (u i - v i) ^ 2)) ^ ((n : ℝ) + 2 * s))) ≤
      ENNReal.ofReal (2 * (volume (ballSet (0 : Fin n → ℝ) 1)).toReal *
        (∫ u in ballSet (0 : Fin n → ℝ) 8, ∑ i, g u i ^ 2)) +
      ENNReal.ofReal (((n : ℝ) + 2 * s) * (2 : ℝ) ^ (n + 1) *
        (volume (ballSet (0 : Fin n → ℝ) 1)).toReal) *
        (∫⁻ r in Ioo (0 : ℝ) 1, ENNReal.ofReal (r ^ (-(2 * s)) *
          (∫ c in ballSet (0 : Fin n → ℝ) (1 + r), ballOscillation c r g) / r)) := by
  have h := unitFractionalEnergy_le_weightedOscillation g hgmeas hg hs
  rw [weightedOscillation_eq_densityMoment g hgmeas hg s] at h
  have hi := integrable_finsetSum Finset.univ fun i _ ↦ (hg i).integrable_sq
  rw [← ofReal_integral_eq_lintegral_ofReal hi
    (Filter.Eventually.of_forall fun u ↦ Finset.sum_nonneg fun i _ ↦ sq_nonneg _),
    ← ENNReal.ofReal_mul (by positivity : 0 ≤ 2 * (volume (ballSet (0 : Fin n → ℝ) 1)).toReal)] at h
  exact h

end AffineCarleson.Internal
