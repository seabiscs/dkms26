import AffineCarleson.SelfImprovement.Exponent
import AffineCarleson.SelfImprovement.DiscreteDecay
import AffineCarleson.SelfImprovement.ContinuousDecay

/-!
# Tail decay from the hole-filling recurrence

This file combines the elementary exponent, iteration, and interpolation
estimates for the scalar tail function appearing in the hole-filling argument.
-/

namespace AffineCarleson.Internal

/-- The source-shaped hole-filling recurrence implies power decay at every
radius in `(0, 1]`. The displayed constant records the exact geometric-series
loss. -/
theorem tail_decay_of_contract
    (Φ : ℝ → ℝ) (n : ℕ) (K σ γ B : ℝ)
    (hK : 1 ≤ K) (hγ : 0 < γ)
    (hγmax : γ < min
      (2 * (Real.log (1 + Real.log 4 / ((4 : ℝ) ^ n * K)) / (2 * Real.log 16))) σ)
    (hB : 0 ≤ B) (hΦone : 0 ≤ Φ 1)
    (hmono : MonotoneOn Φ (Set.Ioc 0 1))
    (hcontract : ∀ r ∈ Set.Ioc (0 : ℝ) (1 / 16),
      Φ r ≤ ((4 : ℝ) ^ n * K / ((4 : ℝ) ^ n * K + Real.log 4)) * Φ (16 * r) +
        B * Real.rpow r σ) :
    ∀ r ∈ Set.Ioc (0 : ℝ) 1,
      Φ r ≤ Real.rpow 16 γ *
          (Φ 1 + B * Real.rpow 16 (-σ) /
            (Real.rpow 16 (-γ) -
              ((4 : ℝ) ^ n * K / ((4 : ℝ) ^ n * K + Real.log 4)))) *
        Real.rpow r γ := by
  let θ := (4 : ℝ) ^ n * K / ((4 : ℝ) ^ n * K + Real.log 4)
  let a := Real.rpow 16 (-γ)
  let b := Real.rpow 16 (-σ)
  have hγβ : γ < 2 * (Real.log (1 + Real.log 4 / ((4 : ℝ) ^ n * K)) /
      (2 * Real.log 16)) := hγmax.trans_le (min_le_left _ _)
  have hγσ : γ < σ := hγmax.trans_le (min_le_right _ _)
  have hθ : 0 ≤ θ := (iterationRatio_pos n hK).le
  have ha_data : 0 < a ∧ a < 1 := rpow_neg_pos_lt_one hγ
  have hb : 0 ≤ b := (Real.rpow_pos_of_pos (by norm_num) _).le
  have hba : b ≤ a := (rpow_neg_lt_rpow_neg hγσ).le
  have hθa : θ < a := iterationRatio_lt_rpow_neg n hK hγβ
  have hpow_error (k : ℕ) :
      Real.rpow (((16 : ℝ) ^ (k + 1))⁻¹) σ = b ^ (k + 1) := by
    change (((16 : ℝ) ^ (k + 1))⁻¹) ^ σ = ((16 : ℝ) ^ (-σ)) ^ (k + 1)
    rw [Real.inv_rpow (by positivity)]
    rw [← Real.rpow_natCast]
    rw [← Real.rpow_mul (by positivity : (0 : ℝ) ≤ 16)]
    rw [← Real.rpow_natCast]
    rw [← Real.rpow_mul (by positivity : (0 : ℝ) ≤ 16)]
    rw [← Real.rpow_neg (by positivity : (0 : ℝ) ≤ 16)]
    congr 1
    push_cast
    ring
  have hrec (k : ℕ) :
      Φ (((16 : ℝ) ^ (k + 1))⁻¹) ≤
        θ * Φ (((16 : ℝ) ^ k)⁻¹) + B * b ^ (k + 1) := by
    have hr_pos : 0 < ((16 : ℝ) ^ (k + 1))⁻¹ := by positivity
    have hr_le : ((16 : ℝ) ^ (k + 1))⁻¹ ≤ 1 / 16 := by
      rw [div_eq_mul_inv, one_mul]
      have : (16 : ℝ) ^ 1 ≤ (16 : ℝ) ^ (k + 1) := by
        exact pow_le_pow_right₀ (by norm_num) (by omega)
      exact (inv_le_inv₀ (pow_pos (by norm_num) (k + 1)) (by norm_num)).2 (by simpa using this)
    have hscale : 16 * ((16 : ℝ) ^ (k + 1))⁻¹ = ((16 : ℝ) ^ k)⁻¹ := by
      rw [pow_succ]
      field_simp
    simpa only [θ, hscale, hpow_error k] using
      hcontract (((16 : ℝ) ^ (k + 1))⁻¹) ⟨hr_pos, hr_le⟩
  have hdisc : ∀ k : ℕ,
      Φ (((16 : ℝ) ^ k)⁻¹) ≤
        a ^ k * (Φ 1 + B * b / (a - θ)) := by
    have hu0 : 0 ≤ Φ (((16 : ℝ) ^ 0)⁻¹) := by simpa using hΦone
    simpa only [pow_zero, inv_one] using
      discrete_decay (fun k ↦ Φ (((16 : ℝ) ^ k)⁻¹)) θ a b B hθ ha_data.1
        ha_data.2 hθa hb hba hB hu0 hrec
  have hgrid : ∀ k : ℕ,
      Φ (((16 : ℝ) ^ k)⁻¹) ≤
        (Φ 1 + B * b / (a - θ)) *
          Real.rpow (((16 : ℝ) ^ k)⁻¹) γ := by
    intro k
    have hpow_decay :
        a ^ k = Real.rpow (((16 : ℝ) ^ k)⁻¹) γ := by
      symm
      change (((16 : ℝ) ^ k)⁻¹) ^ γ = ((16 : ℝ) ^ (-γ)) ^ k
      rw [Real.inv_rpow (by positivity)]
      rw [← Real.rpow_natCast]
      rw [← Real.rpow_mul (by positivity : (0 : ℝ) ≤ 16)]
      rw [← Real.rpow_natCast]
      rw [← Real.rpow_mul (by positivity : (0 : ℝ) ≤ 16)]
      rw [← Real.rpow_neg (by positivity : (0 : ℝ) ≤ 16)]
      congr 1
      ring
    rw [← hpow_decay, mul_comm]
    exact hdisc k
  have hconstant : 0 ≤ Φ 1 + B * b / (a - θ) := by
    have : 0 < a - θ := sub_pos.mpr hθa
    positivity
  simpa only [a, b, θ] using
    continuous_decay_of_geometric Φ (Φ 1 + B * b / (a - θ)) γ hconstant hγ hmono hgrid

end AffineCarleson.Internal
