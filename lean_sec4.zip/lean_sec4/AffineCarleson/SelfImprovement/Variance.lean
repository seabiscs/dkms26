import Mathlib.MeasureTheory.Function.L2Space
import Mathlib.Tactic

/-!
# Finite-measure variance estimates

Componentwise variance bounds for finite-dimensional real-valued functions,
with the mean normalized by the total mass of an arbitrary finite measure.
-/

noncomputable section
open MeasureTheory
open scoped BigOperators

namespace AffineCarleson.Internal

variable {α : Type*} [MeasurableSpace α] {μ : Measure α}

/-- The normalized scalar mean with respect to a finite measure. -/
def normalizedMean (μ : Measure α) (f : α → ℝ) : ℝ :=
  (∫ x, f x ∂μ) / μ.real Set.univ

/-- Centering at the normalized mean subtracts the squared mean contribution
from the second moment. -/
theorem integral_sub_normalizedMean_sq
    [IsFiniteMeasure μ] (hμ : μ Set.univ ≠ 0) {f : α → ℝ} (hf : MemLp f 2 μ) :
    (∫ x, (f x - normalizedMean μ f) ^ 2 ∂μ) =
      (∫ x, f x ^ 2 ∂μ) - (∫ x, f x ∂μ) ^ 2 / μ.real Set.univ := by
  have hmass : 0 < μ.real Set.univ := by
    rw [measureReal_def]
    exact ENNReal.toReal_pos hμ (measure_ne_top μ Set.univ)
  have hf_int : Integrable f μ := hf.integrable (by norm_num)
  have hf_sq : Integrable (fun x ↦ f x ^ 2) μ := hf.integrable_sq
  have hlinear : Integrable (fun x ↦ 2 * normalizedMean μ f * f x) μ :=
    hf_int.const_mul _
  have hlinear_integral :
      integral μ (fun x ↦ 2 * normalizedMean μ f * f x) =
        2 * normalizedMean μ f * integral μ f := by
    exact integral_const_mul _ _
  have hsub_integral :
      integral μ ((fun x ↦ f x ^ 2) - (fun x ↦ 2 * normalizedMean μ f * f x)) =
        integral μ (fun x ↦ f x ^ 2) -
          integral μ (fun x ↦ 2 * normalizedMean μ f * f x) :=
    integral_sub hf_sq hlinear
  have hconst_integral :
      integral μ (fun _ : α ↦ normalizedMean μ f ^ 2) =
        μ.real Set.univ * normalizedMean μ f ^ 2 := by
    rw [integral_const]
    simp only [smul_eq_mul]
  calc
    (∫ x, (f x - normalizedMean μ f) ^ 2 ∂μ) =
        ∫ x, f x ^ 2 - 2 * normalizedMean μ f * f x + normalizedMean μ f ^ 2 ∂μ := by
      apply integral_congr_ae
      filter_upwards [] with x
      ring
    _ = (∫ x, f x ^ 2 ∂μ) -
          2 * normalizedMean μ f * (∫ x, f x ∂μ) +
          μ.real Set.univ * normalizedMean μ f ^ 2 := by
      change integral μ
          (((fun x ↦ f x ^ 2) - (fun x ↦ 2 * normalizedMean μ f * f x)) +
            (fun _ ↦ normalizedMean μ f ^ 2)) = _
      calc
        integral μ
            (((fun x ↦ f x ^ 2) - (fun x ↦ 2 * normalizedMean μ f * f x)) +
              (fun _ ↦ normalizedMean μ f ^ 2)) =
            integral μ ((fun x ↦ f x ^ 2) -
              (fun x ↦ 2 * normalizedMean μ f * f x)) +
              integral μ (fun _ ↦ normalizedMean μ f ^ 2) :=
          integral_add (hf_sq.sub hlinear) (integrable_const _)
        _ = _ := by
          rw [hsub_integral, hlinear_integral, hconst_integral]
    _ = (∫ x, f x ^ 2 ∂μ) - (∫ x, f x ∂μ) ^ 2 / μ.real Set.univ := by
      unfold normalizedMean
      field_simp
      ring

/-- The normalized coordinate mean minimizes the summed componentwise square
error, in particular it is no larger than the uncentered second moment. -/
theorem integral_sum_sub_normalizedMean_sq_le
    {m : ℕ} [IsFiniteMeasure μ] (hμ : μ Set.univ ≠ 0)
    (g : α → Fin m → ℝ) (hg : ∀ i, MemLp (fun x ↦ g x i) 2 μ) :
    (∫ x, ∑ i, (g x i - normalizedMean μ (fun y ↦ g y i)) ^ 2 ∂μ) ≤
      ∫ x, ∑ i, g x i ^ 2 ∂μ := by
  have hcentered_int : ∀ i,
      Integrable (fun x ↦ (g x i - normalizedMean μ (fun y ↦ g y i)) ^ 2) μ := by
    intro i
    exact ((hg i).sub (memLp_const _)).integrable_sq
  have hsquare_int : ∀ i, Integrable (fun x ↦ g x i ^ 2) μ :=
    fun i ↦ (hg i).integrable_sq
  rw [integral_finsetSum Finset.univ (fun i _ ↦ hcentered_int i),
    integral_finsetSum Finset.univ (fun i _ ↦ hsquare_int i)]
  apply Finset.sum_le_sum
  intro i hi
  rw [integral_sub_normalizedMean_sq hμ (hg i)]
  have hmass : 0 ≤ μ.real Set.univ := measureReal_nonneg
  exact sub_le_self _ (div_nonneg (sq_nonneg _) hmass)

/-- Expanding the inner half of the pairwise square integral. -/
theorem integral_sub_sq_right [IsFiniteMeasure μ]
    {f : α → ℝ} (hf : MemLp f 2 μ) (x : α) :
    (∫ y, (f x - f y) ^ 2 ∂μ) =
      μ.real Set.univ * f x ^ 2 - 2 * (∫ y, f y ∂μ) * f x +
        ∫ y, f y ^ 2 ∂μ := by
  have hf_int : Integrable f μ := hf.integrable (by norm_num)
  have hf_sq : Integrable (fun y ↦ f y ^ 2) μ := hf.integrable_sq
  have hlinear : Integrable (fun y ↦ 2 * f x * f y) μ := hf_int.const_mul _
  have hconst : integral μ (fun _ : α ↦ f x ^ 2) = μ.real Set.univ * f x ^ 2 := by
    rw [integral_const]
    simp only [smul_eq_mul]
  have hlinear_eq : integral μ (fun y ↦ 2 * f x * f y) =
      2 * f x * integral μ f := integral_const_mul _ _
  have hsub : integral μ ((fun _ : α ↦ f x ^ 2) - (fun y ↦ 2 * f x * f y)) =
      integral μ (fun _ : α ↦ f x ^ 2) - integral μ (fun y ↦ 2 * f x * f y) :=
    integral_sub (integrable_const _) hlinear
  have hadd : integral μ
      (((fun _ : α ↦ f x ^ 2) - (fun y ↦ 2 * f x * f y)) + (fun y ↦ f y ^ 2)) =
      integral μ ((fun _ : α ↦ f x ^ 2) - (fun y ↦ 2 * f x * f y)) +
        integral μ (fun y ↦ f y ^ 2) :=
    integral_add ((integrable_const _).sub hlinear) hf_sq
  calc
    (∫ y, (f x - f y) ^ 2 ∂μ) =
        ∫ y, f x ^ 2 - 2 * f x * f y + f y ^ 2 ∂μ := by
      apply integral_congr_ae
      filter_upwards [] with y
      ring
    _ = μ.real Set.univ * f x ^ 2 -
          2 * f x * (∫ y, f y ∂μ) + ∫ y, f y ^ 2 ∂μ := by
      change integral μ
        (((fun _ ↦ f x ^ 2) - (fun y ↦ 2 * f x * f y)) + (fun y ↦ f y ^ 2)) = _
      rw [hadd, hsub, hconst, hlinear_eq]
    _ = _ := by ring

/-- The inner pairwise square integral is integrable as a function of its
outer variable. -/
theorem integrable_integral_sub_sq_right [IsFiniteMeasure μ]
    {f : α → ℝ} (hf : MemLp f 2 μ) :
    Integrable (fun x ↦ ∫ y, (f x - f y) ^ 2 ∂μ) μ := by
  apply Integrable.congr
    (((hf.integrable_sq.const_mul (μ.real Set.univ)).sub
      ((hf.integrable (by norm_num)).const_mul (2 * ∫ y, f y ∂μ))).add
      (integrable_const (∫ y, f y ^ 2 ∂μ)))
  filter_upwards [] with x
  rw [integral_sub_sq_right hf x]
  simp only [Pi.add_apply, Pi.sub_apply]

/-- Pairwise square differences equal twice the mass times the centered
second moment. -/
theorem integral_integral_sub_sq
    [IsFiniteMeasure μ] (hμ : μ Set.univ ≠ 0) {f : α → ℝ} (hf : MemLp f 2 μ) :
    (∫ x, ∫ y, (f x - f y) ^ 2 ∂μ ∂μ) =
      2 * μ.real Set.univ *
        ∫ x, (f x - normalizedMean μ f) ^ 2 ∂μ := by
  have hmass : 0 < μ.real Set.univ := by
    rw [measureReal_def]
    exact ENNReal.toReal_pos hμ (measure_ne_top μ Set.univ)
  have hf_int : Integrable f μ := hf.integrable (by norm_num)
  have hf_sq : Integrable (fun x ↦ f x ^ 2) μ := hf.integrable_sq
  have hfirst : integral μ (fun x ↦ μ.real Set.univ * f x ^ 2) =
      μ.real Set.univ * integral μ (fun x ↦ f x ^ 2) := integral_const_mul _ _
  have hsecond : integral μ (fun x ↦ 2 * (∫ y, f y ∂μ) * f x) =
      2 * (∫ y, f y ∂μ) * integral μ f := integral_const_mul _ _
  have hthird : integral μ (fun _ : α ↦ ∫ y, f y ^ 2 ∂μ) =
      μ.real Set.univ * (∫ y, f y ^ 2 ∂μ) := by
    rw [integral_const]
    simp only [smul_eq_mul]
  have hsub : integral μ
      ((fun x ↦ μ.real Set.univ * f x ^ 2) -
        (fun x ↦ 2 * (∫ y, f y ∂μ) * f x)) =
      integral μ (fun x ↦ μ.real Set.univ * f x ^ 2) -
        integral μ (fun x ↦ 2 * (∫ y, f y ∂μ) * f x) :=
    integral_sub (hf_sq.const_mul _) (hf_int.const_mul _)
  have hadd : integral μ
      (((fun x ↦ μ.real Set.univ * f x ^ 2) -
        (fun x ↦ 2 * (∫ y, f y ∂μ) * f x)) +
        (fun _ ↦ ∫ y, f y ^ 2 ∂μ)) =
      integral μ ((fun x ↦ μ.real Set.univ * f x ^ 2) -
        (fun x ↦ 2 * (∫ y, f y ∂μ) * f x)) +
        integral μ (fun _ : α ↦ ∫ y, f y ^ 2 ∂μ) :=
    integral_add ((hf_sq.const_mul _).sub (hf_int.const_mul _)) (integrable_const _)
  calc
    (∫ x, ∫ y, (f x - f y) ^ 2 ∂μ ∂μ) =
        ∫ x, μ.real Set.univ * f x ^ 2 -
          2 * (∫ y, f y ∂μ) * f x + (∫ y, f y ^ 2 ∂μ) ∂μ := by
      apply integral_congr_ae
      filter_upwards [] with x
      exact integral_sub_sq_right hf x
    _ = 2 * μ.real Set.univ * (∫ x, f x ^ 2 ∂μ) -
        2 * (∫ x, f x ∂μ) ^ 2 := by
      change integral μ
        (((fun x ↦ μ.real Set.univ * f x ^ 2) -
          (fun x ↦ 2 * (∫ y, f y ∂μ) * f x)) +
          (fun _ ↦ ∫ y, f y ^ 2 ∂μ)) = _
      rw [hadd, hsub, hfirst, hsecond, hthird]
      ring
    _ = 2 * μ.real Set.univ *
        ∫ x, (f x - normalizedMean μ f) ^ 2 ∂μ := by
      rw [integral_sub_normalizedMean_sq hμ hf]
      field_simp

/-- The pairwise variance identity summed over finitely many real
coordinates. -/
theorem integral_integral_sum_sub_sq
    {m : ℕ} [IsFiniteMeasure μ] (hμ : μ Set.univ ≠ 0)
    (g : α → Fin m → ℝ) (hg : ∀ i, MemLp (fun x ↦ g x i) 2 μ) :
    (∫ x, ∫ y, ∑ i, (g x i - g y i) ^ 2 ∂μ ∂μ) =
      2 * μ.real Set.univ *
        ∫ x, ∑ i, (g x i - normalizedMean μ (fun y ↦ g y i)) ^ 2 ∂μ := by
  have hinner : ∀ x i,
      Integrable (fun y ↦ (g x i - g y i) ^ 2) μ := by
    intro x i
    exact ((memLp_const _).sub (hg i)).integrable_sq
  have houter : ∀ i,
      Integrable (fun x ↦ ∫ y, (g x i - g y i) ^ 2 ∂μ) μ :=
    fun i ↦ integrable_integral_sub_sq_right (hg i)
  have hcentered : ∀ i,
      Integrable (fun x ↦ (g x i - normalizedMean μ (fun y ↦ g y i)) ^ 2) μ := by
    intro i
    exact ((hg i).sub (memLp_const _)).integrable_sq
  calc
    (∫ x, ∫ y, ∑ i, (g x i - g y i) ^ 2 ∂μ ∂μ) =
        ∫ x, ∑ i, (∫ y, (g x i - g y i) ^ 2 ∂μ) ∂μ := by
      apply integral_congr_ae
      filter_upwards [] with x
      exact integral_finsetSum Finset.univ (fun i _ ↦ hinner x i)
    _ = ∑ i, (∫ x, ∫ y, (g x i - g y i) ^ 2 ∂μ ∂μ) :=
      integral_finsetSum Finset.univ (fun i _ ↦ houter i)
    _ = ∑ i, 2 * μ.real Set.univ *
        (∫ x, (g x i - normalizedMean μ (fun y ↦ g y i)) ^ 2 ∂μ) := by
      apply Finset.sum_congr rfl
      intro i hi
      exact integral_integral_sub_sq hμ (hg i)
    _ = 2 * μ.real Set.univ * ∑ i,
        (∫ x, (g x i - normalizedMean μ (fun y ↦ g y i)) ^ 2 ∂μ) := by
      rw [Finset.mul_sum]
    _ = 2 * μ.real Set.univ *
        ∫ x, ∑ i, (g x i - normalizedMean μ (fun y ↦ g y i)) ^ 2 ∂μ := by
      rw [integral_finsetSum Finset.univ (fun i _ ↦ hcentered i)]

end AffineCarleson.Internal
