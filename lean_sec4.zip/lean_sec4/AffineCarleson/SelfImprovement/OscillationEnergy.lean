import AffineCarleson.SelfImprovement.BallMeasurability
import AffineCarleson.SelfImprovement.CenterTonelli

/-! Averaged ball oscillation is controlled by the ambient `L²` energy. -/

noncomputable section
open MeasureTheory Set
open scoped BigOperators ENNReal

namespace AffineCarleson.Internal

/-- Averaging the normalized oscillation over all relevant centers costs no
more than the ambient uncentered second moment. -/
theorem lintegral_ballOscillation_le_energy_on
    {n m : ℕ} (g : (Fin n → ℝ) → Fin m → ℝ)
    (hgmeas : ∀ i, Measurable (fun y ↦ g y i))
    {A U : Set (Fin n → ℝ)} (hA : MeasurableSet A) (hU : MeasurableSet U)
    (hg : ∀ i, MemLp (fun y ↦ g y i) 2 (volume.restrict U))
    {r : ℝ} (hr : 0 < r) (hinside : ∀ c ∈ A, ballSet c r ⊆ U) :
    (∫⁻ c in A, ENNReal.ofReal (ballOscillation c r g)) ≤
      ∫⁻ y in U, ENNReal.ofReal (∑ i, g y i ^ 2) := by
  let F : (Fin n → ℝ) → ENNReal := fun y ↦ ENNReal.ofReal (∑ i, g y i ^ 2)
  let M := volume (ballSet (0 : Fin n → ℝ) r)
  have hFmeas : Measurable F := by
    apply Measurable.ennreal_ofReal
    exact Finset.measurable_sum Finset.univ fun i _ ↦ (hgmeas i).pow_const 2
  have hlocal : ∀ c ∈ A,
      M * ENNReal.ofReal (ballOscillation c r g) ≤ ∫⁻ y in ballSet c r, F y := by
    intro c hc
    have hgc : ∀ i, MemLp (fun y ↦ g y i) 2
        (volume.restrict (ballSet c r)) := by
      intro i
      exact (hg i).mono_measure (Measure.restrict_mono (hinside c hc) le_rfl)
    have hvar := volume_mul_ballOscillation_le c hr g hgc
    have hsum_int : Integrable (fun y ↦ ∑ i, g y i ^ 2)
        (volume.restrict (ballSet c r)) :=
      integrable_finsetSum Finset.univ fun i _ ↦ (hgc i).integrable_sq
    have hsum_nonneg : 0 ≤ᵐ[volume.restrict (ballSet c r)] fun y ↦ ∑ i, g y i ^ 2 :=
      Filter.Eventually.of_forall fun y ↦ Finset.sum_nonneg fun i _ ↦ sq_nonneg _
    have hofReal := ofReal_integral_eq_lintegral_ofReal hsum_int hsum_nonneg
    have hMreal : ENNReal.ofReal (volume (ballSet c r)).toReal = M := by
      rw [ENNReal.ofReal_toReal (volume_ballSet_ne_top c hr), volume_ballSet_center c hr]
    have ho := ENNReal.ofReal_le_ofReal hvar
    rw [ENNReal.ofReal_mul ENNReal.toReal_nonneg, hMreal, hofReal] at ho
    exact ho
  have hfirst : M * (∫⁻ c in A, ENNReal.ofReal (ballOscillation c r g)) ≤
      ∫⁻ c in A, ∫⁻ y in ballSet c r, F y := by
    calc
      M * (∫⁻ c in A, ENNReal.ofReal (ballOscillation c r g)) =
          ∫⁻ c in A, M * ENNReal.ofReal (ballOscillation c r g) :=
        (lintegral_const_mul' M _ (volume_ballSet_ne_top 0 hr)).symm
      _ ≤ _ := setLIntegral_mono' hA hlocal
  have hsecond : (∫⁻ c in A, ∫⁻ y in ballSet c r, F y) ≤
      M * (∫⁻ y in U, F y) :=
    lintegral_ballSet_centers_upper F hFmeas A U hU hr hinside
  have htotal := hfirst.trans hsecond
  have hMzero : M ≠ 0 := (volume_ballSet_pos 0 hr).ne'
  have hMtop : M ≠ ⊤ := volume_ballSet_ne_top 0 hr
  calc
    (∫⁻ c in A, ENNReal.ofReal (ballOscillation c r g)) =
        M⁻¹ * (M * (∫⁻ c in A, ENNReal.ofReal (ballOscillation c r g))) := by
      rw [← mul_assoc, ENNReal.inv_mul_cancel hMzero hMtop, one_mul]
    _ ≤ M⁻¹ * (M * (∫⁻ y in U, F y)) := by
      exact mul_le_mul_right htotal M⁻¹
    _ = ∫⁻ y in U, ENNReal.ofReal (∑ i, g y i ^ 2) := by
      rw [← mul_assoc, ENNReal.inv_mul_cancel hMzero hMtop, one_mul]

/-- The ambient-energy estimate specialized to centers near the unit ball. -/
theorem lintegral_ballOscillation_le_energy
    {n m : ℕ} (g : (Fin n → ℝ) → Fin m → ℝ)
    (hgmeas : ∀ i, Measurable (fun y ↦ g y i))
    (hg : ∀ i, MemLp (fun y ↦ g y i) 2
      (volume.restrict (ballSet (0 : Fin n → ℝ) 8)))
    {r : ℝ} (hr : 0 < r) (hr_one : r ≤ 1) :
    (∫⁻ c in ballSet (0 : Fin n → ℝ) (1 + r),
      ENNReal.ofReal (ballOscillation c r g)) ≤
      ∫⁻ y in ballSet (0 : Fin n → ℝ) 8,
        ENNReal.ofReal (∑ i, g y i ^ 2) := by
  apply lintegral_ballOscillation_le_energy_on g hgmeas
    (measurableSet_ballSet 0 (1 + r)) (measurableSet_ballSet 0 8) hg hr
  intro c hc
  have hsmall : ballSet c r ⊆ ballSet (0 : Fin n → ℝ) (1 + 2 * r) :=
    moving_ballSet_subset (a := 1) (t := r) zero_lt_one hr le_rfl hc
  exact hsmall.trans (ballSet_subset_ballSet 0 (by positivity) (by linarith))

/-- The averaged oscillation energy in the preceding theorem is finite. -/
theorem lintegral_ballOscillation_lt_top
    {n m : ℕ} (g : (Fin n → ℝ) → Fin m → ℝ)
    (hgmeas : ∀ i, Measurable (fun y ↦ g y i))
    (hg : ∀ i, MemLp (fun y ↦ g y i) 2
      (volume.restrict (ballSet (0 : Fin n → ℝ) 8)))
    {r : ℝ} (hr : 0 < r) (hr_one : r ≤ 1) :
    (∫⁻ c in ballSet (0 : Fin n → ℝ) (1 + r),
      ENNReal.ofReal (ballOscillation c r g)) < ⊤ := by
  refine (lintegral_ballOscillation_le_energy g hgmeas hg hr hr_one).trans_lt ?_
  have hsum_int : Integrable (fun y ↦ ∑ i, g y i ^ 2)
      (volume.restrict (ballSet (0 : Fin n → ℝ) 8)) :=
    integrable_finsetSum Finset.univ fun i _ ↦ (hg i).integrable_sq
  have hnonneg : 0 ≤ᵐ[volume.restrict (ballSet (0 : Fin n → ℝ) 8)]
      fun y ↦ ∑ i, g y i ^ 2 :=
    Filter.Eventually.of_forall fun y ↦ Finset.sum_nonneg fun i _ ↦ sq_nonneg _
  rw [← ofReal_integral_eq_lintegral_ofReal hsum_int hnonneg]
  exact ENNReal.ofReal_lt_top

end AffineCarleson.Internal
