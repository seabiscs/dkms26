import AffineCarleson.BallGeometry
import Mathlib.MeasureTheory.Measure.Haar.InnerProductSpace
import Mathlib.Analysis.Normed.Affine.AddTorsor

/-!
Euclidean geometry on the source's coordinate carrier. The ambient norm on
`Fin n → ℝ` is not Euclidean, so all metric arguments explicitly use `toLp 2`.
-/

noncomputable section
set_option autoImplicit false
open MeasureTheory Metric Set

namespace AffineCarleson.Internal

theorem euclidean_dist_sq {n : ℕ} (x y : Fin n → ℝ) :
    dist (WithLp.toLp 2 x : EuclideanSpace ℝ (Fin n)) (WithLp.toLp 2 y) ^ 2 = ∑ i, (x i - y i) ^ 2 := by
  rw [dist_eq_norm, PiLp.norm_sq_eq_of_L2]
  simp only [PiLp.sub_apply, Real.norm_eq_abs, sq_abs]

theorem mem_ballSet_iff_euclidean_dist {n : ℕ} {x y : Fin n → ℝ} {r : ℝ}
    (hr : 0 < r) :
    y ∈ ballSet x r ↔ dist (WithLp.toLp 2 y : EuclideanSpace ℝ (Fin n)) (WithLp.toLp 2 x) < r := by
  change (∑ i, (y i - x i) ^ 2 < r ^ 2) ↔ _
  rw [← euclidean_dist_sq, sq_lt_sq₀ dist_nonneg hr.le]

theorem euclidean_preimage_ball {n : ℕ} (x : Fin n → ℝ) {r : ℝ} (hr : 0 < r) :
    (fun y : Fin n → ℝ ↦ WithLp.toLp 2 y) ⁻¹'
      Metric.ball (WithLp.toLp 2 x) r = ballSet x r := by
  ext y
  exact (mem_ballSet_iff_euclidean_dist hr).symm

theorem ballSet_subset_of_dist_add_le {n : ℕ} {x y : Fin n → ℝ} {r R : ℝ}
    (hr : 0 < r) (hR : 0 < R)
    (h : r + dist (WithLp.toLp 2 x : EuclideanSpace ℝ (Fin n)) (WithLp.toLp 2 y) ≤ R) :
    ballSet x r ⊆ ballSet y R := by
  intro z hz
  have hzdist := (mem_ballSet_iff_euclidean_dist hr).mp hz
  apply (mem_ballSet_iff_euclidean_dist hR).mpr
  calc
    dist (WithLp.toLp 2 z : EuclideanSpace ℝ (Fin n)) (WithLp.toLp 2 y) ≤
        dist (WithLp.toLp 2 z) (WithLp.toLp 2 x) +
          dist (WithLp.toLp 2 x) (WithLp.toLp 2 y) :=
      dist_triangle (WithLp.toLp 2 z) (WithLp.toLp 2 x) (WithLp.toLp 2 y)
    _ < r + dist (WithLp.toLp 2 x) (WithLp.toLp 2 y) := by linarith
    _ ≤ R := h

theorem ballSet_subset_ballSet {n : ℕ} (x : Fin n → ℝ) {r R : ℝ}
    (hr : 0 < r) (hrR : r ≤ R) : ballSet x r ⊆ ballSet x R := by
  apply ballSet_subset_of_dist_add_le hr (hr.trans_le hrR)
  simpa only [dist_self, add_zero] using hrR

/-- The moving-ball containment used in the integrated source hypothesis. -/
theorem moving_ballSet_subset {n : ℕ} {x : Fin n → ℝ} {a r t : ℝ}
    (ha : 0 < a) (hr : 0 < r) (hrt : r ≤ t)
    (hx : x ∈ ballSet 0 (a + r)) :
    ballSet x t ⊆ ballSet 0 (a + 2 * t) := by
  have ht : 0 < t := hr.trans_le hrt
  have hd := (mem_ballSet_iff_euclidean_dist (add_pos ha hr)).mp hx
  apply ballSet_subset_of_dist_add_le ht (by positivity)
  linarith

/-- Ball mass is preserved by moving from coordinates to Euclidean space. -/
theorem volume_ballSet_eq_euclidean {n : ℕ} (x : Fin n → ℝ) {r : ℝ} (hr : 0 < r) :
    volume (ballSet x r) =
      volume (Metric.ball (WithLp.toLp 2 x : EuclideanSpace ℝ (Fin n)) r) := by
  have h := (PiLp.volume_preserving_toLp (Fin n)).measure_preimage
    (measurableSet_ball.nullMeasurableSet :
      NullMeasurableSet (Metric.ball (WithLp.toLp 2 x : EuclideanSpace ℝ (Fin n)) r) volume)
  rwa [euclidean_preimage_ball x hr] at h

theorem volume_ballSet_center {n : ℕ} (x : Fin n → ℝ) {r : ℝ} (hr : 0 < r) :
    volume (ballSet x r) = volume (ballSet (0 : Fin n → ℝ) r) := by
  rw [volume_ballSet_eq_euclidean x hr, volume_ballSet_eq_euclidean 0 hr,
    Measure.addHaar_ball_center]
  rfl

theorem volume_ballSet_mul {n : ℕ} (x : Fin n → ℝ) {a r : ℝ}
    (ha : 0 < a) (hr : 0 < r) :
    volume (ballSet x (a * r)) =
      ENNReal.ofReal (a ^ n) * volume (ballSet (0 : Fin n → ℝ) r) := by
  rw [volume_ballSet_eq_euclidean x (mul_pos ha hr),
    volume_ballSet_eq_euclidean 0 hr, Measure.addHaar_ball_mul_of_pos volume _ ha]
  simp only [finrank_euclideanSpace, Fintype.card_fin]
  rfl

/-- Close pairs have a quantitatively large set of common ball centers. -/
theorem volume_ballSet_inter_lower {n : ℕ} (x y : Fin n → ℝ) {r : ℝ}
    (hr : 0 < r)
    (hxy : dist (WithLp.toLp 2 x : EuclideanSpace ℝ (Fin n)) (WithLp.toLp 2 y) ≤ r) :
    ENNReal.ofReal ((1 / 2 : ℝ) ^ n) * volume (ballSet (0 : Fin n → ℝ) r) ≤
      volume (ballSet x r ∩ ballSet y r) := by
  let c : Fin n → ℝ := WithLp.ofLp
    (midpoint ℝ (WithLp.toLp 2 x : EuclideanSpace ℝ (Fin n)) (WithLp.toLp 2 y))
  have hc : WithLp.toLp 2 c =
      midpoint ℝ (WithLp.toLp 2 x : EuclideanSpace ℝ (Fin n)) (WithLp.toLp 2 y) := rfl
  have hleft : dist (WithLp.toLp 2 c : EuclideanSpace ℝ (Fin n)) (WithLp.toLp 2 x) ≤ r / 2 := by
    rw [hc, dist_midpoint_left]
    simpa only [Real.norm_eq_abs, abs_of_pos (by norm_num : (0:ℝ) < 2), inv_mul_eq_div] using (div_le_div_of_nonneg_right hxy (by norm_num : (0:ℝ) ≤ 2))
  have hright : dist (WithLp.toLp 2 c : EuclideanSpace ℝ (Fin n)) (WithLp.toLp 2 y) ≤ r / 2 := by
    rw [hc, dist_midpoint_right]
    simpa only [Real.norm_eq_abs, abs_of_pos (by norm_num : (0:ℝ) < 2), inv_mul_eq_div] using (div_le_div_of_nonneg_right hxy (by norm_num : (0:ℝ) ≤ 2))
  have hcx : ballSet c (r / 2) ⊆ ballSet x r :=
    ballSet_subset_of_dist_add_le (by positivity) hr (by linarith)
  have hcy : ballSet c (r / 2) ⊆ ballSet y r :=
    ballSet_subset_of_dist_add_le (by positivity) hr (by linarith)
  have hmass : volume (ballSet c (r / 2)) ≤ volume (ballSet x r ∩ ballSet y r) :=
    measure_mono (subset_inter hcx hcy)
  rw [show r / 2 = (1 / 2 : ℝ) * r by ring,
    volume_ballSet_mul c (by norm_num) hr] at hmass
  exact hmass

/-- Any compact set has a finite cover by source balls of a fixed positive radius. -/
theorem compact_finite_ballSet_cover {n : ℕ} (A : Set (Fin n → ℝ))
    (hA : IsCompact A) {r : ℝ} (hr : 0 < r) :
    ∃ centers : Finset A, A ⊆ ⋃ x ∈ centers, ballSet x.val r := by
  classical
  apply hA.elim_finite_subcover (fun x : A ↦ ballSet x.val r)
    (fun x ↦ isOpen_ballSet x.val r)
  intro x hx
  exact mem_iUnion.mpr ⟨⟨x, hx⟩, center_mem_ballSet x hr⟩

/-- All common centers for a pair in the unit ball are in the moving outer ball. -/
theorem common_centers_subset_moving_ball {n : ℕ} {x y : Fin n → ℝ} {r : ℝ}
    (hr : 0 < r) (hx : x ∈ ballSet 0 1) :
    ballSet x r ∩ ballSet y r ⊆ ballSet 0 (1 + r) := by
  apply inter_subset_left.trans
  have hdist := (mem_ballSet_iff_euclidean_dist zero_lt_one).mp hx
  exact ballSet_subset_of_dist_add_le hr (by positivity) (by linarith)

end AffineCarleson.Internal
