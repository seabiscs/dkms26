import AffineCarleson.SelfImprovement.Geometry
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Tactic

/-!
# Pointwise scaling algebra

The identities here are the algebraic part of source rescaling. They do not include any
change-of-variables or Jacobian statement.
-/

noncomputable section
set_option autoImplicit false

open Set

namespace AffineCarleson.Internal

theorem affineScale_sqrt_distance {n : ℕ} (x₀ y z : Fin n → ℝ) {R : ℝ} (hR : 0 < R) :
    Real.sqrt (∑ i, ((x₀ i + R * y i) - (x₀ i + R * z i)) ^ 2) =
      R * Real.sqrt (∑ i, (y i - z i) ^ 2) := by
  have hsum :
      (∑ i, ((x₀ i + R * y i) - (x₀ i + R * z i)) ^ 2) =
        R ^ 2 * ∑ i, (y i - z i) ^ 2 := by
    simp_rw [show ∀ i, (x₀ i + R * y i) - (x₀ i + R * z i) = R * (y i - z i) by
      intro i
      ring]
    simp_rw [mul_pow]
    rw [Finset.mul_sum]
  rw [hsum, Real.sqrt_mul (sq_nonneg R), Real.sqrt_sq_eq_abs, abs_of_pos hR]

theorem fractionalKernel_affineScale {n m : ℕ} (g : (Fin n → ℝ) → Fin m → ℝ)
    (x₀ y z : Fin n → ℝ) {R : ℝ} (hR : 0 < R) (s : ℝ) :
    (∑ j, (g (fun i ↦ x₀ i + R * y i) j - g (fun i ↦ x₀ i + R * z i) j) ^ 2) /
        Real.rpow (Real.sqrt (∑ i, (y i - z i) ^ 2)) ((n : ℝ) + 2 * s) =
      Real.rpow R ((n : ℝ) + 2 * s) *
        ((∑ j, (g (fun i ↦ x₀ i + R * y i) j - g (fun i ↦ x₀ i + R * z i) j) ^ 2) /
          Real.rpow
            (Real.sqrt (∑ i,
              ((x₀ i + R * y i) - (x₀ i + R * z i)) ^ 2))
            ((n : ℝ) + 2 * s)) := by
  rw [affineScale_sqrt_distance x₀ y z hR]
  have hdistpow :
      Real.rpow (R * Real.sqrt (∑ i, (y i - z i) ^ 2)) ((n : ℝ) + 2 * s) =
        Real.rpow R ((n : ℝ) + 2 * s) *
          Real.rpow (Real.sqrt (∑ i, (y i - z i) ^ 2)) ((n : ℝ) + 2 * s) :=
    Real.mul_rpow hR.le (Real.sqrt_nonneg _)
  rw [hdistpow]
  have hscale : Real.rpow R ((n : ℝ) + 2 * s) ≠ 0 :=
    ne_of_gt (Real.rpow_pos_of_pos hR _)
  field_simp

theorem fractionalKernel_affineScale_ofReal {n m : ℕ}
    (g : (Fin n → ℝ) → Fin m → ℝ) (x₀ y z : Fin n → ℝ)
    {R : ℝ} (hR : 0 < R) (s : ℝ) :
    ENNReal.ofReal
        ((∑ j, (g (fun i ↦ x₀ i + R * y i) j - g (fun i ↦ x₀ i + R * z i) j) ^ 2) /
          Real.rpow (Real.sqrt (∑ i, (y i - z i) ^ 2)) ((n : ℝ) + 2 * s)) =
      ENNReal.ofReal (Real.rpow R ((n : ℝ) + 2 * s)) *
        ENNReal.ofReal
          ((∑ j, (g (fun i ↦ x₀ i + R * y i) j - g (fun i ↦ x₀ i + R * z i) j) ^ 2) /
            Real.rpow
              (Real.sqrt (∑ i,
                ((x₀ i + R * y i) - (x₀ i + R * z i)) ^ 2))
              ((n : ℝ) + 2 * s)) := by
  rw [fractionalKernel_affineScale g x₀ y z hR s]
  exact ENNReal.ofReal_mul (Real.rpow_nonneg hR.le _)

theorem affineScale_mem_ballSet_iff {n : ℕ} (x₀ y : Fin n → ℝ) {R r : ℝ}
    (hR : 0 < R) :
    (fun i ↦ x₀ i + R * y i) ∈ ballSet x₀ (R * r) ↔ y ∈ ballSet 0 r := by
  simp only [ballSet, Set.mem_ofPred_eq, Pi.zero_apply, sub_zero]
  have hsum :
      (∑ i, ((x₀ i + R * y i) - x₀ i) ^ 2) = R ^ 2 * ∑ i, y i ^ 2 := by
    simp_rw [show ∀ i, (x₀ i + R * y i) - x₀ i = R * y i by
      intro i
      ring]
    simp_rw [mul_pow]
    rw [Finset.mul_sum]
  rw [hsum, mul_pow]
  constructor <;> intro h <;> nlinarith [sq_pos_of_pos hR]

end AffineCarleson.Internal
