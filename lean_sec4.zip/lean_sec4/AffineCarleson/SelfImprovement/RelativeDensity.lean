import AffineCarleson.SelfImprovement.RelativeScale
import AffineCarleson.SelfImprovement.OscillationDensity
import AffineCarleson.SelfImprovement.TailIntegration

/-! Source-shaped scalar consequences of the relative ball hypothesis. -/

noncomputable section
set_option autoImplicit false

open Set MeasureTheory
open scoped BigOperators ENNReal

namespace AffineCarleson.Internal

/-- The actual relative hypothesis at radius one gives a finite unit tail and its scalar bound. -/
theorem relative_unit_tail_finite_and_le {n m : ℕ}
    (g : (Fin n → ℝ) → Fin m → ℝ)
    (hgmeas : ∀ i, Measurable (fun y ↦ g y i))
    (hg : ∀ i, MemLp (fun y ↦ g y i) 2
      (volume.restrict (ballSet (0 : Fin n → ℝ) 8)))
    (μ : (Fin n → ℝ) → ℝ) (hμmeas : Measurable μ)
    (hμnonneg : ∀ y, 0 ≤ μ y) (hμint : IntegrableOn μ (ballSet 0 8))
    {K M σ : ℝ} (hK : 1 ≤ K) (hM : 0 ≤ M)
    (hrel : ∀ t ∈ Ioc (0 : ℝ) 1,
      ∀ c ∈ ballSet (0 : Fin n → ℝ) (1 + 2 * t),
        (∫⁻ x in ballSet c t, ∫⁻ r in Ioo (0 : ℝ) t,
          ENNReal.ofReal (ballOscillation x r g / r)) ≤
        ENNReal.ofReal
          (K * (volume (ballSet c (4 * t))).toReal * ballOscillation c (4 * t) g +
            M * t ^ σ * ∫ y in ballSet c (4 * t), μ y)) :
    let E : ℝ → ℝ := fun r ↦
      ∫ x in ballSet (0 : Fin n → ℝ) (1 + r), ballOscillation x r g
    let A : ℝ := ∫ y in ballSet (0 : Fin n → ℝ) 8, ∑ i, g y i ^ 2
    let Q : ℝ := ∫ y in ballSet (0 : Fin n → ℝ) 8, μ y
    (∫⁻ r in Ioo (0 : ℝ) 1, ENNReal.ofReal (E r / r)) < ⊤ ∧
      tailIntegral E 1 ≤ (4 : ℝ) ^ n * K * A + (4 : ℝ) ^ n * M * Q := by
  dsimp only
  let E : ℝ → ℝ := fun r ↦
    ∫ x in ballSet (0 : Fin n → ℝ) (1 + r), ballOscillation x r g
  have hrel_one : ∀ c ∈ ballSet (0 : Fin n → ℝ) 3,
      (∫⁻ x in ballSet c 1, ∫⁻ r in Ioo (0 : ℝ) 1,
        ENNReal.ofReal (ballOscillation x r g / r)) ≤
      ENNReal.ofReal
        (K * (volume (ballSet c 4)).toReal * ballOscillation c 4 g +
          M * ∫ y in ballSet c 4, μ y) := by
    intro c hc
    convert hrel 1 ⟨zero_lt_one, le_rfl⟩ c (by norm_num at hc ⊢; exact hc) using 1
    all_goals norm_num
  have hconvert := lintegral_oscillationDensity_div_eq g hgmeas hg (t := (1 : ℝ)) le_rfl
  have hfinite_raw := relative_tail_lt_top g hgmeas hg μ hμmeas hμnonneg hμint
    hK hM hrel_one
  have hfinite : (∫⁻ r in Ioo (0 : ℝ) 1, ENNReal.ofReal (E r / r)) < ⊤ := by
    rw [hconvert]
    exact hfinite_raw
  refine ⟨hfinite, ?_⟩
  have hbound := relative_tail_le_energy g hgmeas hg μ hμmeas hμnonneg hμint
    hK hM hrel_one
  have hsum_int : Integrable (fun y ↦ ∑ i, g y i ^ 2)
      (volume.restrict (ballSet (0 : Fin n → ℝ) 8)) :=
    integrable_finsetSum Finset.univ fun i _ ↦ (hg i).integrable_sq
  have hsum_nonneg : 0 ≤ᵐ[volume.restrict (ballSet (0 : Fin n → ℝ) 8)]
      fun y ↦ ∑ i, g y i ^ 2 :=
    Filter.Eventually.of_forall fun y ↦ Finset.sum_nonneg fun i _ ↦ sq_nonneg _
  rw [← ofReal_integral_eq_lintegral_ofReal hsum_int hsum_nonneg,
    ← ofReal_integral_eq_lintegral_ofReal hμint
      (Filter.Eventually.of_forall hμnonneg)] at hbound
  unfold tailIntegral
  rw [hconvert]
  have hleft_ne_top :
      ENNReal.ofReal ((4 : ℝ) ^ n * K) *
          ENNReal.ofReal (∫ y in ballSet (0 : Fin n → ℝ) 8, ∑ i, g y i ^ 2) ≠ ⊤ :=
    ENNReal.mul_ne_top ENNReal.ofReal_ne_top ENNReal.ofReal_ne_top
  have hright_ne_top :
      ENNReal.ofReal ((4 : ℝ) ^ n * M) *
          ENNReal.ofReal (∫ y in ballSet (0 : Fin n → ℝ) 8, μ y) ≠ ⊤ :=
    ENNReal.mul_ne_top ENNReal.ofReal_ne_top ENNReal.ofReal_ne_top
  have hrhs_ne_top :
      ENNReal.ofReal ((4 : ℝ) ^ n * K) *
          ENNReal.ofReal (∫ y in ballSet (0 : Fin n → ℝ) 8, ∑ i, g y i ^ 2) +
        ENNReal.ofReal ((4 : ℝ) ^ n * M) *
          ENNReal.ofReal (∫ y in ballSet (0 : Fin n → ℝ) 8, μ y) ≠ ⊤ := by
    exact ENNReal.add_ne_top.mpr ⟨hleft_ne_top, hright_ne_top⟩
  calc
    _ ≤ (ENNReal.ofReal ((4 : ℝ) ^ n * K) *
          ENNReal.ofReal (∫ y in ballSet (0 : Fin n → ℝ) 8, ∑ i, g y i ^ 2) +
        ENNReal.ofReal ((4 : ℝ) ^ n * M) *
          ENNReal.ofReal (∫ y in ballSet (0 : Fin n → ℝ) 8, μ y)).toReal :=
      ENNReal.toReal_mono hrhs_ne_top hbound
    _ = _ := by
      rw [ENNReal.toReal_add hleft_ne_top hright_ne_top,
        ENNReal.toReal_mul, ENNReal.toReal_mul,
        ENNReal.toReal_ofReal (mul_nonneg (by positivity) (zero_le_one.trans hK)),
        ENNReal.toReal_ofReal (integral_nonneg_of_ae hsum_nonneg),
        ENNReal.toReal_ofReal (mul_nonneg (by positivity) hM),
        ENNReal.toReal_ofReal (integral_nonneg hμnonneg)]

/-- At every source scale `t ≤ 1/4`, the relative hypothesis yields the scalar tail estimate. -/
theorem relative_density_scale_le {n m : ℕ}
    (g : (Fin n → ℝ) → Fin m → ℝ)
    (hgmeas : ∀ i, Measurable (fun y ↦ g y i))
    (hg : ∀ i, MemLp (fun y ↦ g y i) 2
      (volume.restrict (ballSet (0 : Fin n → ℝ) 8)))
    (μ : (Fin n → ℝ) → ℝ) (hμmeas : Measurable μ)
    (hμnonneg : ∀ y, 0 ≤ μ y) (hμint : IntegrableOn μ (ballSet 0 8))
    {K M σ t : ℝ} (hK : 1 ≤ K) (hM : 0 ≤ M)
    (ht : 0 < t) (ht_upper : t ≤ 1 / 4)
    (hrel : ∀ τ ∈ Ioc (0 : ℝ) 1,
      ∀ c ∈ ballSet (0 : Fin n → ℝ) (1 + 2 * τ),
        (∫⁻ x in ballSet c τ, ∫⁻ r in Ioo (0 : ℝ) τ,
          ENNReal.ofReal (ballOscillation x r g / r)) ≤
        ENNReal.ofReal
          (K * (volume (ballSet c (4 * τ))).toReal * ballOscillation c (4 * τ) g +
            M * τ ^ σ * ∫ y in ballSet c (4 * τ), μ y)) :
    let E : ℝ → ℝ := fun r ↦
      ∫ x in ballSet (0 : Fin n → ℝ) (1 + r), ballOscillation x r g
    let Q : ℝ := ∫ y in ballSet (0 : Fin n → ℝ) 8, μ y
    tailIntegral E t ≤ (4 : ℝ) ^ n * K * E (4 * t) +
      ((4 : ℝ) ^ n * M * Q) * t ^ σ := by
  dsimp only
  let E : ℝ → ℝ := fun r ↦
    ∫ x in ballSet (0 : Fin n → ℝ) (1 + r), ballOscillation x r g
  have ht_one : t ≤ 1 := ht_upper.trans (by norm_num)
  have hrel_t := hrel t ⟨ht, ht_one⟩
  have hbound := relative_scale_le g hgmeas μ hμmeas hμnonneg hμint
    hK hM ht ht_upper hrel_t
  have hconvert := lintegral_oscillationDensity_div_eq g hgmeas hg ht_one
  have hE4_nonneg : 0 ≤ E (4 * t) :=
    oscillationDensity_nonneg g (r := 4 * t) (mul_pos (by norm_num) ht)
  have hE4 := ofReal_oscillationDensity_eq_lintegral g hgmeas hg (r := 4 * t)
    (mul_pos (by norm_num) ht) (by linarith)
  have hQ : ENNReal.ofReal (∫ y in ballSet (0 : Fin n → ℝ) 8, μ y) =
      ∫⁻ y in ballSet (0 : Fin n → ℝ) 8, ENNReal.ofReal (μ y) :=
    ofReal_integral_eq_lintegral_ofReal hμint (Filter.Eventually.of_forall hμnonneg)
  unfold tailIntegral
  rw [← hconvert, ← hE4, ← hQ] at hbound
  have hleft_ne_top :
      ENNReal.ofReal ((4 : ℝ) ^ n * K) * ENNReal.ofReal (E (4 * t)) ≠ ⊤ :=
    ENNReal.mul_ne_top ENNReal.ofReal_ne_top ENNReal.ofReal_ne_top
  have hright_ne_top :
      ENNReal.ofReal ((4 : ℝ) ^ n * M * t ^ σ) *
          ENNReal.ofReal (∫ y in ballSet (0 : Fin n → ℝ) 8, μ y) ≠ ⊤ :=
    ENNReal.mul_ne_top ENNReal.ofReal_ne_top ENNReal.ofReal_ne_top
  have hrhs_ne_top :
      ENNReal.ofReal ((4 : ℝ) ^ n * K) * ENNReal.ofReal (E (4 * t)) +
        ENNReal.ofReal ((4 : ℝ) ^ n * M * t ^ σ) *
          ENNReal.ofReal (∫ y in ballSet (0 : Fin n → ℝ) 8, μ y) ≠ ⊤ := by
    exact ENNReal.add_ne_top.mpr ⟨hleft_ne_top, hright_ne_top⟩
  calc
    _ ≤ (ENNReal.ofReal ((4 : ℝ) ^ n * K) * ENNReal.ofReal (E (4 * t)) +
        ENNReal.ofReal ((4 : ℝ) ^ n * M * t ^ σ) *
          ENNReal.ofReal (∫ y in ballSet (0 : Fin n → ℝ) 8, μ y)).toReal :=
      ENNReal.toReal_mono hrhs_ne_top hbound
    _ = _ := by
      rw [ENNReal.toReal_add hleft_ne_top hright_ne_top,
        ENNReal.toReal_mul, ENNReal.toReal_mul,
        ENNReal.toReal_ofReal (mul_nonneg (by positivity) (zero_le_one.trans hK)),
        ENNReal.toReal_ofReal hE4_nonneg,
        ENNReal.toReal_ofReal (mul_nonneg (mul_nonneg (by positivity) hM)
          (Real.rpow_nonneg ht.le σ)),
        ENNReal.toReal_ofReal (integral_nonneg hμnonneg)]
      dsimp only [E]
      rw [mul_comm 4 t]
      ring_nf

end AffineCarleson.Internal
