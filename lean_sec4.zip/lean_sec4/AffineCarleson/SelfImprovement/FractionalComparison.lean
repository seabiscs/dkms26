import Mathlib.MeasureTheory.Integral.Lebesgue.Add
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Tactic

/-! Lifting a pointwise difference estimate to the exact Gagliardo kernels.
This is an internal conditional helper. In the source's final application its
pointwise premise must be supplied by a proved inequality for the nonlinear V
map; it is not an assumption to add to the variational main theorem. -/

noncomputable section
open MeasureTheory

namespace AffineCarleson.Internal

theorem fractionalEnergy_le_of_pointwise
    {n a b : ℕ} (u : (Fin n → ℝ) → Fin a → ℝ)
    (v : (Fin n → ℝ) → Fin b → ℝ)
    (p s C : ℝ) (hp : 0 < p) (hC : 0 ≤ C)
    (hpoint : ∀ x y,
      Real.rpow (Real.sqrt (∑ i, (u x i - u y i) ^ 2)) p ≤
        C * ∑ j, (v x j - v y j) ^ 2)
    (U : Set (Fin n → ℝ)) :
    (∫⁻ x in U, ∫⁻ y in U,
      ENNReal.ofReal (Real.rpow (Real.sqrt (∑ i, (u x i - u y i) ^ 2)) p /
        Real.rpow (Real.sqrt (∑ k, (x k - y k) ^ 2)) ((n : ℝ) + (2 * s / p) * p))) ≤
    ENNReal.ofReal C *
      (∫⁻ x in U, ∫⁻ y in U,
        ENNReal.ofReal ((∑ j, (v x j - v y j) ^ 2) /
          Real.rpow (Real.sqrt (∑ k, (x k - y k) ^ 2)) ((n : ℝ) + 2 * s))) := by
  rw [div_mul_cancel₀ (2 * s) hp.ne']
  have hpair (x y : Fin n → ℝ) :
      ENNReal.ofReal (Real.rpow (Real.sqrt (∑ i, (u x i - u y i) ^ 2)) p /
        Real.rpow (Real.sqrt (∑ k, (x k - y k) ^ 2)) ((n : ℝ) + 2 * s)) ≤
      ENNReal.ofReal C * ENNReal.ofReal ((∑ j, (v x j - v y j) ^ 2) /
        Real.rpow (Real.sqrt (∑ k, (x k - y k) ^ 2)) ((n : ℝ) + 2 * s)) := by
    calc
      _ ≤ ENNReal.ofReal ((C * ∑ j, (v x j - v y j) ^ 2) /
          Real.rpow (Real.sqrt (∑ k, (x k - y k) ^ 2)) ((n : ℝ) + 2 * s)) := by
        apply ENNReal.ofReal_le_ofReal
        exact div_le_div_of_nonneg_right (hpoint x y)
          (Real.rpow_nonneg (Real.sqrt_nonneg _) _)
      _ = _ := by rw [mul_div_assoc, ENNReal.ofReal_mul hC]
  calc
    _ ≤ ∫⁻ x in U, ∫⁻ y in U,
        ENNReal.ofReal C * ENNReal.ofReal ((∑ j, (v x j - v y j) ^ 2) /
          Real.rpow (Real.sqrt (∑ k, (x k - y k) ^ 2)) ((n : ℝ) + 2 * s)) :=
      lintegral_mono (fun x => lintegral_mono (hpair x))
    _ = _ := by
      simp_rw [lintegral_const_mul' _ _ ENNReal.ofReal_ne_top]

end AffineCarleson.Internal
