import AffineCarleson.SelfImprovement.HoleFilling
import AffineCarleson.SelfImprovement.TailMeasure
import Mathlib.Analysis.SpecialFunctions.Integrals.Basic

/-! Elementary properties of the finite scalar tail integral. -/

noncomputable section
set_option autoImplicit false
open Set MeasureTheory

namespace AffineCarleson.Internal

/-- The real-valued cumulative tail used in the hole-filling argument. -/
def tailIntegral (E : ℝ → ℝ) (t : ℝ) : ℝ :=
  (∫⁻ u in Ioo (0 : ℝ) t, ENNReal.ofReal (E u / u)).toReal

theorem tailIntegral_eq_tailMeasureReal (E : ℝ → ℝ) (t : ℝ) :
    tailIntegral E t = (tailMeasure E (Ioc 0 t)).toReal := by
  rw [tailIntegral, tailMeasure_Ioc_eq_lintegral_Ioo]

/-- Every truncated tail below one is finite once the unit tail is finite. -/
theorem tailIntegral_lintegral_ne_top_of_le_one
    (E : ℝ → ℝ)
    (hfinite : (∫⁻ u in Ioo (0 : ℝ) 1, ENNReal.ofReal (E u / u)) ≠ ⊤)
    {t : ℝ} (ht : t ≤ 1) :
    (∫⁻ u in Ioo (0 : ℝ) t, ENNReal.ofReal (E u / u)) ≠ ⊤ := by
  apply ne_top_of_le_ne_top hfinite
  exact lintegral_mono_set (Ioo_subset_Ioo_right ht)

/-- The finite scalar tail is monotone on endpoints below one. -/
theorem tailIntegral_mono_of_le_one
    (E : ℝ → ℝ)
    (hfinite : (∫⁻ u in Ioo (0 : ℝ) 1, ENNReal.ofReal (E u / u)) ≠ ⊤)
    {r t : ℝ} (hrt : r ≤ t) (ht : t ≤ 1) :
    tailIntegral E r ≤ tailIntegral E t := by
  unfold tailIntegral
  apply ENNReal.toReal_mono (tailIntegral_lintegral_ne_top_of_le_one E hfinite ht)
  exact lintegral_mono_set (Ioo_subset_Ioo_right hrt)

theorem tailIntegral_nonneg (E : ℝ → ℝ) (t : ℝ) : 0 ≤ tailIntegral E t :=
  ENNReal.toReal_nonneg

/-- The cumulative tail below one agrees with the integral of its nonnegative
density whenever that density is measurable and the unit tail is finite. -/
theorem tailIntegral_eq_setIntegral
    (E : ℝ → ℝ) (hEmeas : Measurable E)
    (hEnonneg : ∀ u ∈ Ioo (0 : ℝ) 1, 0 ≤ E u)
    (hfinite : (∫⁻ u in Ioo (0 : ℝ) 1, ENNReal.ofReal (E u / u)) ≠ ⊤)
    {t : ℝ} (ht_one : t ≤ 1) :
    tailIntegral E t = ∫ u in Ioo (0 : ℝ) t, E u / u := by
  have hmeas : AEStronglyMeasurable (fun u ↦ E u / u)
      (volume.restrict (Ioo (0 : ℝ) t)) :=
    (hEmeas.div measurable_id).aestronglyMeasurable
  have hnonneg : 0 ≤ᵐ[volume.restrict (Ioo (0 : ℝ) t)] fun u ↦ E u / u := by
    filter_upwards [self_mem_ae_restrict measurableSet_Ioo] with u hu
    exact div_nonneg (hEnonneg u ⟨hu.1, hu.2.trans_le ht_one⟩) hu.1.le
  have hint : Integrable (fun u ↦ E u / u) (volume.restrict (Ioo (0 : ℝ) t)) :=
    (lintegral_ofReal_ne_top_iff_integrable hmeas hnonneg).mp
      (tailIntegral_lintegral_ne_top_of_le_one E hfinite ht_one)
  have hconvert := ofReal_integral_eq_lintegral_ofReal hint hnonneg
  unfold tailIntegral
  rw [← hconvert, ENNReal.toReal_ofReal]
  exact integral_nonneg_of_ae hnonneg

/-- The tail density is integrable on every positive interval below one. -/
theorem tailDensity_intervalIntegrable
    (E : ℝ → ℝ) (hEmeas : Measurable E)
    (hEnonneg : ∀ u ∈ Ioo (0 : ℝ) 1, 0 ≤ E u)
    (hfinite : (∫⁻ u in Ioo (0 : ℝ) 1, ENNReal.ofReal (E u / u)) ≠ ⊤)
    {a b : ℝ} (ha : 0 ≤ a) (hab : a ≤ b) (hb : b ≤ 1) :
    IntervalIntegrable (fun u ↦ E u / u) volume a b := by
  rw [intervalIntegrable_iff_integrableOn_Ioc_of_le hab]
  have hmeas : AEStronglyMeasurable (fun u ↦ E u / u)
      (volume.restrict (Ioo (0 : ℝ) b)) :=
    (hEmeas.div measurable_id).aestronglyMeasurable
  have hnonneg : 0 ≤ᵐ[volume.restrict (Ioo (0 : ℝ) b)] fun u ↦ E u / u := by
    filter_upwards [self_mem_ae_restrict measurableSet_Ioo] with u hu
    exact div_nonneg (hEnonneg u ⟨hu.1, hu.2.trans_le hb⟩) hu.1.le
  have hi : IntegrableOn (fun u ↦ E u / u) (Ioo (0 : ℝ) b) :=
    (lintegral_ofReal_ne_top_iff_integrable hmeas hnonneg).mp
      (tailIntegral_lintegral_ne_top_of_le_one E hfinite hb)
  have hi' : IntegrableOn (fun u ↦ E u / u) (Ioc (0 : ℝ) b) :=
    hi.congr_set_ae Ioo_ae_eq_Ioc.symm
  apply hi'.mono_set
  intro u hu
  exact ⟨ha.trans_lt hu.1, hu.2⟩

theorem tailIntegral_eq_setIntegral_Ioc
    (E : ℝ → ℝ) (hEmeas : Measurable E)
    (hEnonneg : ∀ u ∈ Ioo (0 : ℝ) 1, 0 ≤ E u)
    (hfinite : (∫⁻ u in Ioo (0 : ℝ) 1, ENNReal.ofReal (E u / u)) ≠ ⊤)
    {t : ℝ} (ht : t ≤ 1) :
    tailIntegral E t = ∫ u in Ioc (0 : ℝ) t, E u / u := by
  rw [tailIntegral_eq_setIntegral E hEmeas hEnonneg hfinite ht]
  exact setIntegral_congr_set Ioo_ae_eq_Ioc

/-- A finite cumulative tail has the expected increment on a positive interval. -/
theorem integral_tailDensity_eq_tailIntegral_sub
    (E : ℝ → ℝ) (hEmeas : Measurable E)
    (hEnonneg : ∀ u ∈ Ioo (0 : ℝ) 1, 0 ≤ E u)
    (hfinite : (∫⁻ u in Ioo (0 : ℝ) 1, ENNReal.ofReal (E u / u)) ≠ ⊤)
    {a b : ℝ} (ha : 0 ≤ a) (hab : a ≤ b) (hb : b ≤ 1) :
    (∫ u in a..b, E u / u) = tailIntegral E b - tailIntegral E a := by
  rw [intervalIntegral.integral_of_le hab,
    tailIntegral_eq_setIntegral_Ioc E hEmeas hEnonneg hfinite hb,
    tailIntegral_eq_setIntegral_Ioc E hEmeas hEnonneg hfinite (hab.trans hb)]
  have hia := (tailDensity_intervalIntegrable E hEmeas hEnonneg hfinite
    (a := 0) (b := a) le_rfl ha (hab.trans hb)).1
  have hiab := (tailDensity_intervalIntegrable E hEmeas hEnonneg hfinite
    ha hab hb).1
  have hdisj : Disjoint (Ioc (0 : ℝ) a) (Ioc a b) := by
    rw [Set.disjoint_left]
    intro u hu hua
    exact (not_lt_of_ge hu.2) hua.1
  have hadd := setIntegral_union hdisj measurableSet_Ioc hia hiab
  rw [Ioc_union_Ioc_eq_Ioc ha hab] at hadd
  linarith

/-- Rescaling the density by four produces the corresponding tail increment. -/
theorem integral_tailDensity_four_mul
    (E : ℝ → ℝ) (hEmeas : Measurable E)
    (hEnonneg : ∀ u ∈ Ioo (0 : ℝ) 1, 0 ≤ E u)
    (hfinite : (∫⁻ u in Ioo (0 : ℝ) 1, ENNReal.ofReal (E u / u)) ≠ ⊤)
    {r : ℝ} (hr : 0 < r) (hr_upper : r ≤ 1 / 16) :
    (∫ t in r..4 * r, E (4 * t) / t) =
      tailIntegral E (16 * r) - tailIntegral E (4 * r) := by
  have hpoint : (fun t ↦ E (4 * t) / t) =
      fun t ↦ 4 * (E (4 * t) / (4 * t)) := by
    funext t
    by_cases ht : t = 0
    · simp [ht]
    · field_simp
  rw [hpoint]
  calc
    (∫ t in r..4 * r, 4 * (E (4 * t) / (4 * t))) =
        4 * ∫ t in r..4 * r, (fun u ↦ E u / u) (4 * t) := by
      rw [intervalIntegral.integral_const_mul]
    _ = 4 * ((4 : ℝ)⁻¹ * ∫ u in 4 * r..4 * (4 * r), E u / u) := by
      rw [intervalIntegral.integral_comp_mul_left
        (fun u ↦ E u / u) (by norm_num : (4 : ℝ) ≠ 0)]
      rfl
    _ = ∫ u in 4 * r..16 * r, E u / u := by
      rw [show 4 * (4 * r) = 16 * r by ring]
      ring
    _ = tailIntegral E (16 * r) - tailIntegral E (4 * r) :=
      integral_tailDensity_eq_tailIntegral_sub E hEmeas hEnonneg hfinite
        (a := 4 * r) (b := 16 * r) (by positivity) (by linarith) (by linarith)

/-- Integrating a one-scale estimate yields the scalar hole-filling contraction. -/
theorem tailIntegral_contract
    (E : ℝ → ℝ) (hEmeas : Measurable E)
    (hEnonneg : ∀ u ∈ Ioo (0 : ℝ) 1, 0 ≤ E u)
    (hfinite : (∫⁻ u in Ioo (0 : ℝ) 1, ENNReal.ofReal (E u / u)) ≠ ⊤)
    {c B σ : ℝ} (hc : 0 < c) (hB : 0 ≤ B) (hσ : 0 < σ)
    (hscale : ∀ t, 0 < t → t ≤ 1 / 4 →
      tailIntegral E t ≤ c * E (4 * t) + B * t ^ σ)
    {r : ℝ} (hr : 0 < r) (hr_upper : r ≤ 1 / 16) :
    tailIntegral E r ≤ c / (c + Real.log 4) * tailIntegral E (16 * r) +
      (B * (4 : ℝ) ^ σ * Real.log 4 / (c + Real.log 4)) * r ^ σ := by
  have hr4 : r ≤ 4 * r := by linarith
  have h4r : 4 * r ≤ 1 / 4 := by linarith
  have h16r : 16 * r ≤ 1 := by linarith
  have hinv : IntervalIntegrable (fun t : ℝ ↦ 1 / t) volume r (4 * r) := by
    apply ContinuousOn.intervalIntegrable
    apply continuousOn_const.div continuousOn_id
    intro t ht
    rw [uIcc_of_le hr4] at ht
    exact ne_of_gt (hr.trans_le ht.1)
  have hdens : IntervalIntegrable (fun u ↦ E u / u) volume (4 * r) (16 * r) :=
    tailDensity_intervalIntegrable E hEmeas hEnonneg hfinite
      (by positivity) (by linarith) h16r
  have hcomp : IntervalIntegrable (fun t ↦ E (4 * t) / (4 * t)) volume r (4 * r) := by
    have h := hdens.comp_mul_left (c := (4 : ℝ))
    convert h using 1
    all_goals ring
  have hscaled : IntervalIntegrable (fun t ↦ E (4 * t) / t) volume r (4 * r) := by
    convert hcomp.const_mul 4 using 1
    funext t
    by_cases ht : t = 0
    · simp [ht]
    · field_simp
  have hleft : IntervalIntegrable (fun t ↦ tailIntegral E r / t) volume r (4 * r) := by
    simpa [div_eq_mul_inv] using hinv.const_mul (tailIntegral E r)
  have hright : IntervalIntegrable
      (fun t ↦ c * (E (4 * t) / t) + (B * (4 * r) ^ σ) * (1 / t))
      volume r (4 * r) :=
    (hscaled.const_mul c).add (hinv.const_mul (B * (4 * r) ^ σ))
  have hint : (∫ t in r..4 * r, tailIntegral E r / t) ≤
      ∫ t in r..4 * r, (c * (E (4 * t) / t) + (B * (4 * r) ^ σ) * (1 / t)) := by
    apply intervalIntegral.integral_mono_on hr4 hleft hright
    intro t ht
    have htpos : 0 < t := hr.trans_le ht.1
    have htquarter : t ≤ 1 / 4 := ht.2.trans h4r
    have hφ := tailIntegral_mono_of_le_one E hfinite ht.1
      (htquarter.trans (by norm_num))
    have hs := hscale t htpos htquarter
    have hpow : t ^ σ ≤ (4 * r) ^ σ := Real.rpow_le_rpow htpos.le ht.2 hσ.le
    have hmain : tailIntegral E r ≤ c * E (4 * t) + B * (4 * r) ^ σ := by
      calc
        _ ≤ tailIntegral E t := hφ
        _ ≤ c * E (4 * t) + B * t ^ σ := hs
        _ ≤ c * E (4 * t) + B * (4 * r) ^ σ := by gcongr
    calc
      tailIntegral E r / t ≤ (c * E (4 * t) + B * (4 * r) ^ σ) / t :=
        div_le_div_of_nonneg_right hmain htpos.le
      _ = c * (E (4 * t) / t) + (B * (4 * r) ^ σ) * (1 / t) := by ring
  have hlog : 0 < Real.log (4 : ℝ) := Real.log_pos (by norm_num)
  have hraw : Real.log 4 * tailIntegral E r ≤
      c * (tailIntegral E (16 * r) - tailIntegral E (4 * r)) +
        B * (4 * r) ^ σ * Real.log 4 := by
    calc
      Real.log 4 * tailIntegral E r = ∫ t in r..4 * r, tailIntegral E r / t := by
        rw [show (fun t ↦ tailIntegral E r / t) =
            fun t ↦ tailIntegral E r * (1 / t) by funext t; ring,
          intervalIntegral.integral_const_mul, integral_one_div_of_pos hr (by positivity),
          show 4 * r / r = 4 by field_simp [hr.ne']]
        ring
      _ ≤ _ := hint
      _ = _ := by
        rw [intervalIntegral.integral_add (hscaled.const_mul c)
            (hinv.const_mul (B * (4 * r) ^ σ)),
          intervalIntegral.integral_const_mul,
          intervalIntegral.integral_const_mul,
          integral_tailDensity_four_mul E hEmeas hEnonneg hfinite hr hr_upper,
          integral_one_div_of_pos hr (by positivity),
          show 4 * r / r = 4 by field_simp [hr.ne']]
  have hφ4 := tailIntegral_mono_of_le_one E hfinite hr4 (h4r.trans (by norm_num))
  have hpowscale : (4 * r) ^ σ = (4 : ℝ) ^ σ * r ^ σ :=
    Real.mul_rpow (by norm_num) hr.le
  rw [hpowscale] at hraw
  have hhole : tailIntegral E r ≤
      (c / Real.log 4) * (tailIntegral E (16 * r) - tailIntegral E r) +
        B * (4 : ℝ) ^ σ * r ^ σ := by
    have hh : Real.log 4 * tailIntegral E r ≤
        c * (tailIntegral E (16 * r) - tailIntegral E r) +
          B * (4 : ℝ) ^ σ * r ^ σ * Real.log 4 := by
      nlinarith
    have hd := (le_div_iff₀ hlog).2 (by nlinarith :
      tailIntegral E r * Real.log 4 ≤
        c * (tailIntegral E (16 * r) - tailIntegral E r) +
          B * (4 : ℝ) ^ σ * r ^ σ * Real.log 4)
    calc
      tailIntegral E r ≤ (c * (tailIntegral E (16 * r) - tailIntegral E r) +
          B * (4 : ℝ) ^ σ * r ^ σ * Real.log 4) / Real.log 4 := hd
      _ = _ := by field_simp [hlog.ne']
  have hrearr := holeFilling_rearrange (div_nonneg hc.le hlog.le) hhole
  convert hrearr using 1
  all_goals field_simp [hlog.ne']

end AffineCarleson.Internal
