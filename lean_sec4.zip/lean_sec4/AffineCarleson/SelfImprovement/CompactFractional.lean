import AffineCarleson.SelfImprovement.BallVariance
import AffineCarleson.SelfImprovement.Geometry
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.MeasureTheory.Measure.WithDensity
import Mathlib.Tactic

/-! Local bounds for compact fractional-energy arguments. -/

noncomputable section
set_option autoImplicit false
open Set MeasureTheory Filter
open scoped BigOperators ENNReal

namespace AffineCarleson.Internal

/-- The real fractional difference quotient used in the compactness argument. -/
def fractionalIntegrand {n m : ℕ} (a : ℝ)
    (g : (Fin n → ℝ) → Fin m → ℝ) (u v : Fin n → ℝ) : ℝ :=
  (∑ i, (g u i - g v i) ^ 2) /
    (Real.sqrt (∑ j, (u j - v j) ^ 2)) ^ a

/-- Away from the diagonal, the fractional quotient is bounded by the two
uncentered square functions. -/
theorem fractionalIntegrand_le_of_distance_lower
    {n m : ℕ} {a δ : ℝ} (ha : 0 < a) (hδ : 0 < δ)
    (g : (Fin n → ℝ) → Fin m → ℝ) (u v : Fin n → ℝ)
    (huv : δ ≤ Real.sqrt (∑ j, (u j - v j) ^ 2)) :
    fractionalIntegrand a g u v ≤
      δ ^ (-a) * (2 * ∑ i, g u i ^ 2 + 2 * ∑ i, g v i ^ 2) := by
  have hdist : 0 < Real.sqrt (∑ j, (u j - v j) ^ 2) := hδ.trans_le huv
  have hpow : δ ^ a ≤ (Real.sqrt (∑ j, (u j - v j) ^ 2)) ^ a :=
    Real.rpow_le_rpow hδ.le huv ha.le
  have hnum : (∑ i, (g u i - g v i) ^ 2) ≤
      2 * ∑ i, g u i ^ 2 + 2 * ∑ i, g v i ^ 2 := by
    calc
      (∑ i, (g u i - g v i) ^ 2) ≤
          ∑ i, (2 * g u i ^ 2 + 2 * g v i ^ 2) := by
        apply Finset.sum_le_sum
        intro i hi
        nlinarith [sq_nonneg (g u i + g v i)]
      _ = _ := by rw [Finset.sum_add_distrib, Finset.mul_sum, Finset.mul_sum]
  have hdenδ : 0 < δ ^ a := Real.rpow_pos_of_pos hδ a
  have hdend : 0 < (Real.sqrt (∑ j, (u j - v j) ^ 2)) ^ a :=
    Real.rpow_pos_of_pos hdist a
  unfold fractionalIntegrand
  calc
    (∑ i, (g u i - g v i) ^ 2) /
        (Real.sqrt (∑ j, (u j - v j) ^ 2)) ^ a ≤
      (2 * ∑ i, g u i ^ 2 + 2 * ∑ i, g v i ^ 2) /
        (Real.sqrt (∑ j, (u j - v j) ^ 2)) ^ a :=
      div_le_div_of_nonneg_right hnum hdend.le
    _ ≤ (2 * ∑ i, g u i ^ 2 + 2 * ∑ i, g v i ^ 2) / δ ^ a := by
      exact div_le_div_of_nonneg_left
        (by positivity) hdenδ hpow
    _ = δ ^ (-a) * (2 * ∑ i, g u i ^ 2 + 2 * ∑ i, g v i ^ 2) := by
      rw [Real.rpow_neg hδ.le]
      field_simp

/-- The same off-diagonal estimate after passage to `ENNReal`. -/
theorem ofReal_fractionalIntegrand_le_of_distance_lower
    {n m : ℕ} {a δ : ℝ} (ha : 0 < a) (hδ : 0 < δ)
    (g : (Fin n → ℝ) → Fin m → ℝ) (u v : Fin n → ℝ)
    (huv : δ ≤ Real.sqrt (∑ j, (u j - v j) ^ 2)) :
    ENNReal.ofReal (fractionalIntegrand a g u v) ≤
      ENNReal.ofReal (δ ^ (-a)) *
        (ENNReal.ofReal (2 * ∑ i, g u i ^ 2) +
          ENNReal.ofReal (2 * ∑ i, g v i ^ 2)) := by
  have hgu : 0 ≤ 2 * ∑ i, g u i ^ 2 :=
    mul_nonneg (by norm_num) (Finset.sum_nonneg fun i hi ↦ sq_nonneg _)
  have hgv : 0 ≤ 2 * ∑ i, g v i ^ 2 :=
    mul_nonneg (by norm_num) (Finset.sum_nonneg fun i hi ↦ sq_nonneg _)
  calc
    _ ≤ ENNReal.ofReal
        (δ ^ (-a) * (2 * ∑ i, g u i ^ 2 + 2 * ∑ i, g v i ^ 2)) :=
      ENNReal.ofReal_le_ofReal
        (fractionalIntegrand_le_of_distance_lower ha hδ g u v huv)
    _ = _ := by
      rw [ENNReal.ofReal_mul (Real.rpow_nonneg hδ.le _),
        ENNReal.ofReal_add hgu]
      exact hgv

/-- Fractional energy is finite on two finite-measure sets separated by a
positive Euclidean distance. -/
theorem lintegral_fractionalIntegrand_lt_top_of_separated
    {n m : ℕ} {a δ : ℝ} (ha : 0 < a) (hδ : 0 < δ)
    (g : (Fin n → ℝ) → Fin m → ℝ)
    {U V : Set (Fin n → ℝ)} (hU : MeasurableSet U) (hV : MeasurableSet V)
    (hUtop : volume U ≠ ⊤) (hVtop : volume V ≠ ⊤)
    (hgU : ∀ i, MemLp (fun u ↦ g u i) 2 (volume.restrict U))
    (hgV : ∀ i, MemLp (fun v ↦ g v i) 2 (volume.restrict V))
    (hsep : ∀ u ∈ U, ∀ v ∈ V,
      δ ≤ Real.sqrt (∑ j, (u j - v j) ^ 2)) :
    (∫⁻ u in U, ∫⁻ v in V, ENNReal.ofReal (fractionalIntegrand a g u v)) < ⊤ := by
  let C := ENNReal.ofReal (δ ^ (-a))
  let SU : (Fin n → ℝ) → ENNReal := fun u ↦ ENNReal.ofReal (2 * ∑ i, g u i ^ 2)
  let SV : (Fin n → ℝ) → ENNReal := fun v ↦ ENNReal.ofReal (2 * ∑ i, g v i ^ 2)
  have hSUmeas : AEMeasurable SU (volume.restrict U) := by
    apply AEMeasurable.ennreal_ofReal
    have hs := Finset.aemeasurable_sum Finset.univ fun i hi ↦
      (hgU i).aestronglyMeasurable.aemeasurable.pow_const 2
    convert hs.const_mul 2 using 1
    ext u
    simp only [Finset.sum_apply]
  have hSVmeas : AEMeasurable SV (volume.restrict V) := by
    apply AEMeasurable.ennreal_ofReal
    have hs := Finset.aemeasurable_sum Finset.univ fun i hi ↦
      (hgV i).aestronglyMeasurable.aemeasurable.pow_const 2
    convert hs.const_mul 2 using 1
    ext v
    simp only [Finset.sum_apply]
  have hSUtop : (∫⁻ u in U, SU u) < ⊤ := by
    have hi : Integrable (fun u ↦ 2 * ∑ i, g u i ^ 2) (volume.restrict U) :=
      (integrable_finsetSum Finset.univ fun i hi ↦ (hgU i).integrable_sq).const_mul 2
    have hn : 0 ≤ᵐ[volume.restrict U] fun u ↦ 2 * ∑ i, g u i ^ 2 :=
      Filter.Eventually.of_forall fun u ↦ mul_nonneg (by norm_num)
        (Finset.sum_nonneg fun i hi ↦ sq_nonneg _)
    rw [← ofReal_integral_eq_lintegral_ofReal hi hn]
    exact ENNReal.ofReal_lt_top
  have hSVtop : (∫⁻ v in V, SV v) < ⊤ := by
    have hi : Integrable (fun v ↦ 2 * ∑ i, g v i ^ 2) (volume.restrict V) :=
      (integrable_finsetSum Finset.univ fun i hi ↦ (hgV i).integrable_sq).const_mul 2
    have hn : 0 ≤ᵐ[volume.restrict V] fun v ↦ 2 * ∑ i, g v i ^ 2 :=
      Filter.Eventually.of_forall fun v ↦ mul_nonneg (by norm_num)
        (Finset.sum_nonneg fun i hi ↦ sq_nonneg _)
    rw [← ofReal_integral_eq_lintegral_ofReal hi hn]
    exact ENNReal.ofReal_lt_top
  have hbound : (∫⁻ u in U, ∫⁻ v in V,
      ENNReal.ofReal (fractionalIntegrand a g u v)) ≤
      C * ((∫⁻ u in U, SU u) * volume V + volume U * (∫⁻ v in V, SV v)) := by
    calc
      _ ≤ ∫⁻ u in U, ∫⁻ v in V, C * (SU u + SV v) := by
        apply setLIntegral_mono' hU
        intro u hu
        apply setLIntegral_mono' hV
        intro v hv
        exact ofReal_fractionalIntegrand_le_of_distance_lower ha hδ g u v
          (hsep u hu v hv)
      _ = _ := by
        simp_rw [lintegral_const_mul' C _ ENNReal.ofReal_ne_top]
        simp_rw [lintegral_add_left measurable_const, lintegral_const,
          Measure.restrict_apply_univ]
        rw [lintegral_add_left' (hSUmeas.mul_const (volume V)),
          lintegral_mul_const' (volume V) SU hVtop,
          lintegral_const, Measure.restrict_apply_univ]
        ring
  refine hbound.trans_lt ?_
  apply ENNReal.mul_lt_top ENNReal.ofReal_lt_top
  exact ENNReal.add_lt_top.2 ⟨ENNReal.mul_lt_top hSUtop (lt_top_iff_ne_top.2 hVtop),
    ENNReal.mul_lt_top (lt_top_iff_ne_top.2 hUtop) hSVtop⟩

/-- Local `L²` representatives make the fractional kernel a.e. measurable on
the corresponding product restriction. -/
theorem aemeasurable_fractionalIntegrand_prod
    {n m : ℕ} {a : ℝ} (ha : 0 < a)
    (g : (Fin n → ℝ) → Fin m → ℝ)
    {U V : Set (Fin n → ℝ)} (hUtop : volume U ≠ ⊤) (hVtop : volume V ≠ ⊤)
    (hgU : ∀ i, MemLp (fun u ↦ g u i) 2 (volume.restrict U))
    (hgV : ∀ i, MemLp (fun v ↦ g v i) 2 (volume.restrict V)) :
    AEMeasurable
      (fun p : (Fin n → ℝ) × (Fin n → ℝ) ↦
        ENNReal.ofReal (fractionalIntegrand a g p.1 p.2))
      ((volume.restrict U).prod (volume.restrict V)) := by
  let _ : IsFiniteMeasure (volume.restrict U) := isFiniteMeasure_restrict.mpr hUtop
  let _ : IsFiniteMeasure (volume.restrict V) := isFiniteMeasure_restrict.mpr hVtop
  have hcoord : ∀ i, AEMeasurable
      (fun p : (Fin n → ℝ) × (Fin n → ℝ) ↦ g p.1 i - g p.2 i)
      ((volume.restrict U).prod (volume.restrict V)) := by
    intro i
    exact (hgU i).aestronglyMeasurable.aemeasurable.comp_fst.sub
      (hgV i).aestronglyMeasurable.aemeasurable.comp_snd
  have hnum : AEMeasurable
      (fun p : (Fin n → ℝ) × (Fin n → ℝ) ↦ ∑ i, (g p.1 i - g p.2 i) ^ 2)
      ((volume.restrict U).prod (volume.restrict V)) := by
    have hs := Finset.aemeasurable_sum Finset.univ fun i hi ↦ (hcoord i).pow_const 2
    convert hs using 1
    ext p
    simp only [Finset.sum_apply]
  have hdist : Continuous
      (fun p : (Fin n → ℝ) × (Fin n → ℝ) ↦
        Real.sqrt (∑ j, (p.1 j - p.2 j) ^ 2)) := by fun_prop
  have hden : Measurable
      (fun p : (Fin n → ℝ) × (Fin n → ℝ) ↦
        (Real.sqrt (∑ j, (p.1 j - p.2 j) ^ 2)) ^ a) :=
    (hdist.rpow_const fun p ↦ Or.inr ha.le).measurable
  apply AEMeasurable.ennreal_ofReal
  exact hnum.div hden.aemeasurable

/-- Tonelli identifies the product integral of the locally measurable kernel
with the nested source integral. -/
theorem lintegral_fractionalIntegrand_prod_eq_iterated
    {n m : ℕ} {a : ℝ} (ha : 0 < a)
    (g : (Fin n → ℝ) → Fin m → ℝ)
    {U V : Set (Fin n → ℝ)} (hUtop : volume U ≠ ⊤) (hVtop : volume V ≠ ⊤)
    (hgU : ∀ i, MemLp (fun u ↦ g u i) 2 (volume.restrict U))
    (hgV : ∀ i, MemLp (fun v ↦ g v i) 2 (volume.restrict V)) :
    (∫⁻ p, ENNReal.ofReal (fractionalIntegrand a g p.1 p.2)
        ∂((volume.restrict U).prod (volume.restrict V))) =
      ∫⁻ u in U, ∫⁻ v in V, ENNReal.ofReal (fractionalIntegrand a g u v) := by
  let _ : IsFiniteMeasure (volume.restrict V) := isFiniteMeasure_restrict.mpr hVtop
  exact lintegral_prod _
    (aemeasurable_fractionalIntegrand_prod ha g hUtop hVtop hgU hgV)

/-- Local diagonal fractional-energy control and local `L²` control imply
fractional-energy finiteness on every compact subset. -/
theorem lintegral_fractionalIntegrand_lt_top_of_compact
    {n m : ℕ} {Ω : Set (Fin n → ℝ)}
    (g : (Fin n → ℝ) → Fin m → ℝ) {a : ℝ} (ha : 0 < a)
    (hg : ∀ K : Set (Fin n → ℝ), IsCompact K → K ⊆ Ω → ∀ i,
      MemLp (fun u ↦ g u i) 2 (volume.restrict K))
    (hlocal : ∀ x ∈ Ω, ∃ r > 0, closure (ballSet x r) ⊆ Ω ∧
      (∫⁻ u in ballSet x r, ∫⁻ v in ballSet x r,
        ENNReal.ofReal (fractionalIntegrand a g u v)) < ⊤)
    {A : Set (Fin n → ℝ)} (hA : IsCompact A) (hAΩ : A ⊆ Ω) :
    (∫⁻ u in A, ∫⁻ v in A, ENNReal.ofReal (fractionalIntegrand a g u v)) < ⊤ := by
  let k : ((Fin n → ℝ) × (Fin n → ℝ)) → ENNReal := fun p ↦
    ENNReal.ofReal (fractionalIntegrand a g p.1 p.2)
  let ν := (volume.prod volume).withDensity k
  have hrect (U V : Set (Fin n → ℝ)) (hU : MeasurableSet U) (hV : MeasurableSet V)
      (hUtop : volume U ≠ ⊤) (hVtop : volume V ≠ ⊤)
      (hgU : ∀ i, MemLp (fun u ↦ g u i) 2 (volume.restrict U))
      (hgV : ∀ i, MemLp (fun v ↦ g v i) 2 (volume.restrict V)) :
      ν (U ×ˢ V) = ∫⁻ u in U, ∫⁻ v in V,
        ENNReal.ofReal (fractionalIntegrand a g u v) := by
    change (volume.prod volume).withDensity k (U ×ˢ V) = _
    rw [withDensity_apply k (hU.prod hV), ← Measure.prod_restrict]
    exact lintegral_fractionalIntegrand_prod_eq_iterated ha g hUtop hVtop hgU hgV
  have hfinite_local : ∀ p ∈ A ×ˢ A, ν.FiniteAtFilter (nhdsWithin p (A ×ˢ A)) := by
    intro p hp
    rcases p with ⟨x, y⟩
    by_cases hxy : x = y
    · subst y
      rcases hlocal x (hAΩ hp.1) with ⟨r, hr, hclosure, henergy⟩
      let U := ballSet x r
      have hUtop : volume U ≠ ⊤ := volume_ballSet_ne_top x hr
      have hgU : ∀ i, MemLp (fun u ↦ g u i) 2 (volume.restrict U) := by
        intro i
        exact (hg (closure U) (isCompact_closure_ballSet x hr) hclosure i).mono_measure
          (Measure.restrict_mono subset_closure le_rfl)
      refine ⟨U ×ˢ U, ?_, ?_⟩
      · exact mem_nhdsWithin_iff_exists_mem_nhds_inter.mpr
          ⟨U ×ˢ U, (isOpen_ballSet x r).prod (isOpen_ballSet x r) |>.mem_nhds
            ⟨center_mem_ballSet x hr, center_mem_ballSet x hr⟩, inter_subset_left⟩
      · rw [hrect U U (measurableSet_ballSet x r) (measurableSet_ballSet x r)
          hUtop hUtop hgU hgU]
        exact henergy
    · have hd : 0 < dist (WithLp.toLp 2 x : EuclideanSpace ℝ (Fin n))
          (WithLp.toLp 2 y) := dist_pos.mpr (by
            intro heq
            exact hxy (by simpa using congrArg WithLp.ofLp heq))
      rcases hlocal x (hAΩ hp.1) with ⟨rx, hrx, hxΩ, hxenergy⟩
      rcases hlocal y (hAΩ hp.2) with ⟨ry, hry, hyΩ, hyenergy⟩
      let ρ := min (rx / 2) (min (ry / 2) (dist (WithLp.toLp 2 x : EuclideanSpace ℝ (Fin n))
        (WithLp.toLp 2 y) / 4))
      have hρ : 0 < ρ := by simp [ρ, hrx, hry, hd]
      let U := ballSet x ρ
      let V := ballSet y ρ
      have hρx : ρ ≤ rx := (min_le_left _ _).trans (by linarith)
      have hρy : ρ ≤ ry := (min_le_right _ _ |>.trans (min_le_left _ _)).trans (by linarith)
      have hUx : U ⊆ closure (ballSet x rx) :=
        (ballSet_subset_ballSet x hρ hρx).trans subset_closure
      have hVy : V ⊆ closure (ballSet y ry) :=
        (ballSet_subset_ballSet y hρ hρy).trans subset_closure
      have hgU : ∀ i, MemLp (fun u ↦ g u i) 2 (volume.restrict U) := fun i ↦
        (hg (closure (ballSet x rx)) (isCompact_closure_ballSet x hrx) hxΩ i).mono_measure
          (Measure.restrict_mono hUx le_rfl)
      have hgV : ∀ i, MemLp (fun v ↦ g v i) 2 (volume.restrict V) := fun i ↦
        (hg (closure (ballSet y ry)) (isCompact_closure_ballSet y hry) hyΩ i).mono_measure
          (Measure.restrict_mono hVy le_rfl)
      have hsep : ∀ u ∈ U, ∀ v ∈ V,
          dist (WithLp.toLp 2 x : EuclideanSpace ℝ (Fin n)) (WithLp.toLp 2 y) / 2 ≤
            Real.sqrt (∑ j, (u j - v j) ^ 2) := by
        intro u hu v hv
        have hux := (mem_ballSet_iff_euclidean_dist hρ).mp hu
        have hvy := (mem_ballSet_iff_euclidean_dist hρ).mp hv
        rw [← euclidean_dist_sq, Real.sqrt_sq_eq_abs, abs_of_nonneg dist_nonneg]
        have hρd : ρ ≤ dist (WithLp.toLp 2 x : EuclideanSpace ℝ (Fin n))
            (WithLp.toLp 2 y) / 4 := by simp [ρ]
        calc
          _ ≤ dist (WithLp.toLp 2 x : EuclideanSpace ℝ (Fin n)) (WithLp.toLp 2 y) -
              dist (WithLp.toLp 2 u) (WithLp.toLp 2 x) -
              dist (WithLp.toLp 2 y) (WithLp.toLp 2 v) := by
            have hvy' : dist (WithLp.toLp 2 y) (WithLp.toLp 2 v) < ρ := by
              simpa only [dist_comm] using hvy
            linarith
          _ ≤ dist (WithLp.toLp 2 u) (WithLp.toLp 2 v) := by
            have htri := dist_triangle4 (WithLp.toLp 2 x) (WithLp.toLp 2 u)
              (WithLp.toLp 2 v) (WithLp.toLp 2 y)
            rw [dist_comm (WithLp.toLp 2 x) (WithLp.toLp 2 u),
              dist_comm (WithLp.toLp 2 v) (WithLp.toLp 2 y)] at htri
            linarith
      have hoff := lintegral_fractionalIntegrand_lt_top_of_separated ha (half_pos hd) g
        (measurableSet_ballSet x ρ) (measurableSet_ballSet y ρ)
        (volume_ballSet_ne_top x hρ) (volume_ballSet_ne_top y hρ) hgU hgV hsep
      refine ⟨U ×ˢ V, ?_, ?_⟩
      · exact mem_nhdsWithin_iff_exists_mem_nhds_inter.mpr
          ⟨U ×ˢ V, (isOpen_ballSet x ρ).prod (isOpen_ballSet y ρ) |>.mem_nhds
            ⟨center_mem_ballSet x hρ, center_mem_ballSet y hρ⟩, inter_subset_left⟩
      · rw [hrect U V (measurableSet_ballSet x ρ) (measurableSet_ballSet y ρ)
          (volume_ballSet_ne_top x hρ) (volume_ballSet_ne_top y hρ) hgU hgV]
        exact hoff
  have hνA : ν (A ×ˢ A) < ⊤ := (hA.prod hA).measure_lt_top_of_nhdsWithin hfinite_local
  have hAtop : volume A ≠ ⊤ := hA.measure_ne_top
  have hgA := hg A hA hAΩ
  rw [hrect A A hA.measurableSet hA.measurableSet hAtop hAtop hgA hgA] at hνA
  exact hνA

end AffineCarleson.Internal
