import Frozen.SelfImprovement

noncomputable section
set_option autoImplicit false

open Set MeasureTheory
open scoped ENNReal

namespace AffineCarleson

open Internal

/-- The zero-error source corollary, with constant depending only on n, K, and s. -/
theorem meanOscillation_selfImprovement_zeroError
    (n : ℕ) (hn : 2 ≤ n) (K s : ℝ) (hK : 1 ≤ K) (hs : 0 < s)
    (hs_upper : s <
      Real.log (1 + Real.log 4 / ((4 : ℝ) ^ n * K)) / (2 * Real.log 16)) :
    ∃ c : ℝ, 0 < c ∧
      ∀ (m : ℕ) (Ω : Set (Fin n → ℝ)), IsOpen Ω →
      ∀ g : (Fin n → ℝ) → Fin m → ℝ,
      (∀ A : Set (Fin n → ℝ), IsCompact A → A ⊆ Ω →
        ∀ α : Fin m, MemLp (fun y ↦ g y α) 2 (volume.restrict A)) →
      (∀ (x₀ : Fin n → ℝ) (R : ℝ), 0 < R → R ≤ 1 →
        closure (ballSet x₀ (4 * R)) ⊆ Ω →
        (∫⁻ x in ballSet x₀ R, ∫⁻ r in Ioo (0 : ℝ) R,
          ENNReal.ofReal (ballOscillation x r g / r)) ≤
        ENNReal.ofReal (K * (volume (ballSet x₀ (4 * R))).toReal *
          ballOscillation x₀ (4 * R) g)) →
      (∀ A : Set (Fin n → ℝ), IsCompact A → A ⊆ Ω →
        (∫⁻ x in A, ∫⁻ y in A,
          ENNReal.ofReal ((∑ α, (g x α - g y α) ^ 2) /
            Real.rpow (Real.sqrt (∑ i, (x i - y i) ^ 2)) ((n : ℝ) + 2 * s))) < ⊤) ∧
      (∀ (x₀ : Fin n → ℝ) (R : ℝ), 0 < R → R ≤ 1 →
        closure (ballSet x₀ (8 * R)) ⊆ Ω →
        (∫⁻ x in ballSet x₀ R, ∫⁻ y in ballSet x₀ R,
          ENNReal.ofReal ((∑ α, (g x α - g y α) ^ 2) /
            Real.rpow (Real.sqrt (∑ i, (x i - y i) ^ 2)) ((n : ℝ) + 2 * s))) ≤
        ENNReal.ofReal (c * Real.rpow R (-2 * s) *
          ∫ y in ballSet x₀ (8 * R), ∑ α, (g y α) ^ 2)) := by
  have hσ : 0 < 4 * s := mul_pos (by norm_num) hs
  have hs2 : s < (4 * s) / 2 := by linarith
  have hsmin : s < min
      (Real.log (1 + Real.log 4 / ((4 : ℝ) ^ n * K)) / (2 * Real.log 16))
      ((4 * s) / 2) := lt_min hs_upper hs2
  obtain ⟨c, hc, hmain⟩ := AffineCarleson.meanOscillation_selfImprovement
    n hn K (4 * s) s hK hσ hs hsmin
  refine ⟨c, hc, ?_⟩
  intro m Ω hΩ g hg hrel
  have hzeroInt : ∀ A : Set (Fin n → ℝ), IsCompact A → A ⊆ Ω →
      IntegrableOn (fun _ : Fin n → ℝ ↦ (0 : ℝ)) A := by
    intro A _ _
    exact integrableOn_zero
  have hzeroNonneg : ∀ᵐ y ∂volume.restrict Ω, 0 ≤ (0 : ℝ) := by simp
  have h := hmain m Ω hΩ g (fun _ ↦ 0) 0 (le_refl 0) hg
    hzeroInt hzeroNonneg
  dsimp only at h
  have hout := h (by
    intro x₀ R hR hR1 hinside
    simpa only [ballSet, ballOscillation, zero_mul, add_zero] using
      hrel x₀ R hR hR1 hinside)
  simpa only [ballSet, zero_mul, add_zero] using hout

end AffineCarleson
