import AffineCarleson.SelfImprovement.PairTonelli
import AffineCarleson.SelfImprovement.Geometry
import AffineCarleson.SelfImprovement.BallMeasurability

/-! Close pairs are controlled by the variance averaged over ball centers. -/

noncomputable section
set_option autoImplicit false
open Set MeasureTheory

namespace AffineCarleson.Internal

theorem nearPairs_le_integrated_ballPairs {n : ℕ}
    (Q : (Fin n → ℝ) → (Fin n → ℝ) → ENNReal)
    (hQ : Measurable (Function.uncurry Q)) {r : ℝ} (hr : 0 < r) :
    (ENNReal.ofReal ((1 / 2 : ℝ) ^ n) * volume (ballSet (0 : Fin n → ℝ) r)) *
        (∫⁻ u in ballSet (0 : Fin n → ℝ) 1, ∫⁻ v in ballSet (0 : Fin n → ℝ) 1,
          if dist (WithLp.toLp 2 u : EuclideanSpace ℝ (Fin n)) (WithLp.toLp 2 v) < r
          then Q u v else 0) ≤
      ∫⁻ c in ballSet (0 : Fin n → ℝ) (1 + r),
        ∫⁻ u in ballSet c r, ∫⁻ v in ballSet c r, Q u v := by
  let C := ENNReal.ofReal ((1 / 2 : ℝ) ^ n) * volume (ballSet (0 : Fin n → ℝ) r)
  let W := fun u v : Fin n → ℝ ↦
    volume (ballSet (0 : Fin n → ℝ) (1 + r) ∩ ballSet u r ∩ ballSet v r) * Q u v
  have hC : C ≠ ⊤ := ENNReal.mul_ne_top ENNReal.ofReal_ne_top
    (volume_ballSet_ne_top 0 hr)
  have hpoint (u v : Fin n → ℝ) (hu : u ∈ ballSet 0 1) :
      C * (if dist (WithLp.toLp 2 u : EuclideanSpace ℝ (Fin n)) (WithLp.toLp 2 v) < r
        then Q u v else 0) ≤ W u v := by
    by_cases hd : dist (WithLp.toLp 2 u : EuclideanSpace ℝ (Fin n))
        (WithLp.toLp 2 v) < r
    · rw [if_pos hd]
      have hset : ballSet (0 : Fin n → ℝ) (1 + r) ∩ ballSet u r ∩ ballSet v r =
          ballSet u r ∩ ballSet v r := by
        rw [inter_assoc, inter_eq_right.mpr (common_centers_subset_moving_ball hr hu)]
      dsimp only [W]
      rw [hset]
      exact mul_le_mul' (volume_ballSet_inter_lower u v hr hd.le) le_rfl
    · rw [if_neg hd, mul_zero]
      exact zero_le
  calc
    _ = ∫⁻ u in ballSet (0 : Fin n → ℝ) 1, ∫⁻ v in ballSet (0 : Fin n → ℝ) 1,
        C * (if dist (WithLp.toLp 2 u : EuclideanSpace ℝ (Fin n)) (WithLp.toLp 2 v) < r
          then Q u v else 0) := by
      change C * _ = _
      rw [← lintegral_const_mul' C _ hC]
      apply lintegral_congr
      intro u
      exact (lintegral_const_mul' _ _ hC).symm
    _ ≤ ∫⁻ u in ballSet (0 : Fin n → ℝ) 1, ∫⁻ v in ballSet (0 : Fin n → ℝ) 1,
        W u v := by
      apply setLIntegral_mono' (measurableSet_ballSet 0 1)
      intro u hu
      exact lintegral_mono fun v ↦ hpoint u v hu
    _ ≤ ∫⁻ u, ∫⁻ v, W u v := by
      apply le_trans (lintegral_mono fun u ↦ setLIntegral_le_lintegral _ (W u))
      exact setLIntegral_le_lintegral _ _
    _ = _ := (lintegral_pair_ballSet_centers Q hQ _ r).symm

theorem integrated_ballPairs_eq_oscillation {n m : ℕ}
    (g : (Fin n → ℝ) → Fin m → ℝ) (A U : Set (Fin n → ℝ))
    (hA : MeasurableSet A)
    (hg : ∀ i, MemLp (fun u ↦ g u i) 2 (volume.restrict U))
    {r : ℝ} (hr : 0 < r) (hinside : ∀ c ∈ A, ballSet c r ⊆ U) :
    (∫⁻ c in A, ∫⁻ u in ballSet c r, ∫⁻ v in ballSet c r,
      ENNReal.ofReal (∑ i, (g u i - g v i) ^ 2)) =
      ENNReal.ofReal (2 * (volume (ballSet (0 : Fin n → ℝ) r)).toReal ^ 2) *
        ∫⁻ c in A, ENNReal.ofReal (ballOscillation c r g) := by
  have hrow (c : Fin n → ℝ) (hc : c ∈ A) :
      (∫⁻ u in ballSet c r, ∫⁻ v in ballSet c r,
        ENNReal.ofReal (∑ i, (g u i - g v i) ^ 2)) =
        ENNReal.ofReal (2 * (volume (ballSet (0 : Fin n → ℝ) r)).toReal ^ 2) *
          ENNReal.ofReal (ballOscillation c r g) := by
    rw [lintegral_pairwise_eq_ball_variance c hr g
      (fun i ↦ (hg i).mono_measure (Measure.restrict_mono (hinside c hc) le_rfl)),
      ← ENNReal.ofReal_mul (by positivity :
        0 ≤ 2 * (volume (ballSet (0 : Fin n → ℝ) r)).toReal ^ 2)]
    congr 1
    unfold ballOscillation
    have hvol := volume_ballSet_center c hr
    rw [hvol]
    have hmass := (volume_ballSet_toReal_pos (0 : Fin n → ℝ) hr).ne'
    field_simp
  calc
    _ = ∫⁻ c in A,
        ENNReal.ofReal (2 * (volume (ballSet (0 : Fin n → ℝ) r)).toReal ^ 2) *
          ENNReal.ofReal (ballOscillation c r g) := setLIntegral_congr_fun hA hrow
    _ = _ := lintegral_const_mul' _ _ ENNReal.ofReal_ne_top

theorem nearPairs_le_oscillation {n m : ℕ}
    (g : (Fin n → ℝ) → Fin m → ℝ)
    (hgmeas : ∀ i, Measurable (fun u ↦ g u i))
    (hg : ∀ i, MemLp (fun u ↦ g u i) 2
      (volume.restrict (ballSet (0 : Fin n → ℝ) 8)))
    {r : ℝ} (hr : 0 < r) (hr_one : r ≤ 1) :
    (∫⁻ u in ballSet (0 : Fin n → ℝ) 1, ∫⁻ v in ballSet (0 : Fin n → ℝ) 1,
      if dist (WithLp.toLp 2 u : EuclideanSpace ℝ (Fin n)) (WithLp.toLp 2 v) < r
      then ENNReal.ofReal (∑ i, (g u i - g v i) ^ 2) else 0) ≤
      ENNReal.ofReal ((2 : ℝ) ^ (n + 1) * (volume (ballSet (0 : Fin n → ℝ) r)).toReal) *
        ∫⁻ c in ballSet (0 : Fin n → ℝ) (1 + r),
          ENNReal.ofReal (ballOscillation c r g) := by
  let Q := fun u v : Fin n → ℝ ↦ ENNReal.ofReal (∑ i, (g u i - g v i) ^ 2)
  have hQ : Measurable (Function.uncurry Q) := by
    apply Measurable.ennreal_ofReal
    exact Finset.measurable_sum Finset.univ fun i _ ↦
      ((hgmeas i).comp measurable_fst |>.sub ((hgmeas i).comp measurable_snd)).pow_const 2
  have hinside : ∀ c ∈ ballSet (0 : Fin n → ℝ) (1 + r), ballSet c r ⊆ ballSet 0 8 := by
    intro c hc
    exact (moving_ballSet_subset (a := 1) (t := r) zero_lt_one hr le_rfl hc).trans
      (ballSet_subset_ballSet 0 (by positivity) (by linarith))
  have hbound := nearPairs_le_integrated_ballPairs Q hQ hr
  rw [integrated_ballPairs_eq_oscillation g _ _ (measurableSet_ballSet 0 (1 + r))
    hg hr hinside] at hbound
  let V := volume (ballSet (0 : Fin n → ℝ) r)
  let C := ENNReal.ofReal ((1 / 2 : ℝ) ^ n) * V
  have hVzero : V ≠ 0 := (volume_ballSet_pos 0 hr).ne'
  have hVtop : V ≠ ⊤ := volume_ballSet_ne_top 0 hr
  have hCzero : C ≠ 0 := mul_ne_zero (ENNReal.ofReal_pos.mpr (by positivity)).ne' hVzero
  have hCtop : C ≠ ⊤ := ENNReal.mul_ne_top ENNReal.ofReal_ne_top hVtop
  have hfactor : ENNReal.ofReal (2 * V.toReal ^ 2) =
      C * ENNReal.ofReal ((2 : ℝ) ^ (n + 1) * V.toReal) := by
    have hpow : (1 / 2 : ℝ) ^ n * 2 ^ (n + 1) = 2 := by
      rw [pow_succ, ← mul_assoc, ← mul_pow]
      norm_num
    dsimp only [C]
    rw [← ENNReal.ofReal_toReal hVtop,
      ← ENNReal.ofReal_mul (by positivity : 0 ≤ (1 / 2 : ℝ) ^ n),
      ← ENNReal.ofReal_mul (by positivity : 0 ≤ (1 / 2 : ℝ) ^ n * V.toReal)]
    simp only [ENNReal.toReal_ofReal ENNReal.toReal_nonneg]
    congr 1
    calc
      2 * V.toReal ^ 2 = ((1 / 2 : ℝ) ^ n * 2 ^ (n + 1)) * V.toReal ^ 2 := by rw [hpow]
      _ = _ := by ring
  change C * _ ≤ ENNReal.ofReal (2 * V.toReal ^ 2) * _ at hbound
  rw [hfactor] at hbound
  exact (ENNReal.mul_le_mul_iff_right hCzero hCtop).mp
    (hbound.trans_eq (mul_assoc _ _ _))

end AffineCarleson.Internal
