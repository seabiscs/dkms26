import AffineCarleson.SelfImprovement.GeneralBallBound
import AffineCarleson.SelfImprovement.CompactFractional
import AffineCarleson.SelfImprovement.LocalBalls

noncomputable section
set_option autoImplicit false
open MeasureTheory

namespace AffineCarleson.Internal

/-- The abstract self-improvement lemma: the source Carleson-type hypothesis
implies local fractional regularity and the quantitative Gagliardo estimate.
The constant is chosen before the output dimension, domain, functions,
error coefficient, center, and radius. -/
theorem meanOscillation_selfImprovement
    (n : ℕ) (hn : 2 ≤ n)
    (K σ s : ℝ) (hK : 1 ≤ K) (hσ : 0 < σ) (hs : 0 < s)
    (hs_upper : s < min
      (Real.log (1 + Real.log 4 / ((4 : ℝ) ^ n * K)) / (2 * Real.log 16))
      (σ / 2)) :
    ∃ c : ℝ, 0 < c ∧
      ∀ (m : ℕ) (Ω : Set (Fin n → ℝ)), IsOpen Ω →
      ∀ (g : (Fin n → ℝ) → Fin m → ℝ) (μ : (Fin n → ℝ) → ℝ)
        (M : ℝ), 0 ≤ M →
      (∀ A : Set (Fin n → ℝ), IsCompact A → A ⊆ Ω →
        ∀ α : Fin m, MemLp (fun y => g y α) 2 (volume.restrict A)) →
      (∀ A : Set (Fin n → ℝ), IsCompact A → A ⊆ Ω → IntegrableOn μ A) →
      (∀ᵐ y ∂volume.restrict Ω, 0 ≤ μ y) →
      let ball : (Fin n → ℝ) → ℝ → Set (Fin n → ℝ) :=
        fun x r => {y | ∑ i, (y i - x i) ^ 2 < r ^ 2}
      let mean : (Fin n → ℝ) → ℝ → Fin m → ℝ :=
        fun x r α => (volume (ball x r)).toReal⁻¹ * (∫ y in ball x r, g y α)
      let osc : (Fin n → ℝ) → ℝ → ℝ := fun x r =>
        (volume (ball x r)).toReal⁻¹ *
          (∫ y in ball x r, ∑ α, (g y α - mean x r α) ^ 2)
      let fractionalEnergy : Set (Fin n → ℝ) → ENNReal := fun A =>
        ∫⁻ x in A, ∫⁻ y in A,
          ENNReal.ofReal ((∑ α, (g x α - g y α) ^ 2) /
            Real.rpow (Real.sqrt (∑ i, (x i - y i) ^ 2)) ((n : ℝ) + 2 * s))
      (∀ (x₀ : Fin n → ℝ) (R : ℝ), 0 < R → R ≤ 1 →
        closure (ball x₀ (4 * R)) ⊆ Ω →
        (∫⁻ x in ball x₀ R, ∫⁻ r in Set.Ioo (0 : ℝ) R,
          ENNReal.ofReal (osc x r / r)) ≤
        ENNReal.ofReal (K * (volume (ball x₀ (4 * R))).toReal * osc x₀ (4 * R) +
          M * Real.rpow R σ * (∫ y in ball x₀ (4 * R), μ y))) →
      (∀ A : Set (Fin n → ℝ), IsCompact A → A ⊆ Ω → fractionalEnergy A < ⊤) ∧
      (∀ (x₀ : Fin n → ℝ) (R : ℝ), 0 < R → R ≤ 1 →
        closure (ball x₀ (8 * R)) ⊆ Ω →
        fractionalEnergy (ball x₀ R) ≤
          ENNReal.ofReal (c * Real.rpow R (-2 * s) *
            ((∫ y in ball x₀ (8 * R), ∑ α, (g y α) ^ 2) +
              M * Real.rpow R σ * (∫ y in ball x₀ (8 * R), μ y)))) := by
  obtain ⟨C, hC, hbound⟩ := ball_selfImprovement n K σ s hK hσ hs hs_upper
  refine ⟨C, hC, ?_⟩
  intro m Ω hΩ g μ M hM hg hμ hμnonneg
  dsimp only
  intro hrel
  have hquant : ∀ (x₀ : Fin n → ℝ) (R : ℝ), 0 < R → R ≤ 1 →
      closure (ballSet x₀ (8 * R)) ⊆ Ω →
      (∫⁻ u in ballSet x₀ R, ∫⁻ v in ballSet x₀ R,
        ENNReal.ofReal ((∑ i, (g u i - g v i) ^ 2) /
          (Real.sqrt (∑ i, (u i - v i) ^ 2)) ^ ((n : ℝ) + 2 * s))) ≤
        ENNReal.ofReal (C * R ^ (-2 * s) *
          ((∫ u in ballSet x₀ (8 * R), ∑ i, g u i ^ 2) +
            M * R ^ σ * ∫ u in ballSet x₀ (8 * R), μ u)) := by
    intro x₀ R hR hR1 hinside
    have hcompact := isCompact_closure_ballSet x₀ (by positivity : 0 < 8 * R)
    have hgball : ∀ i, MemLp (fun u ↦ g u i) 2 (volume.restrict (ballSet x₀ (8 * R))) :=
      fun i ↦ (hg _ hcompact hinside i).mono_measure
        (Measure.restrict_mono subset_closure le_rfl)
    have hμball : IntegrableOn μ (ballSet x₀ (8 * R)) :=
      (hμ _ hcompact hinside).mono_set subset_closure
    have hμpos : ∀ᵐ u ∂volume.restrict (ballSet x₀ (8 * R)), 0 ≤ μ u :=
      ae_mono (Measure.restrict_mono (subset_closure.trans hinside) le_rfl) hμnonneg
    apply hbound m g μ M x₀ R hR hM hgball hμball hμpos
    intro c t ht htR hsub
    exact hrel c t ht (htR.trans hR1) ((closure_mono hsub).trans hinside)
  have ha : 0 < (n : ℝ) + 2 * s := by
    have hnpos : 0 < (n : ℝ) := by exact_mod_cast (lt_of_lt_of_le (by decide : 0 < 2) hn)
    linarith only [hnpos, hs]
  have hlocal : ∀ x ∈ Ω, ∃ r > 0, closure (ballSet x r) ⊆ Ω ∧
      (∫⁻ u in ballSet x r, ∫⁻ v in ballSet x r,
        ENNReal.ofReal (fractionalIntegrand ((n : ℝ) + 2 * s) g u v)) < ⊤ := by
    intro x hx
    obtain ⟨r, hr, hr1, hinside⟩ := exists_enlarged_ballSet_closure_subset hΩ hx
    refine ⟨r, hr, ?_, ?_⟩
    · exact (closure_mono (ballSet_subset_ballSet x hr (by linarith only [hr]))).trans hinside
    · exact (hquant x r hr hr1 hinside).trans_lt ENNReal.ofReal_lt_top
  constructor
  · intro A hA hAΩ
    exact lintegral_fractionalIntegrand_lt_top_of_compact g ha hg hlocal hA hAΩ
  · exact hquant

end AffineCarleson.Internal
