import AffineCarleson.SelfImprovement.RelativeTail

/-! The source-shaped relative oscillation estimate at a variable scale. -/

noncomputable section
set_option autoImplicit false
open Set MeasureTheory
open scoped BigOperators ENNReal

namespace AffineCarleson.Internal

/-- Center averaging converts a relative estimate at scale `t` into the tail estimate. -/
theorem relative_scale_le
    {n m : ℕ} (g : (Fin n → ℝ) → Fin m → ℝ)
    (hgmeas : ∀ i, Measurable (fun y ↦ g y i))
    (μ : (Fin n → ℝ) → ℝ) (hμmeas : Measurable μ)
    (hμnonneg : ∀ y, 0 ≤ μ y) (hμint : IntegrableOn μ (ballSet 0 8))
    {K M σ t : ℝ} (hK : 1 ≤ K) (hM : 0 ≤ M) (ht : 0 < t) (ht_upper : t ≤ 1 / 4)
    (hrel : ∀ c ∈ ballSet (0 : Fin n → ℝ) (1 + 2 * t),
      (∫⁻ x in ballSet c t, ∫⁻ r in Ioo (0 : ℝ) t,
        ENNReal.ofReal (ballOscillation x r g / r)) ≤
      ENNReal.ofReal
        (K * (volume (ballSet c (4 * t))).toReal * ballOscillation c (4 * t) g +
          M * t ^ σ * ∫ y in ballSet c (4 * t), μ y)) :
    (∫⁻ r in Ioo (0 : ℝ) t, ∫⁻ x in ballSet (0 : Fin n → ℝ) (1 + r),
      ENNReal.ofReal (ballOscillation x r g / r)) ≤
      ENNReal.ofReal ((4 : ℝ) ^ n * K) *
          (∫⁻ c in ballSet (0 : Fin n → ℝ) (1 + 4 * t),
            ENNReal.ofReal (ballOscillation c (4 * t) g)) +
        ENNReal.ofReal ((4 : ℝ) ^ n * M * t ^ σ) *
          (∫⁻ y in ballSet (0 : Fin n → ℝ) 8, ENNReal.ofReal (μ y)) := by
  let F : (Fin n → ℝ) → ℝ → ENNReal := fun x r ↦
    ENNReal.ofReal (ballOscillation x r g / r)
  let O : ENNReal := ∫⁻ c in ballSet (0 : Fin n → ℝ) (1 + 4 * t),
    ENNReal.ofReal (ballOscillation c (4 * t) g)
  let Q : ENNReal := ∫⁻ y in ballSet (0 : Fin n → ℝ) 8, ENNReal.ofReal (μ y)
  let Vt := volume (ballSet (0 : Fin n → ℝ) t)
  let V4t := volume (ballSet (0 : Fin n → ℝ) (4 * t))
  have h4t : 0 < 4 * t := mul_pos (by norm_num) ht
  have hFmeas : Measurable (Function.uncurry F) := by
    apply Measurable.ennreal_ofReal
    exact (measurable_ballOscillation g hgmeas).div measurable_snd
  have hlower : Vt * (∫⁻ r in Ioo (0 : ℝ) t,
      ∫⁻ x in ballSet (0 : Fin n → ℝ) (1 + r), F x r) ≤
      ∫⁻ c in ballSet (0 : Fin n → ℝ) (1 + 2 * t),
        ∫⁻ x in ballSet c t, ∫⁻ r in Ioo (0 : ℝ) t, F x r := by
    simpa [Vt] using integrated_centers_lower F hFmeas ht
  have hrelative : (∫⁻ c in ballSet (0 : Fin n → ℝ) (1 + 2 * t),
      ∫⁻ x in ballSet c t, ∫⁻ r in Ioo (0 : ℝ) t, F x r) ≤
      ∫⁻ c in ballSet (0 : Fin n → ℝ) (1 + 2 * t),
        ENNReal.ofReal
          (K * (volume (ballSet c (4 * t))).toReal * ballOscillation c (4 * t) g +
            M * t ^ σ * ∫ y in ballSet c (4 * t), μ y) :=
    setLIntegral_mono' (measurableSet_ballSet 0 (1 + 2 * t)) hrel
  have hμlocal : ∀ c ∈ ballSet (0 : Fin n → ℝ) (1 + 2 * t),
      IntegrableOn μ (ballSet c (4 * t)) := by
    intro c hc
    apply hμint.mono_set
    have hd := (mem_ballSet_iff_euclidean_dist (by linarith : 0 < 1 + 2 * t)).mp hc
    exact ballSet_subset_of_dist_add_le h4t (by norm_num) (by linarith)
  let C : ℝ := M * t ^ σ
  have hC : 0 ≤ C := mul_nonneg hM (Real.rpow_nonneg ht.le σ)
  have hsplit : (∫⁻ c in ballSet (0 : Fin n → ℝ) (1 + 2 * t),
      ENNReal.ofReal
        (K * (volume (ballSet c (4 * t))).toReal * ballOscillation c (4 * t) g +
          M * t ^ σ * ∫ y in ballSet c (4 * t), μ y)) =
      ENNReal.ofReal (K * V4t.toReal) *
          (∫⁻ c in ballSet (0 : Fin n → ℝ) (1 + 2 * t),
            ENNReal.ofReal (ballOscillation c (4 * t) g)) +
        ENNReal.ofReal C *
          (∫⁻ c in ballSet (0 : Fin n → ℝ) (1 + 2 * t),
            ∫⁻ y in ballSet c (4 * t), ENNReal.ofReal (μ y)) := by
    have hpoint : ∀ c ∈ ballSet (0 : Fin n → ℝ) (1 + 2 * t),
        ENNReal.ofReal
          (K * (volume (ballSet c (4 * t))).toReal * ballOscillation c (4 * t) g +
            M * t ^ σ * ∫ y in ballSet c (4 * t), μ y) =
        ENNReal.ofReal (K * V4t.toReal) * ENNReal.ofReal (ballOscillation c (4 * t) g) +
          ENNReal.ofReal C * (∫⁻ y in ballSet c (4 * t), ENNReal.ofReal (μ y)) := by
      intro c hc
      have hosc : 0 ≤ K * (volume (ballSet c (4 * t))).toReal *
          ballOscillation c (4 * t) g :=
        mul_nonneg (mul_nonneg (zero_le_one.trans hK) ENNReal.toReal_nonneg)
          (ballOscillation_nonneg c h4t g)
      have hV : (volume (ballSet c (4 * t))).toReal = V4t.toReal := by
        rw [volume_ballSet_center c h4t]
      have hCi : 0 ≤ C * ∫ y in ballSet c (4 * t), μ y :=
        mul_nonneg hC (integral_nonneg hμnonneg)
      change ENNReal.ofReal (_ + C * ∫ y in ballSet c (4 * t), μ y) = _
      rw [ENNReal.ofReal_add hosc,
        ENNReal.ofReal_mul (mul_nonneg (zero_le_one.trans hK) ENNReal.toReal_nonneg),
        hV, ENNReal.ofReal_mul hC,
        ofReal_integral_eq_lintegral_ofReal (hμlocal c hc)
          (Filter.Eventually.of_forall hμnonneg)]
      exact hCi
    calc
      _ = ∫⁻ c in ballSet (0 : Fin n → ℝ) (1 + 2 * t),
          (ENNReal.ofReal (K * V4t.toReal) * ENNReal.ofReal (ballOscillation c (4 * t) g) +
            ENNReal.ofReal C * (∫⁻ y in ballSet c (4 * t), ENNReal.ofReal (μ y))) :=
        setLIntegral_congr_fun (measurableSet_ballSet 0 (1 + 2 * t)) hpoint
      _ = _ := by
        rw [lintegral_add_left,
          lintegral_const_mul' _ _ ENNReal.ofReal_ne_top,
          lintegral_const_mul' _ _ ENNReal.ofReal_ne_top]
        exact (Measurable.const_mul
          ((measurable_ballOscillation g hgmeas).comp
            (measurable_id.prodMk measurable_const)).ennreal_ofReal _)
  have hcenters : ballSet (0 : Fin n → ℝ) (1 + 2 * t) ⊆ ballSet 0 (1 + 4 * t) :=
    ballSet_subset_ballSet 0 (by linarith) (by linarith)
  have hosc : (∫⁻ c in ballSet (0 : Fin n → ℝ) (1 + 2 * t),
      ENNReal.ofReal (ballOscillation c (4 * t) g)) ≤ O := by
    exact lintegral_mono' (Measure.restrict_mono hcenters le_rfl) le_rfl
  have herr : (∫⁻ c in ballSet (0 : Fin n → ℝ) (1 + 2 * t),
      ∫⁻ y in ballSet c (4 * t), ENNReal.ofReal (μ y)) ≤ V4t * Q := by
    simpa [V4t, Q] using integrated_centers_error_upper
      (fun y ↦ ENNReal.ofReal (μ y)) (hμmeas.ennreal_ofReal) ht ht_upper
  have hupper : Vt * (∫⁻ r in Ioo (0 : ℝ) t,
      ∫⁻ x in ballSet (0 : Fin n → ℝ) (1 + r), F x r) ≤
      ENNReal.ofReal (K * V4t.toReal) * O + ENNReal.ofReal C * (V4t * Q) := by
    calc
      _ ≤ ∫⁻ c in ballSet (0 : Fin n → ℝ) (1 + 2 * t),
          ENNReal.ofReal
            (K * (volume (ballSet c (4 * t))).toReal * ballOscillation c (4 * t) g +
              M * t ^ σ * ∫ y in ballSet c (4 * t), μ y) := hlower.trans hrelative
      _ = _ := hsplit
      _ ≤ _ := add_le_add (mul_le_mul_right hosc _) (mul_le_mul_right herr _)
  have hVscale : V4t = ENNReal.ofReal ((4 : ℝ) ^ n) * Vt := by
    simpa [Vt, V4t] using volume_ballSet_mul (0 : Fin n → ℝ)
      (a := (4 : ℝ)) (r := t) (by norm_num) ht
  have hVzero : Vt ≠ 0 := (volume_ballSet_pos 0 ht).ne'
  have hVtop : Vt ≠ ⊤ := volume_ballSet_ne_top 0 ht
  have hKreal : ENNReal.ofReal (K * V4t.toReal) = ENNReal.ofReal K * V4t := by
    rw [ENNReal.ofReal_mul (zero_le_one.trans hK), ENNReal.ofReal_toReal]
    exact volume_ballSet_ne_top 0 h4t
  rw [hKreal, hVscale] at hupper
  let T := ∫⁻ r in Ioo (0 : ℝ) t,
    ∫⁻ x in ballSet (0 : Fin n → ℝ) (1 + r), F x r
  let R := ENNReal.ofReal ((4 : ℝ) ^ n * K) * O +
    ENNReal.ofReal ((4 : ℝ) ^ n * M * t ^ σ) * Q
  have hscaled : Vt * T ≤ Vt * R := by
    dsimp only [T, R]
    rw [ENNReal.ofReal_mul (by positivity : 0 ≤ (4 : ℝ) ^ n),
      show (4 : ℝ) ^ n * M * t ^ σ = (4 : ℝ) ^ n * C by simp [C, mul_assoc],
      ENNReal.ofReal_mul (by positivity : 0 ≤ (4 : ℝ) ^ n)]
    convert hupper using 1
    all_goals ring
  calc
    (∫⁻ r in Ioo (0 : ℝ) t, ∫⁻ x in ballSet (0 : Fin n → ℝ) (1 + r),
      ENNReal.ofReal (ballOscillation x r g / r)) = Vt⁻¹ * (Vt * T) := by
        rw [← mul_assoc, ENNReal.inv_mul_cancel hVzero hVtop, one_mul]
    _ ≤ Vt⁻¹ * (Vt * R) := mul_le_mul_right hscaled _
    _ = ENNReal.ofReal ((4 : ℝ) ^ n * K) * O +
        ENNReal.ofReal ((4 : ℝ) ^ n * M * t ^ σ) * Q := by
      rw [← mul_assoc, ENNReal.inv_mul_cancel hVzero hVtop, one_mul]

end AffineCarleson.Internal
