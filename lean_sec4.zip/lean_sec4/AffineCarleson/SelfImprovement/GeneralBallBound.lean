import AffineCarleson.SelfImprovement.UnitBound
import AffineCarleson.SelfImprovement.AffineRelative
import AffineCarleson.SelfImprovement.AffineBallGeometry
import AffineCarleson.SelfImprovement.ScaledBound
import AffineCarleson.SelfImprovement.MeasurableRepresentative
import AffineCarleson.SelfImprovement.RelativeCongruence

/-! The quantitative estimate with the original local a.e. data on a general ball. -/

noncomputable section
set_option autoImplicit false
open Set MeasureTheory

namespace AffineCarleson.Internal

theorem ball_selfImprovement (n : ℕ) (K σ s : ℝ)
    (hK : 1 ≤ K) (hσ : 0 < σ) (hs : 0 < s)
    (hsmax : s < min
      (Real.log (1 + Real.log 4 / ((4 : ℝ) ^ n * K)) / (2 * Real.log 16)) (σ / 2)) :
    ∃ C : ℝ, 0 < C ∧ ∀ (m : ℕ)
      (g : (Fin n → ℝ) → Fin m → ℝ) (μ : (Fin n → ℝ) → ℝ) (M : ℝ)
      (x₀ : Fin n → ℝ) (R : ℝ), 0 < R → 0 ≤ M →
      (∀ i, MemLp (fun u ↦ g u i) 2 (volume.restrict (ballSet x₀ (8 * R)))) →
      IntegrableOn μ (ballSet x₀ (8 * R)) →
      (∀ᵐ u ∂volume.restrict (ballSet x₀ (8 * R)), 0 ≤ μ u) →
      (∀ (c : Fin n → ℝ) (t : ℝ), 0 < t → t ≤ R →
        ballSet c (4 * t) ⊆ ballSet x₀ (8 * R) →
        (∫⁻ x in ballSet c t, ∫⁻ r in Ioo (0 : ℝ) t,
          ENNReal.ofReal (ballOscillation x r g / r)) ≤
        ENNReal.ofReal (K * (volume (ballSet c (4 * t))).toReal * ballOscillation c (4 * t) g +
          M * t ^ σ * ∫ y in ballSet c (4 * t), μ y)) →
      (∫⁻ u in ballSet x₀ R, ∫⁻ v in ballSet x₀ R,
        ENNReal.ofReal ((∑ i, (g u i - g v i) ^ 2) /
          (Real.sqrt (∑ i, (u i - v i) ^ 2)) ^ ((n : ℝ) + 2 * s))) ≤
        ENNReal.ofReal (C * R ^ (-2 * s) *
          ((∫ u in ballSet x₀ (8 * R), ∑ i, g u i ^ 2) +
            M * R ^ σ * ∫ u in ballSet x₀ (8 * R), μ u)) := by
  obtain ⟨C, hC, hunit⟩ := unit_selfImprovement n K σ s hK hσ hs hsmax
  refine ⟨C, hC, ?_⟩
  intro m g μ M x₀ R hR hM hg hμint hμnonneg hrel
  obtain ⟨h, hhmeas, hhg, hhLp⟩ := exists_measurable_l2_representative g hg
  obtain ⟨ν, hνmeas, hνnonneg, hνμ, hνint⟩ :=
    exists_measurable_nonneg_representative μ hμint hμnonneg
  let T := fun y : Fin n → ℝ ↦ fun i ↦ x₀ i + R * y i
  let G := fun y ↦ h (T y)
  let Q := fun y ↦ ν (T y)
  have hT : Measurable T := by fun_prop
  have hGmeas : ∀ i, Measurable (fun y ↦ G y i) := fun i ↦ (hhmeas i).comp hT
  have hGLp : ∀ i, MemLp (fun y ↦ G y i) 2
      (volume.restrict (ballSet (0 : Fin n → ℝ) 8)) := by
    intro i
    apply memLp_comp_affineScale_ball (f := fun u ↦ h u i) (p := 2) (r := 8) x₀ 0 hR
    simpa only [Pi.zero_apply, mul_zero, add_zero, mul_comm R 8] using hhLp i
  have hQint : IntegrableOn Q (ballSet (0 : Fin n → ℝ) 8) := by
    apply IntegrableOn.comp_affineScale_ball (f := ν) (r := 8) x₀ 0 hR
    simpa only [Pi.zero_apply, mul_zero, add_zero, mul_comm R 8, IntegrableOn] using hνint
  have hnormalized : ∀ t ∈ Ioc (0 : ℝ) 1,
      ∀ c ∈ ballSet (0 : Fin n → ℝ) (1 + 2 * t),
        (∫⁻ x in ballSet c t, ∫⁻ r in Ioo (0 : ℝ) t,
          ENNReal.ofReal (ballOscillation x r G / r)) ≤
        ENNReal.ofReal (K * (volume (ballSet c (4 * t))).toReal * ballOscillation c (4 * t) G +
          (M * R ^ σ) * t ^ σ * ∫ y in ballSet c (4 * t), Q y) := by
    intro t ht c hc
    have htR : R * t ≤ R := by nlinarith only [ht.2, hR]
    have hsub := rescaled_relative_ball_subset x₀ hR ht.1 ht.2 hc
    have hsource := hrel (T c) (R * t) (mul_pos hR ht.1) htR hsub
    have hrep := relative_inequality_congr_ae g h (fun i ↦ (hhg i).symm)
      μ ν hνμ.symm (mul_pos hR ht.1) (T c) hsub K M σ hsource
    exact relativeOscillation_le_affineScale h hhmeas ν x₀ c hR ht.1 hrep
  have hscaled := hunit m G Q (M * R ^ σ) hGmeas hGLp (hνmeas.comp hT)
    (fun u ↦ hνnonneg (T u)) hQint (mul_nonneg hM (Real.rpow_nonneg hR.le _)) hnormalized
  have hbound := fractionalEnergy_le_of_scaled_unit_bound h hhmeas ν C M σ s x₀ hR hscaled
  have hsmall : ballSet x₀ R ⊆ ballSet x₀ (8 * R) :=
    ballSet_subset_ballSet x₀ hR (by linarith only [hR])
  have henergy := lintegral_gagliardo_congr_ae (s := s) h g hhg hsmall
  have hsquares : (fun u ↦ ∑ i, h u i ^ 2) =ᵐ[volume.restrict (ballSet x₀ (8 * R))]
      (fun u ↦ ∑ i, g u i ^ 2) := by
    filter_upwards [ae_all_iff.2 hhg] with u hu
    exact Finset.sum_congr rfl fun i _ ↦ congrArg (fun z : ℝ ↦ z ^ 2) (hu i)
  rw [henergy, integral_congr_ae hsquares, integral_congr_ae hνμ] at hbound
  exact hbound

end AffineCarleson.Internal
