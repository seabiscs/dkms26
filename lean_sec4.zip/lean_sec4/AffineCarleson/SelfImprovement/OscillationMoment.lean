import AffineCarleson.SelfImprovement.TailMeasure
import AffineCarleson.SelfImprovement.TailMoment

/-!
Composition of the density measure and the contraction-to-moment argument.
The contraction and finite unweighted tail remain explicit internal premises;
their derivation from the ball-oscillation hypothesis is a separate obligation.
-/

noncomputable section
set_option autoImplicit false
open Set MeasureTheory

namespace AffineCarleson.Internal

theorem oscillation_weightedMoment_of_tail_contract
    (n : ℕ) (K σ s : ℝ) (hK : 1 ≤ K) (hs : 0 < s)
    (hsmax : s < min
      (Real.log (1 + Real.log 4 / ((4 : ℝ) ^ n * K)) / (2 * Real.log 16))
      (σ / 2)) :
    ∃ C : ℝ, 0 < C ∧ ∀ (E : ℝ → ℝ) (B : ℝ), 0 ≤ B → Measurable E →
      (∀ r ∈ Ioo (0 : ℝ) 1, 0 ≤ E r) →
      (∫⁻ r in Ioo (0 : ℝ) 1, ENNReal.ofReal (E r / r)) ≠ ⊤ →
      (∀ r ∈ Ioc (0 : ℝ) (1 / 16),
        (∫⁻ t in Ioo (0 : ℝ) r, ENNReal.ofReal (E t / t)).toReal ≤
          ((4 : ℝ) ^ n * K / ((4 : ℝ) ^ n * K + Real.log 4)) *
            (∫⁻ t in Ioo (0 : ℝ) (16 * r), ENNReal.ofReal (E t / t)).toReal +
              B * r ^ σ) →
      (∫⁻ r in Ioo (0 : ℝ) 1, ENNReal.ofReal (r ^ (-(2 * s)) * E r / r)) ≤
        ENNReal.ofReal (C *
          ((∫⁻ r in Ioo (0 : ℝ) 1, ENNReal.ofReal (E r / r)).toReal + B)) := by
  obtain ⟨C, hC, hmoment⟩ := weightedMoment_of_contract n K σ s hK hs hsmax
  refine ⟨C, hC, ?_⟩
  intro E B hB hEmeas hEnonneg hfinite hcontract
  have hfinite' : tailMeasure E (Ioc 0 1) ≠ ⊤ := by
    simpa only [tailMeasure_Ioc_eq_lintegral_Ioo] using hfinite
  have hcontract' : ∀ r ∈ Ioc (0 : ℝ) (1 / 16),
      (tailMeasure E (Ioc 0 r)).toReal ≤
        ((4 : ℝ) ^ n * K / ((4 : ℝ) ^ n * K + Real.log 4)) *
          (tailMeasure E (Ioc 0 (16 * r))).toReal + B * r ^ σ := by
    simpa only [tailMeasure_Ioc_eq_lintegral_Ioo] using hcontract
  have h := hmoment (tailMeasure E) B hB hfinite' hcontract'
  rw [lintegral_inversePower_tailMeasure E (2 * s) hEmeas hEnonneg,
    tailMeasure_Ioc_eq_lintegral_Ioo] at h
  exact h

end AffineCarleson.Internal
