import Mathlib.Analysis.SpecialFunctions.Pow.Integral
import Mathlib.Analysis.SpecialFunctions.ImproperIntegrals
import Mathlib.Tactic

/-!
# Distribution bounds for inverse-power moments

This file records the set-theoretic and measure-theoretic input for applying the layer-cake
formula to inverse powers on `(0, 1]`.
-/

open Set MeasureTheory

namespace AffineCarleson.Internal

theorem inversePower_superlevel_subset {q t : ℝ} (hq : 0 < q) (ht : 1 ≤ t) :
    Ioc (0 : ℝ) 1 ∩ {r | t < r ^ (-q)} ⊆ Ioc 0 (t ^ (-(q⁻¹))) := by
  intro r hr
  have htpos : 0 < t := zero_lt_one.trans_le ht
  have hthreshold : t ^ (-(q⁻¹)) ≤ 1 :=
    Real.rpow_le_one_of_one_le_of_nonpos ht (neg_nonpos.mpr (inv_nonneg.mpr hq.le))
  refine ⟨hr.1.1, ?_⟩
  have hrlt : r < t ^ (-q)⁻¹ :=
    (Real.lt_rpow_inv_iff_of_neg hr.1.1 htpos (neg_neg_of_pos hq)).2 hr.2
  simpa only [inv_neg] using hrlt.le

theorem inversePower_superlevel_measure_le {q γ A t : ℝ} {ν : Measure ℝ}
    (hq : 0 < q) (ht : 1 ≤ t)
    (hν : ∀ r, 0 < r → r ≤ 1 → ν (Ioc 0 r) ≤ ENNReal.ofReal (A * r ^ γ)) :
    (ν.restrict (Ioc 0 1)) {r | t < r ^ (-q)} ≤
      ENNReal.ofReal (A * t ^ (-γ / q)) := by
  rw [Measure.restrict_apply' measurableSet_Ioc]
  calc
    ν ({r : ℝ | t < r ^ (-q)} ∩ Ioc 0 1) ≤ ν (Ioc 0 (t ^ (-(q⁻¹)))) := by
      apply measure_mono
      rw [inter_comm]
      exact inversePower_superlevel_subset hq ht
    _ ≤ ENNReal.ofReal (A * t ^ (-γ / q)) := by
      calc
        ν (Ioc 0 (t ^ (-(q⁻¹)))) ≤ ENNReal.ofReal (A * (t ^ (-(q⁻¹))) ^ γ) := by
          apply hν
          · exact Real.rpow_pos_of_pos (zero_lt_one.trans_le ht) _
          · exact Real.rpow_le_one_of_one_le_of_nonpos ht
              (neg_nonpos.mpr (inv_nonneg.mpr hq.le))
        _ = ENNReal.ofReal (A * t ^ (-γ / q)) := by
          congr 2
          rw [← Real.rpow_mul (zero_lt_one.trans_le ht).le]
          congr 1
          field_simp

theorem inversePower_weightedMoment_le {q γ A : ℝ} {ν : Measure ℝ}
    (hA : 0 ≤ A) (hq : 0 < q) (hqγ : q < γ)
    (hν : ∀ r, 0 < r → r ≤ 1 → ν (Ioc 0 r) ≤ ENNReal.ofReal (A * r ^ γ)) :
    ∫⁻ r in Ioc (0 : ℝ) 1, ENNReal.ofReal (r ^ (-q)) ∂ν ≤
      ENNReal.ofReal (A * (γ / (γ - q))) := by
  let μ := ν.restrict (Ioc (0 : ℝ) 1)
  have hf_nn : 0 ≤ᵐ[μ] fun r : ℝ ↦ r ^ (-q) := by
    filter_upwards [self_mem_ae_restrict measurableSet_Ioc] with r hr
    exact Real.rpow_nonneg hr.1.le _
  have hf_meas : AEMeasurable (fun r : ℝ ↦ r ^ (-q)) μ := by
    apply (continuousOn_id.rpow_const fun r hr ↦ Or.inl hr.1.ne').aemeasurable
    exact measurableSet_Ioc
  rw [MeasureTheory.lintegral_eq_lintegral_meas_lt μ hf_nn hf_meas]
  have hmass : μ Set.univ ≤ ENNReal.ofReal A := by
    change (ν.restrict (Ioc (0 : ℝ) 1)) Set.univ ≤ ENNReal.ofReal A
    rw [Measure.restrict_apply' measurableSet_Ioc, univ_inter]
    simpa only [mul_one, Real.one_rpow] using hν 1 zero_lt_one le_rfl
  have hsmall :
      (∫⁻ t in Ioc (0 : ℝ) 1, μ {r : ℝ | t < r ^ (-q)}) ≤ ENNReal.ofReal A := by
    calc
      (∫⁻ t in Ioc (0 : ℝ) 1, μ {r : ℝ | t < r ^ (-q)}) ≤
          ∫⁻ _t in Ioc (0 : ℝ) 1, ENNReal.ofReal A := by
        refine setLIntegral_mono' measurableSet_Ioc ?_
        intro t ht
        exact (measure_mono (subset_univ _)).trans hmass
      _ = ENNReal.ofReal A := by simp
  have ha : -γ / q < -1 := by
    apply (div_lt_iff₀ hq).2
    linarith
  have hpow_int : IntegrableOn (fun t : ℝ ↦ A * t ^ (-γ / q)) (Ioi 1) :=
    (integrableOn_Ioi_rpow_of_lt ha zero_lt_one).const_mul A
  have htail :
      (∫⁻ t in Ioi (1 : ℝ), μ {r : ℝ | t < r ^ (-q)}) ≤
        ENNReal.ofReal (A * (q / (γ - q))) := by
    calc
      (∫⁻ t in Ioi (1 : ℝ), μ {r : ℝ | t < r ^ (-q)}) ≤
          ∫⁻ t in Ioi (1 : ℝ), ENNReal.ofReal (A * t ^ (-γ / q)) := by
        refine setLIntegral_mono' measurableSet_Ioi ?_
        intro t ht
        exact inversePower_superlevel_measure_le hq ht.le hν
      _ = ENNReal.ofReal (A * (q / (γ - q))) := by
        rw [← ofReal_integral_eq_lintegral_ofReal hpow_int]
        · rw [integral_const_mul, integral_Ioi_rpow_of_lt ha zero_lt_one]
          congr 2
          simp only [Real.one_rpow]
          field_simp [hq.ne', hqγ.ne, hqγ.ne', ne_of_gt (sub_pos.mpr hqγ)]
          rw [show -γ + q = -(γ - q) by ring]
          field_simp [hqγ.ne']
          exact div_self (sub_ne_zero.mpr hqγ.ne')
        · filter_upwards [self_mem_ae_restrict measurableSet_Ioi] with t ht
          exact mul_nonneg hA (Real.rpow_nonneg (zero_le_one.trans ht.le) _)
  calc
    (∫⁻ t in Ioi (0 : ℝ), μ {r : ℝ | t < r ^ (-q)}) ≤
        ∫⁻ t in Ioc (0 : ℝ) 1 ∪ Ioi 1, μ {r : ℝ | t < r ^ (-q)} :=
      lintegral_mono_set Ioi_subset_Ioc_union_Ioi
    _ ≤ (∫⁻ t in Ioc (0 : ℝ) 1, μ {r : ℝ | t < r ^ (-q)}) +
        ∫⁻ t in Ioi (1 : ℝ), μ {r : ℝ | t < r ^ (-q)} := lintegral_union_le _ _ _
    _ ≤ ENNReal.ofReal A + ENNReal.ofReal (A * (q / (γ - q))) := add_le_add hsmall htail
    _ = ENNReal.ofReal (A * (γ / (γ - q))) := by
      rw [← ENNReal.ofReal_add hA (mul_nonneg hA (div_nonneg hq.le (sub_nonneg.mpr hqγ.le)))]
      congr 1
      field_simp [ne_of_gt (sub_pos.mpr hqγ)]
      ring

end AffineCarleson.Internal
