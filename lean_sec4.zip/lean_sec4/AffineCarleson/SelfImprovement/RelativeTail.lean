import AffineCarleson.SelfImprovement.IntegratedCenters
import AffineCarleson.SelfImprovement.OscillationEnergy

/-! Finiteness of the fixed-ball relative oscillation tail. -/

noncomputable section
set_option autoImplicit false
open Set MeasureTheory
open scoped BigOperators ENNReal

namespace AffineCarleson.Internal

/-- The radius-one relative estimate, averaged over centers, controls the full tail. -/
theorem relative_tail_le_energy
    {n m : ℕ} (g : (Fin n → ℝ) → Fin m → ℝ)
    (hgmeas : ∀ i, Measurable (fun y ↦ g y i))
    (hg : ∀ i, MemLp (fun y ↦ g y i) 2
      (volume.restrict (ballSet (0 : Fin n → ℝ) 8)))
    (μ : (Fin n → ℝ) → ℝ) (hμmeas : Measurable μ)
    (hμnonneg : ∀ y, 0 ≤ μ y) (hμint : IntegrableOn μ (ballSet 0 8))
    {K M : ℝ} (hK : 1 ≤ K) (hM : 0 ≤ M)
    (hrel : ∀ c ∈ ballSet (0 : Fin n → ℝ) 3,
      (∫⁻ x in ballSet c 1, ∫⁻ r in Ioo (0 : ℝ) 1,
        ENNReal.ofReal (ballOscillation x r g / r)) ≤
      ENNReal.ofReal
        (K * (volume (ballSet c 4)).toReal * ballOscillation c 4 g +
          M * ∫ y in ballSet c 4, μ y)) :
    (∫⁻ r in Ioo (0 : ℝ) 1, ∫⁻ x in ballSet (0 : Fin n → ℝ) (1 + r),
      ENNReal.ofReal (ballOscillation x r g / r)) ≤
      ENNReal.ofReal ((4 : ℝ) ^ n * K) *
          (∫⁻ y in ballSet (0 : Fin n → ℝ) 8,
            ENNReal.ofReal (∑ i, g y i ^ 2)) +
        ENNReal.ofReal ((4 : ℝ) ^ n * M) *
          (∫⁻ y in ballSet (0 : Fin n → ℝ) 8, ENNReal.ofReal (μ y)) := by
  let F : (Fin n → ℝ) → ℝ → ENNReal := fun x r ↦
    ENNReal.ofReal (ballOscillation x r g / r)
  let E : ENNReal := ∫⁻ y in ballSet (0 : Fin n → ℝ) 8,
    ENNReal.ofReal (∑ i, g y i ^ 2)
  let Q : ENNReal := ∫⁻ y in ballSet (0 : Fin n → ℝ) 8, ENNReal.ofReal (μ y)
  let V1 := volume (ballSet (0 : Fin n → ℝ) 1)
  let V4 := volume (ballSet (0 : Fin n → ℝ) 4)
  have hFmeas : Measurable (Function.uncurry F) := by
    apply Measurable.ennreal_ofReal
    exact (measurable_ballOscillation g hgmeas).div
      measurable_snd
  have hlower : V1 * (∫⁻ r in Ioo (0 : ℝ) 1,
      ∫⁻ x in ballSet (0 : Fin n → ℝ) (1 + r), F x r) ≤
      ∫⁻ c in ballSet (0 : Fin n → ℝ) 3,
        ∫⁻ x in ballSet c 1, ∫⁻ r in Ioo (0 : ℝ) 1, F x r := by
    convert integrated_centers_lower F hFmeas (t := (1 : ℝ)) zero_lt_one using 1
    all_goals norm_num [V1]
  have hrelative : (∫⁻ c in ballSet (0 : Fin n → ℝ) 3,
      ∫⁻ x in ballSet c 1, ∫⁻ r in Ioo (0 : ℝ) 1, F x r) ≤
      ∫⁻ c in ballSet (0 : Fin n → ℝ) 3,
        ENNReal.ofReal
          (K * (volume (ballSet c 4)).toReal * ballOscillation c 4 g +
            M * ∫ y in ballSet c 4, μ y) := by
    exact setLIntegral_mono' (measurableSet_ballSet 0 3) hrel
  have hμlocal : ∀ c ∈ ballSet (0 : Fin n → ℝ) 3,
      IntegrableOn μ (ballSet c 4) := by
    intro c hc
    apply hμint.mono_set
    have hd := (mem_ballSet_iff_euclidean_dist (by norm_num : (0 : ℝ) < 3)).mp hc
    exact ballSet_subset_of_dist_add_le (by norm_num) (by norm_num) (by linarith)
  have hsplit : (∫⁻ c in ballSet (0 : Fin n → ℝ) 3,
      ENNReal.ofReal
        (K * (volume (ballSet c 4)).toReal * ballOscillation c 4 g +
          M * ∫ y in ballSet c 4, μ y)) =
      ENNReal.ofReal (K * V4.toReal) *
          (∫⁻ c in ballSet (0 : Fin n → ℝ) 3,
            ENNReal.ofReal (ballOscillation c 4 g)) +
        ENNReal.ofReal M *
          (∫⁻ c in ballSet (0 : Fin n → ℝ) 3,
            ∫⁻ y in ballSet c 4, ENNReal.ofReal (μ y)) := by
    have hpoint : ∀ c ∈ ballSet (0 : Fin n → ℝ) 3,
        ENNReal.ofReal
          (K * (volume (ballSet c 4)).toReal * ballOscillation c 4 g +
            M * ∫ y in ballSet c 4, μ y) =
        ENNReal.ofReal (K * V4.toReal) * ENNReal.ofReal (ballOscillation c 4 g) +
          ENNReal.ofReal M * (∫⁻ y in ballSet c 4, ENNReal.ofReal (μ y)) := by
      intro c hc
      have hosc : 0 ≤ K * (volume (ballSet c 4)).toReal * ballOscillation c 4 g :=
        mul_nonneg (mul_nonneg (zero_le_one.trans hK) ENNReal.toReal_nonneg)
          (ballOscillation_nonneg c (by norm_num) g)
      have hV : (volume (ballSet c 4)).toReal = V4.toReal := by
        rw [volume_ballSet_center c (by norm_num)]
      have hμi : 0 ≤ M * ∫ y in ballSet c 4, μ y :=
        mul_nonneg hM (integral_nonneg hμnonneg)
      rw [ENNReal.ofReal_add hosc,
        ENNReal.ofReal_mul (mul_nonneg (zero_le_one.trans hK) ENNReal.toReal_nonneg),
        hV, ENNReal.ofReal_mul hM,
        ofReal_integral_eq_lintegral_ofReal (hμlocal c hc)
          (Filter.Eventually.of_forall hμnonneg)]
      exact hμi
    calc
      _ = ∫⁻ c in ballSet (0 : Fin n → ℝ) 3,
          (ENNReal.ofReal (K * V4.toReal) * ENNReal.ofReal (ballOscillation c 4 g) +
            ENNReal.ofReal M * (∫⁻ y in ballSet c 4, ENNReal.ofReal (μ y))) :=
        setLIntegral_congr_fun (measurableSet_ballSet 0 3) hpoint
      _ = (∫⁻ c in ballSet (0 : Fin n → ℝ) 3,
            ENNReal.ofReal (K * V4.toReal) * ENNReal.ofReal (ballOscillation c 4 g)) +
          ∫⁻ c in ballSet (0 : Fin n → ℝ) 3,
            ENNReal.ofReal M * (∫⁻ y in ballSet c 4, ENNReal.ofReal (μ y)) := by
        rw [lintegral_add_left]
        exact (Measurable.const_mul
          ((measurable_ballOscillation g hgmeas).comp
            (measurable_id.prodMk measurable_const)).ennreal_ofReal _)
      _ = _ := by
        rw [lintegral_const_mul' _ _ ENNReal.ofReal_ne_top,
          lintegral_const_mul' _ _ ENNReal.ofReal_ne_top]
  have hosc : (∫⁻ c in ballSet (0 : Fin n → ℝ) 3,
      ENNReal.ofReal (ballOscillation c 4 g)) ≤ E := by
    apply lintegral_ballOscillation_le_energy_on g hgmeas
      (measurableSet_ballSet 0 3) (measurableSet_ballSet 0 8) hg (by norm_num)
    intro c hc
    have hd := (mem_ballSet_iff_euclidean_dist (by norm_num : (0 : ℝ) < 3)).mp hc
    exact ballSet_subset_of_dist_add_le (by norm_num) (by norm_num) (by linarith)
  have hQmeas : Measurable (fun y ↦ ENNReal.ofReal (μ y)) :=
    Measurable.ennreal_ofReal hμmeas
  have herr : (∫⁻ c in ballSet (0 : Fin n → ℝ) 3,
      ∫⁻ y in ballSet c 4, ENNReal.ofReal (μ y)) ≤ V4 * Q := by
    apply lintegral_ballSet_centers_upper _ hQmeas _ _ (measurableSet_ballSet 0 8)
      (by norm_num)
    intro c hc
    have hd := (mem_ballSet_iff_euclidean_dist (by norm_num : (0 : ℝ) < 3)).mp hc
    exact ballSet_subset_of_dist_add_le (by norm_num) (by norm_num) (by linarith)
  have hupper : V1 * (∫⁻ r in Ioo (0 : ℝ) 1,
      ∫⁻ x in ballSet (0 : Fin n → ℝ) (1 + r), F x r) ≤
      ENNReal.ofReal (K * V4.toReal) * E + ENNReal.ofReal M * (V4 * Q) := by
    calc
      _ ≤ ∫⁻ c in ballSet (0 : Fin n → ℝ) 3,
          ENNReal.ofReal
            (K * (volume (ballSet c 4)).toReal * ballOscillation c 4 g +
              M * ∫ y in ballSet c 4, μ y) := hlower.trans hrelative
      _ = _ := hsplit
      _ ≤ _ := add_le_add (mul_le_mul_right hosc _) (mul_le_mul_right herr _)
  have hVscale : V4 = ENNReal.ofReal ((4 : ℝ) ^ n) * V1 := by
    simpa [V1, V4] using volume_ballSet_mul (0 : Fin n → ℝ)
      (a := (4 : ℝ)) (r := (1 : ℝ)) (by norm_num) (by norm_num)
  have hV1zero : V1 ≠ 0 := (volume_ballSet_pos 0 zero_lt_one).ne'
  have hV1top : V1 ≠ ⊤ := volume_ballSet_ne_top 0 zero_lt_one
  have hKreal : ENNReal.ofReal (K * V4.toReal) = ENNReal.ofReal K * V4 := by
    rw [ENNReal.ofReal_mul (zero_le_one.trans hK),
      ENNReal.ofReal_toReal (volume_ballSet_ne_top 0 (by norm_num))]
  rw [hKreal, hVscale] at hupper
  let T := ∫⁻ r in Ioo (0 : ℝ) 1, ∫⁻ x in ballSet (0 : Fin n → ℝ) (1 + r), F x r
  let R := ENNReal.ofReal ((4 : ℝ) ^ n * K) * E +
    ENNReal.ofReal ((4 : ℝ) ^ n * M) * Q
  have hscaled : V1 * T ≤ V1 * R := by
    dsimp only [T, R]
    rw [ENNReal.ofReal_mul (by positivity : 0 ≤ (4 : ℝ) ^ n),
      ENNReal.ofReal_mul (by positivity : 0 ≤ (4 : ℝ) ^ n)]
    convert hupper using 1
    all_goals ring
  calc
    (∫⁻ r in Ioo (0 : ℝ) 1, ∫⁻ x in ballSet (0 : Fin n → ℝ) (1 + r),
      ENNReal.ofReal (ballOscillation x r g / r)) = V1⁻¹ * (V1 * T) := by
        rw [← mul_assoc, ENNReal.inv_mul_cancel hV1zero hV1top, one_mul]
    _ ≤ V1⁻¹ * (V1 * R) := mul_le_mul_right hscaled _
    _ = ENNReal.ofReal ((4 : ℝ) ^ n * K) * E +
        ENNReal.ofReal ((4 : ℝ) ^ n * M) * Q := by
      rw [← mul_assoc, ENNReal.inv_mul_cancel hV1zero hV1top, one_mul]

/-- In particular, the radius-one relative tail is finite. -/
theorem relative_tail_lt_top
    {n m : ℕ} (g : (Fin n → ℝ) → Fin m → ℝ)
    (hgmeas : ∀ i, Measurable (fun y ↦ g y i))
    (hg : ∀ i, MemLp (fun y ↦ g y i) 2
      (volume.restrict (ballSet (0 : Fin n → ℝ) 8)))
    (μ : (Fin n → ℝ) → ℝ) (hμmeas : Measurable μ)
    (hμnonneg : ∀ y, 0 ≤ μ y) (hμint : IntegrableOn μ (ballSet 0 8))
    {K M : ℝ} (hK : 1 ≤ K) (hM : 0 ≤ M)
    (hrel : ∀ c ∈ ballSet (0 : Fin n → ℝ) 3,
      (∫⁻ x in ballSet c 1, ∫⁻ r in Ioo (0 : ℝ) 1,
        ENNReal.ofReal (ballOscillation x r g / r)) ≤
      ENNReal.ofReal
        (K * (volume (ballSet c 4)).toReal * ballOscillation c 4 g +
          M * ∫ y in ballSet c 4, μ y)) :
    (∫⁻ r in Ioo (0 : ℝ) 1, ∫⁻ x in ballSet (0 : Fin n → ℝ) (1 + r),
      ENNReal.ofReal (ballOscillation x r g / r)) < ⊤ := by
  refine (relative_tail_le_energy g hgmeas hg μ hμmeas hμnonneg hμint hK hM hrel).trans_lt ?_
  apply ENNReal.add_lt_top.2
  constructor
  · apply ENNReal.mul_lt_top ENNReal.ofReal_lt_top
    have hsum_int : Integrable (fun y ↦ ∑ i, g y i ^ 2)
        (volume.restrict (ballSet (0 : Fin n → ℝ) 8)) :=
      integrable_finsetSum Finset.univ fun i _ ↦ (hg i).integrable_sq
    have hnonneg : 0 ≤ᵐ[volume.restrict (ballSet (0 : Fin n → ℝ) 8)]
        fun y ↦ ∑ i, g y i ^ 2 :=
      Filter.Eventually.of_forall fun y ↦ Finset.sum_nonneg fun i _ ↦ sq_nonneg _
    rw [← ofReal_integral_eq_lintegral_ofReal hsum_int hnonneg]
    exact ENNReal.ofReal_lt_top
  · apply ENNReal.mul_lt_top ENNReal.ofReal_lt_top
    rw [← ofReal_integral_eq_lintegral_ofReal hμint
      (Filter.Eventually.of_forall hμnonneg)]
    exact ENNReal.ofReal_lt_top

end AffineCarleson.Internal
