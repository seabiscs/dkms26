import Mathlib.MeasureTheory.Measure.WithDensity
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Pow.Continuity

/-!
# The tail measure associated with an oscillation density

This file realizes the differential `dΦ(r) = E(r) dr / r` directly as a measure.
The identities are valid for extended nonnegative integrals and therefore require no
weighted-integrability assumption.
-/

noncomputable section

open Set MeasureTheory

namespace AffineCarleson.Internal

/-- The measure whose density with respect to Lebesgue measure is the nonnegative
representative of `E(r) / r`. -/
def tailMeasure (E : ℝ → ℝ) : Measure ℝ :=
  volume.withDensity fun r ↦ ENNReal.ofReal (E r / r)

/-- The cumulative mass of `tailMeasure E` is the source tail integral. The difference
between `Ioc` and `Ioo` is the Lebesgue-null right endpoint. -/
theorem tailMeasure_Ioc_eq_lintegral_Ioo (E : ℝ → ℝ) (t : ℝ) :
    tailMeasure E (Ioc 0 t) =
      ∫⁻ r in Ioo (0 : ℝ) t, ENNReal.ofReal (E r / r) := by
  rw [tailMeasure, withDensity_apply _ measurableSet_Ioc]
  exact setLIntegral_congr Ioo_ae_eq_Ioc.symm

/-- Cumulative masses of the tail measure are monotone in the endpoint. -/
theorem tailMeasure_Ioc_mono (E : ℝ → ℝ) {r t : ℝ} (hrt : r ≤ t) :
    tailMeasure E (Ioc 0 r) ≤ tailMeasure E (Ioc 0 t) :=
  measure_mono (Ioc_subset_Ioc_right hrt)

/-- A finite cumulative mass can be recovered from its real value. -/
theorem ofReal_tailMeasure_Ioc_toReal (E : ℝ → ℝ) {t : ℝ}
    (hfinite : tailMeasure E (Ioc 0 t) ≠ ⊤) :
    ENNReal.ofReal (tailMeasure E (Ioc 0 t)).toReal = tailMeasure E (Ioc 0 t) := by
  rw [ENNReal.ofReal_toReal hfinite]

/-- Integration against the tail measure is multiplication by its density. This is the
exact weighted-moment identity used with the weight `r ^ (-q)` on `(0,1]`. -/
theorem lintegral_inversePower_tailMeasure (E : ℝ → ℝ) (q : ℝ)
    (hE_meas : Measurable E)
    (hE_nonneg : ∀ r ∈ Ioo (0 : ℝ) 1, 0 ≤ E r) :
    (∫⁻ r in Ioc (0 : ℝ) 1, ENNReal.ofReal (r ^ (-q)) ∂tailMeasure E) =
      ∫⁻ r in Ioo (0 : ℝ) 1, ENNReal.ofReal (r ^ (-q) * E r / r) := by
  have hdensity_meas : Measurable (fun r : ℝ ↦ ENNReal.ofReal (E r / r)) :=
    (hE_meas.div measurable_id).ennreal_ofReal
  have hweight_meas : Measurable (fun r : ℝ ↦ ENNReal.ofReal (r ^ (-q))) := by
    apply Measurable.ennreal_ofReal
    apply measurable_of_continuousOn_compl_singleton 0
    exact continuousOn_id.rpow_const (fun r hr ↦ Or.inl hr)
  rw [tailMeasure,
    setLIntegral_withDensity_eq_setLIntegral_mul volume hdensity_meas hweight_meas
      measurableSet_Ioc]
  calc
    (∫⁻ r in Ioc (0 : ℝ) 1,
        ((fun z ↦ ENNReal.ofReal (E z / z)) *
          (fun z ↦ ENNReal.ofReal (z ^ (-q)))) r) =
        ∫⁻ r in Ioo (0 : ℝ) 1,
          ((fun z ↦ ENNReal.ofReal (E z / z)) *
            (fun z ↦ ENNReal.ofReal (z ^ (-q)))) r :=
      setLIntegral_congr Ioo_ae_eq_Ioc.symm
    _ = ∫⁻ r in Ioo (0 : ℝ) 1, ENNReal.ofReal (r ^ (-q) * E r / r) := by
      apply setLIntegral_congr_fun measurableSet_Ioo
      intro r hr
      have hEr : 0 ≤ E r / r := div_nonneg (hE_nonneg r hr) hr.1.le
      rw [Pi.mul_apply, ← ENNReal.ofReal_mul hEr]
      congr 1
      ring

end AffineCarleson.Internal
