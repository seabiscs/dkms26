import AffineCarleson.SelfImprovement.OscillationCongruence
import AffineCarleson.SelfImprovement.Geometry

/-!
# Congruence for the relative Carleson inequality

The relative inequality only depends on the almost-everywhere classes of its
data on the containing ball.  These lemmas make that invariance explicit.
-/

open scoped ENNReal

namespace AffineCarleson.Internal

open MeasureTheory Set

theorem relative_lhs_congr_ae
    {n m : ℕ} {U : Set (Fin n → ℝ)}
    (g h : (Fin n → ℝ) → Fin m → ℝ)
    (hgh : ∀ i, (fun x ↦ g x i) =ᵐ[volume.restrict U] fun x ↦ h x i)
    {t : ℝ} (ht : 0 < t) (c : Fin n → ℝ)
    (hsub : ballSet c (4 * t) ⊆ U) :
    (∫⁻ x in ballSet c t, ∫⁻ r in Ioo (0 : ℝ) t,
        ENNReal.ofReal (ballOscillation x r g / r)) =
      ∫⁻ x in ballSet c t, ∫⁻ r in Ioo (0 : ℝ) t,
        ENNReal.ofReal (ballOscillation x r h / r) := by
  apply setLIntegral_congr_fun (measurableSet_ballSet c t)
  intro x hx
  apply setLIntegral_congr_fun measurableSet_Ioo
  intro r hr
  have hxc :
      dist (WithLp.toLp 2 x : EuclideanSpace ℝ (Fin n)) (WithLp.toLp 2 c) < t :=
    (mem_ballSet_iff_euclidean_dist ht).mp hx
  have hball : ballSet x r ⊆ ballSet c (4 * t) := by
    apply ballSet_subset_of_dist_add_le hr.1 (by positivity)
    linarith [hr.2, hxc]
  change ENNReal.ofReal (ballOscillation x r g / r) =
    ENNReal.ofReal (ballOscillation x r h / r)
  rw [ballOscillation_congr_ae g h hgh x r (hball.trans hsub)]

theorem relative_rhs_congr_ae
    {n m : ℕ} {U : Set (Fin n → ℝ)}
    (g h : (Fin n → ℝ) → Fin m → ℝ)
    (hgh : ∀ i, (fun x ↦ g x i) =ᵐ[volume.restrict U] fun x ↦ h x i)
    (μ ν : (Fin n → ℝ) → ℝ)
    (hμν : μ =ᵐ[volume.restrict U] ν)
    {t : ℝ} (c : Fin n → ℝ)
    (hsub : ballSet c (4 * t) ⊆ U) (K M σ : ℝ) :
    K * (volume (ballSet c (4 * t))).toReal * ballOscillation c (4 * t) g +
        M * t ^ σ * ∫ x in ballSet c (4 * t), μ x =
      K * (volume (ballSet c (4 * t))).toReal * ballOscillation c (4 * t) h +
        M * t ^ σ * ∫ x in ballSet c (4 * t), ν x := by
  have hμν_ball : μ =ᵐ[volume.restrict (ballSet c (4 * t))] ν :=
    ae_mono (Measure.restrict_mono hsub le_rfl) hμν
  rw [ballOscillation_congr_ae g h hgh c (4 * t) hsub,
    integral_congr_ae hμν_ball]

theorem relative_inequality_congr_ae
    {n m : ℕ} {U : Set (Fin n → ℝ)}
    (g h : (Fin n → ℝ) → Fin m → ℝ)
    (hgh : ∀ i, (fun x ↦ g x i) =ᵐ[volume.restrict U] fun x ↦ h x i)
    (μ ν : (Fin n → ℝ) → ℝ)
    (hμν : μ =ᵐ[volume.restrict U] ν)
    {t : ℝ} (ht : 0 < t) (c : Fin n → ℝ)
    (hsub : ballSet c (4 * t) ⊆ U) (K M σ : ℝ)
    (hrel :
      (∫⁻ x in ballSet c t, ∫⁻ r in Ioo (0 : ℝ) t,
          ENNReal.ofReal (ballOscillation x r g / r)) ≤
        ENNReal.ofReal
          (K * (volume (ballSet c (4 * t))).toReal * ballOscillation c (4 * t) g +
            M * t ^ σ * ∫ x in ballSet c (4 * t), μ x)) :
    (∫⁻ x in ballSet c t, ∫⁻ r in Ioo (0 : ℝ) t,
        ENNReal.ofReal (ballOscillation x r h / r)) ≤
      ENNReal.ofReal
        (K * (volume (ballSet c (4 * t))).toReal * ballOscillation c (4 * t) h +
          M * t ^ σ * ∫ x in ballSet c (4 * t), ν x) := by
  rw [← relative_lhs_congr_ae g h hgh ht c hsub,
    ← relative_rhs_congr_ae g h hgh μ ν hμν c hsub K M σ]
  exact hrel

end AffineCarleson.Internal
