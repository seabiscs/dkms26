import AffineCarleson.SelfImprovement.KernelLayerCake
import AffineCarleson.SelfImprovement.Geometry
import Mathlib.MeasureTheory.Measure.Prod
import Mathlib.MeasureTheory.Integral.Lebesgue.Add

/-!
# Tonelli integration of the inverse-power layer-cake bound

This file lifts the pointwise inverse-power estimate to pairs in a measurable set.  All
integrals are extended nonnegative integrals, so no finiteness hypothesis is needed.
-/

noncomputable section
set_option autoImplicit false

open Set MeasureTheory

namespace AffineCarleson.Internal

/-- Integrating the pointwise inverse-power layer-cake estimate over a measurable pair set. -/
theorem lintegral_inversePower_kernel_le_layerCake {n : ℕ}
    (Q : (Fin n → ℝ) → (Fin n → ℝ) → ℝ)
    (hQ : Measurable (Function.uncurry Q))
    (hQ_nonneg : ∀ u v, 0 ≤ Q u v) (hQ_diag : ∀ u, Q u u = 0)
    (A : Set (Fin n → ℝ)) (hA : MeasurableSet A) {a : ℝ} (ha : 0 < a) :
    (∫⁻ u in A, ∫⁻ v in A,
      ENNReal.ofReal (Q u v /
        dist (WithLp.toLp 2 u : EuclideanSpace ℝ (Fin n)) (WithLp.toLp 2 v) ^ a)) ≤
      (∫⁻ u in A, ∫⁻ v in A, ENNReal.ofReal (Q u v)) + ENNReal.ofReal a *
        (∫⁻ r in Ioo (0 : ℝ) 1, ENNReal.ofReal (r ^ (-a - 1)) *
          (∫⁻ u in A, ∫⁻ v in A,
            if dist (WithLp.toLp 2 u : EuclideanSpace ℝ (Fin n))
                (WithLp.toLp 2 v) < r then ENNReal.ofReal (Q u v) else 0)) := by
  classical
  let d : (Fin n → ℝ) → (Fin n → ℝ) → ℝ := fun u v ↦
    dist (WithLp.toLp 2 u : EuclideanSpace ℝ (Fin n)) (WithLp.toLp 2 v)
  have hd_meas : Measurable (Function.uncurry d) := by
    dsimp only [d, Function.uncurry]
    exact Measurable.dist
      ((MeasurableEquiv.toLp 2 (Fin n → ℝ)).measurable.comp measurable_fst)
      ((MeasurableEquiv.toLp 2 (Fin n → ℝ)).measurable.comp measurable_snd)
  have hQe : Measurable (fun p : (Fin n → ℝ) × (Fin n → ℝ) ↦ ENNReal.ofReal (Q p.1 p.2)) :=
    hQ.ennreal_ofReal
  have hpoint (u v : Fin n → ℝ) :
      ENNReal.ofReal (Q u v / d u v ^ a) ≤ ENNReal.ofReal (Q u v) + ENNReal.ofReal a *
        (∫⁻ r in Ioo (0 : ℝ) 1,
          if d u v < r then ENNReal.ofReal (Q u v * r ^ (-a - 1)) else 0) := by
    apply inversePower_kernel_le_layerCake ha (dist_nonneg) (hQ_nonneg u v)
    intro hdist
    have huvLp : (WithLp.toLp 2 u : EuclideanSpace ℝ (Fin n)) = WithLp.toLp 2 v :=
      dist_eq_zero.mp hdist
    exact hQ_diag _ ▸ congr_arg (fun w ↦ Q w v) (WithLp.toLp_injective 2 huvLp)
  have hpair :
      (∫⁻ u in A, ∫⁻ v in A, ENNReal.ofReal (Q u v / d u v ^ a)) ≤
        ∫⁻ u in A, ∫⁻ v in A, ENNReal.ofReal (Q u v) + ENNReal.ofReal a *
          (∫⁻ r in Ioo (0 : ℝ) 1,
            if d u v < r then ENNReal.ofReal (Q u v * r ^ (-a - 1)) else 0) := by
    refine setLIntegral_mono' hA fun u _ ↦ ?_
    exact setLIntegral_mono' hA fun v _ ↦ hpoint u v
  calc
    (∫⁻ u in A, ∫⁻ v in A,
      ENNReal.ofReal (Q u v /
        dist (WithLp.toLp 2 u : EuclideanSpace ℝ (Fin n)) (WithLp.toLp 2 v) ^ a)) =
        ∫⁻ u in A, ∫⁻ v in A, ENNReal.ofReal (Q u v / d u v ^ a) := rfl
    _ ≤ ∫⁻ u in A, ∫⁻ v in A, ENNReal.ofReal (Q u v) + ENNReal.ofReal a *
          (∫⁻ r in Ioo (0 : ℝ) 1,
            if d u v < r then ENNReal.ofReal (Q u v * r ^ (-a - 1)) else 0) := hpair
    _ = (∫⁻ u in A, ∫⁻ v in A, ENNReal.ofReal (Q u v)) + ENNReal.ofReal a *
        (∫⁻ r in Ioo (0 : ℝ) 1, ENNReal.ofReal (r ^ (-a - 1)) *
          (∫⁻ u in A, ∫⁻ v in A,
            if d u v < r then ENNReal.ofReal (Q u v) else 0)) := by
      let μA : Measure (Fin n → ℝ) := volume.restrict A
      let μI : Measure ℝ := volume.restrict (Ioo (0 : ℝ) 1)
      let F : ((Fin n → ℝ) × (Fin n → ℝ)) → ℝ → ENNReal := fun p r ↦
        ENNReal.ofReal (r ^ (-a - 1)) *
          if d p.1 p.2 < r then ENNReal.ofReal (Q p.1 p.2) else 0
      have hw : Measurable (fun r : ℝ ↦ ENNReal.ofReal (r ^ (-a - 1))) := by
        fun_prop
      have hF : Measurable (Function.uncurry F) := by
        dsimp only [F, Function.uncurry]
        exact (hw.comp measurable_snd).mul <|
          Measurable.ite
            (measurableSet_lt
              (hd_meas.comp ((measurable_fst.comp measurable_fst).prodMk
                (measurable_snd.comp measurable_fst))) measurable_snd)
            (hQe.comp measurable_fst) measurable_const
      have hfactor (u v : Fin n → ℝ) (r : ℝ) :
          (if d u v < r then ENNReal.ofReal (Q u v * r ^ (-a - 1)) else 0) =
            F (u, v) r := by
        by_cases h : d u v < r
        · simp only [h, ↓reduceIte, F]
          rw [ENNReal.ofReal_mul (hQ_nonneg u v)]
          exact mul_comm _ _
        · simp only [h, ↓reduceIte, F, mul_zero]
      have hlayer_meas : Measurable (fun p : (Fin n → ℝ) × (Fin n → ℝ) ↦
          ∫⁻ r, F p r ∂μI) := hF.lintegral_prod_right'
      have hq_row_meas : Measurable (fun u : Fin n → ℝ ↦
          ∫⁻ v, ENNReal.ofReal (Q u v) ∂μA) := hQe.lintegral_prod_right'
      have hlayer_row_meas : Measurable (fun u : Fin n → ℝ ↦
          ∫⁻ v, (∫⁻ r, F (u, v) r ∂μI) ∂μA) :=
        hlayer_meas.lintegral_prod_right'
      have hsplit :
          (∫⁻ u, (∫⁻ v, ENNReal.ofReal (Q u v) + ENNReal.ofReal a *
              (∫⁻ r, (if d u v < r then ENNReal.ofReal (Q u v * r ^ (-a - 1)) else 0) ∂μI)
                ∂μA) ∂μA) =
            (∫⁻ u, (∫⁻ v, ENNReal.ofReal (Q u v) ∂μA) ∂μA) + ENNReal.ofReal a *
              (∫⁻ u, (∫⁻ v, (∫⁻ r, F (u, v) r ∂μI) ∂μA) ∂μA) := by
        have hpoint_integral (u v : Fin n → ℝ) :
            (∫⁻ r, (if d u v < r then ENNReal.ofReal (Q u v * r ^ (-a - 1)) else 0) ∂μI) =
              ∫⁻ r, F (u, v) r ∂μI :=
          lintegral_congr (hfactor u v)
        calc
          _ = ∫⁻ u, ((∫⁻ v, ENNReal.ofReal (Q u v) ∂μA) +
                ENNReal.ofReal a * (∫⁻ v, (∫⁻ r, F (u, v) r ∂μI) ∂μA)) ∂μA := by
              apply lintegral_congr
              intro u
              simp_rw [hpoint_integral u]
              have hQ_u : Measurable (fun v ↦ ENNReal.ofReal (Q u v)) :=
                hQe.comp (measurable_const.prodMk measurable_id)
              rw [lintegral_add_left hQ_u,
                lintegral_const_mul' _ _ ENNReal.ofReal_ne_top]
          _ = _ := by
            rw [lintegral_add_left hq_row_meas,
              lintegral_const_mul' _ _ ENNReal.ofReal_ne_top]
      change
        (∫⁻ u, (∫⁻ v, ENNReal.ofReal (Q u v) + ENNReal.ofReal a *
          (∫⁻ r, (if d u v < r then ENNReal.ofReal (Q u v * r ^ (-a - 1)) else 0) ∂μI)
            ∂μA) ∂μA) =
          (∫⁻ u, (∫⁻ v, ENNReal.ofReal (Q u v) ∂μA) ∂μA) + ENNReal.ofReal a *
            (∫⁻ r, ENNReal.ofReal (r ^ (-a - 1)) *
              (∫⁻ u, (∫⁻ v, (if d u v < r then ENNReal.ofReal (Q u v) else 0) ∂μA) ∂μA)
                ∂μI)
      rw [hsplit]
      congr 1
      have hswap :
          (∫⁻ u, (∫⁻ v, (∫⁻ r, F (u, v) r ∂μI) ∂μA) ∂μA) =
            ∫⁻ r, (∫⁻ u, (∫⁻ v, F (u, v) r ∂μA) ∂μA) ∂μI := by
        calc
          _ = ∫⁻ p, (∫⁻ r, F p r ∂μI) ∂μA.prod μA :=
            lintegral_lintegral hlayer_meas.aemeasurable
          _ = ∫⁻ r, (∫⁻ p, F p r ∂μA.prod μA) ∂μI :=
            lintegral_lintegral_swap hF.aemeasurable
          _ = _ := by
            apply lintegral_congr
            intro r
            have hFr : Measurable (Function.uncurry
                (fun u v : Fin n → ℝ ↦ F (u, v) r)) := by
              exact hF.comp (by fun_prop : Measurable (fun p :
                (Fin n → ℝ) × (Fin n → ℝ) ↦ (p, r)))
            exact (lintegral_lintegral hFr.aemeasurable).symm
      rw [hswap]
      apply congrArg (fun x ↦ ENNReal.ofReal a * x)
      apply lintegral_congr
      intro r
      calc
        (∫⁻ u, (∫⁻ v, F (u, v) r ∂μA) ∂μA) =
            ∫⁻ u, ENNReal.ofReal (r ^ (-a - 1)) *
              (∫⁻ v, (if d u v < r then ENNReal.ofReal (Q u v) else 0) ∂μA) ∂μA := by
          apply lintegral_congr
          intro u
          change (∫⁻ v, ENNReal.ofReal (r ^ (-a - 1)) *
              (if d u v < r then ENNReal.ofReal (Q u v) else 0) ∂μA) = _
          rw [lintegral_const_mul' _ _ ENNReal.ofReal_ne_top]
        _ = _ := lintegral_const_mul' _ _ ENNReal.ofReal_ne_top

end AffineCarleson.Internal
