import AffineCarleson.SelfImprovement.BallVariance

/-! Congruence of oscillation quantities under local almost-everywhere equality. -/

noncomputable section
open MeasureTheory Set
open scoped BigOperators ENNReal

namespace AffineCarleson.Internal

/-- Ball oscillation depends only on the a.e. equivalence class on any
containing set. -/
theorem ballOscillation_congr_ae
    {n m : ℕ} {U : Set (Fin n → ℝ)}
    (g h : (Fin n → ℝ) → Fin m → ℝ)
    (hgh : ∀ i, (fun y ↦ g y i) =ᵐ[volume.restrict U] fun y ↦ h y i)
    (x : Fin n → ℝ) (r : ℝ) (hsub : ballSet x r ⊆ U) :
    ballOscillation x r g = ballOscillation x r h := by
  have hball : ∀ i, (fun y ↦ g y i) =ᵐ[volume.restrict (ballSet x r)] fun y ↦ h y i :=
    fun i ↦ ae_mono (Measure.restrict_mono hsub le_rfl) (hgh i)
  have hmean : ∀ i,
      (volume (ballSet x r)).toReal⁻¹ * (∫ y in ballSet x r, g y i) =
        (volume (ballSet x r)).toReal⁻¹ * (∫ y in ballSet x r, h y i) := by
    intro i
    rw [integral_congr_ae (hball i)]
  unfold ballOscillation
  congr 1
  apply integral_congr_ae
  filter_upwards [ae_all_iff.2 hball] with y hy
  apply Finset.sum_congr rfl
  intro i hi
  rw [hy i, hmean i]

/-- The nested ENNReal Gagliardo integral on a subset depends only on the a.e.
equivalence class on a containing set. No integrability is required. -/
theorem lintegral_gagliardo_congr_ae
    {n m : ℕ} {U A : Set (Fin n → ℝ)} {s : ℝ}
    (g h : (Fin n → ℝ) → Fin m → ℝ)
    (hgh : ∀ i, (fun y ↦ g y i) =ᵐ[volume.restrict U] fun y ↦ h y i)
    (hAU : A ⊆ U) :
    (∫⁻ u in A, ∫⁻ v in A,
      ENNReal.ofReal ((∑ i, (g u i - g v i) ^ 2) /
        (Real.sqrt (∑ j, (u j - v j) ^ 2)) ^ ((n : ℝ) + 2 * s))) =
      ∫⁻ u in A, ∫⁻ v in A,
        ENNReal.ofReal ((∑ i, (h u i - h v i) ^ 2) /
          (Real.sqrt (∑ j, (u j - v j) ^ 2)) ^ ((n : ℝ) + 2 * s)) := by
  have hA : ∀ i, (fun y ↦ g y i) =ᵐ[volume.restrict A] fun y ↦ h y i :=
    fun i ↦ ae_mono (Measure.restrict_mono hAU le_rfl) (hgh i)
  have hAall : ∀ᵐ y ∂volume.restrict A, ∀ i, g y i = h y i := ae_all_iff.2 hA
  apply lintegral_congr_ae
  filter_upwards [hAall] with u hu
  apply lintegral_congr_ae
  filter_upwards [hAall] with v hv
  congr 2
  apply Finset.sum_congr rfl
  intro i hi
  rw [hu i, hv i]

end AffineCarleson.Internal
