import AffineCarleson.SelfImprovement.BallVariance
import Mathlib.MeasureTheory.Integral.Prod

/-!
# Joint measurability of ball oscillation

Measurability of the literal variable-center, variable-radius ball averages
and oscillation used by the self-improvement argument.
-/

noncomputable section
open MeasureTheory Set
open scoped BigOperators

namespace AffineCarleson.Internal

/-- Membership in a ball is jointly measurable in center, radius, and point. -/
theorem measurableSet_mem_ballSet_parameter {n : ℕ} :
    MeasurableSet
      {q : ((Fin n → ℝ) × ℝ) × (Fin n → ℝ) | q.2 ∈ ballSet q.1.1 q.1.2} := by
  change MeasurableSet {q : ((Fin n → ℝ) × ℝ) × (Fin n → ℝ) |
    (∑ i, (q.2 i - q.1.1 i) ^ 2) < q.1.2 ^ 2}
  exact measurableSet_lt
    (by fun_prop : Measurable (fun q : ((Fin n → ℝ) × ℝ) × (Fin n → ℝ) ↦
      ∑ i, (q.2 i - q.1.1 i) ^ 2))
    (by fun_prop : Measurable (fun q : ((Fin n → ℝ) × ℝ) × (Fin n → ℝ) ↦ q.1.2 ^ 2))

/-- The real volume of a ball is jointly measurable in its center and radius. -/
theorem measurable_ballSet_volumeReal {n : ℕ} :
    Measurable (fun p : (Fin n → ℝ) × ℝ ↦ (volume (ballSet p.1 p.2)).toReal) := by
  classical
  have hjoint : StronglyMeasurable
      (fun q : ((Fin n → ℝ) × ℝ) × (Fin n → ℝ) ↦
        if q.2 ∈ ballSet q.1.1 q.1.2 then (1 : ℝ) else 0) :=
    (Measurable.ite measurableSet_mem_ballSet_parameter measurable_const measurable_const).stronglyMeasurable
  have hint := hjoint.integral_prod_right' (ν := volume)
  convert hint.measurable using 1
  funext p
  rw [show (fun y : Fin n → ℝ ↦ if y ∈ ballSet p.1 p.2 then (1 : ℝ) else 0) =
      (ballSet p.1 p.2).indicator (fun _ ↦ (1 : ℝ)) by
        funext y
        rfl]
  rw [integral_indicator (measurableSet_ballSet p.1 p.2), integral_const]
  simp only [smul_eq_mul, mul_one, Measure.real]
  rw [Measure.restrict_apply_univ]

/-- A coordinate integral over a ball is jointly measurable in center and
radius when the coordinate function has a globally measurable representative. -/
theorem measurable_ballSet_coordinateIntegral
    {n m : ℕ} (g : (Fin n → ℝ) → Fin m → ℝ)
    (hg : ∀ i, Measurable (fun y ↦ g y i)) (i : Fin m) :
    Measurable (fun p : (Fin n → ℝ) × ℝ ↦ ∫ y in ballSet p.1 p.2, g y i) := by
  classical
  have hjoint : StronglyMeasurable
      (fun q : ((Fin n → ℝ) × ℝ) × (Fin n → ℝ) ↦
        if q.2 ∈ ballSet q.1.1 q.1.2 then g q.2 i else 0) :=
    (Measurable.ite measurableSet_mem_ballSet_parameter
      ((hg i).comp measurable_snd) measurable_const).stronglyMeasurable
  have hint := hjoint.integral_prod_right' (ν := volume)
  convert hint.measurable using 1
  funext p
  rw [show (fun y : Fin n → ℝ ↦ if y ∈ ballSet p.1 p.2 then g y i else 0) =
      (ballSet p.1 p.2).indicator (fun y ↦ g y i) by
        funext y
        rfl]
  exact (integral_indicator (μ := volume) (f := fun y ↦ g y i)
    (measurableSet_ballSet p.1 p.2)).symm

/-- The literal normalized ball oscillation is jointly measurable in center
and radius for a globally coordinatewise measurable representative. -/
theorem measurable_ballOscillation
    {n m : ℕ} (g : (Fin n → ℝ) → Fin m → ℝ)
    (hg : ∀ i, Measurable (fun y ↦ g y i)) :
    Measurable (fun p : (Fin n → ℝ) × ℝ ↦ ballOscillation p.1 p.2 g) := by
  classical
  have hmass : Measurable
      (fun p : (Fin n → ℝ) × ℝ ↦ (volume (ballSet p.1 p.2)).toReal) :=
    measurable_ballSet_volumeReal
  have hmean : ∀ i, Measurable
      (fun p : (Fin n → ℝ) × ℝ ↦
        (volume (ballSet p.1 p.2)).toReal⁻¹ *
          ∫ y in ballSet p.1 p.2, g y i) := by
    intro i
    exact hmass.inv.mul (measurable_ballSet_coordinateIntegral g hg i)
  have hjoint : StronglyMeasurable
      (fun q : ((Fin n → ℝ) × ℝ) × (Fin n → ℝ) ↦
        if q.2 ∈ ballSet q.1.1 q.1.2 then
          ∑ i, (g q.2 i -
            (volume (ballSet q.1.1 q.1.2)).toReal⁻¹ *
              ∫ y in ballSet q.1.1 q.1.2, g y i) ^ 2
        else 0) := by
    apply Measurable.stronglyMeasurable
    apply Measurable.ite measurableSet_mem_ballSet_parameter
    · apply Finset.measurable_sum
      intro i hi
      exact (((hg i).comp measurable_snd).sub ((hmean i).comp measurable_fst)).pow_const 2
    · exact measurable_const
  have hinter : Measurable
      (fun p : (Fin n → ℝ) × ℝ ↦
        ∫ y in ballSet p.1 p.2, ∑ i,
          (g y i - (volume (ballSet p.1 p.2)).toReal⁻¹ *
            ∫ z in ballSet p.1 p.2, g z i) ^ 2) := by
    have hint := hjoint.integral_prod_right' (ν := volume)
    convert hint.measurable using 1
    funext p
    rw [show (fun y : Fin n → ℝ ↦
        if y ∈ ballSet p.1 p.2 then
          ∑ i, (g y i - (volume (ballSet p.1 p.2)).toReal⁻¹ *
            ∫ z in ballSet p.1 p.2, g z i) ^ 2 else 0) =
        (ballSet p.1 p.2).indicator (fun y ↦
          ∑ i, (g y i - (volume (ballSet p.1 p.2)).toReal⁻¹ *
            ∫ z in ballSet p.1 p.2, g z i) ^ 2) by
          funext y
          rfl]
    exact (integral_indicator (μ := volume)
      (f := fun y ↦ ∑ i, (g y i - (volume (ballSet p.1 p.2)).toReal⁻¹ *
        ∫ z in ballSet p.1 p.2, g z i) ^ 2)
      (measurableSet_ballSet p.1 p.2)).symm
  unfold ballOscillation
  exact hmass.inv.mul hinter

end AffineCarleson.Internal
