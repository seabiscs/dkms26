import AffineCarleson.SelfImprovement.AffineChangeVariables

/-! Ball containment under the affine normalization used in the source proof. -/

noncomputable section
set_option autoImplicit false
open Set

namespace AffineCarleson.Internal

theorem affineScale_surjective {n : ℕ} (x₀ : Fin n → ℝ) {R : ℝ} (hR : 0 < R) :
    Function.Surjective (fun y : Fin n → ℝ ↦ fun i ↦ x₀ i + R * y i) := by
  intro x
  refine ⟨fun i ↦ (x i - x₀ i) / R, ?_⟩
  funext i
  field_simp
  ring

theorem affineScale_image_ballSet {n : ℕ} (x₀ c : Fin n → ℝ) {R r : ℝ} (hR : 0 < R) :
    (fun y : Fin n → ℝ ↦ fun i ↦ x₀ i + R * y i) '' ballSet c r =
      ballSet (fun i ↦ x₀ i + R * c i) (R * r) := by
  rw [← affineScale_preimage_ballSet x₀ c hR]
  exact Set.image_preimage_eq _ (affineScale_surjective x₀ hR)

theorem normalized_relative_ball_subset {n : ℕ} {c : Fin n → ℝ} {t : ℝ}
    (ht : 0 < t) (ht1 : t ≤ 1) (hc : c ∈ ballSet 0 (1 + 2 * t)) :
    ballSet c (4 * t) ⊆ ballSet (0 : Fin n → ℝ) 8 := by
  have hdist := (mem_ballSet_iff_euclidean_dist (by positivity : 0 < 1 + 2 * t)).mp hc
  apply ballSet_subset_of_dist_add_le (by positivity) (by norm_num)
  linarith only [hdist, ht1]

theorem rescaled_relative_ball_subset {n : ℕ} (x₀ : Fin n → ℝ)
    {R t : ℝ} (hR : 0 < R) (ht : 0 < t) (ht1 : t ≤ 1)
    {c : Fin n → ℝ} (hc : c ∈ ballSet 0 (1 + 2 * t)) :
    ballSet (fun i ↦ x₀ i + R * c i) (4 * (R * t)) ⊆ ballSet x₀ (8 * R) := by
  have h := Set.image_mono (f := fun y : Fin n → ℝ ↦ fun i ↦ x₀ i + R * y i)
    (normalized_relative_ball_subset ht ht1 hc)
  rw [affineScale_image_ballSet x₀ c hR, affineScale_image_ballSet x₀ 0 hR] at h
  simpa only [Pi.zero_apply, mul_zero, add_zero, mul_left_comm R 4 t, mul_comm R 8] using h

end AffineCarleson.Internal
