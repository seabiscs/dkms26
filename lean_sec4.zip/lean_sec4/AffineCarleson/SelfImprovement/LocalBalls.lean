import AffineCarleson.SelfImprovement.Geometry

/-! Small source balls with their enlarged closures inside an open domain. -/

noncomputable section
set_option autoImplicit false
open Set Metric

namespace AffineCarleson.Internal

theorem exists_enlarged_ballSet_closure_subset {n : ℕ} {Ω : Set (Fin n → ℝ)}
    (hΩ : IsOpen Ω) {x : Fin n → ℝ} (hx : x ∈ Ω) :
    ∃ r : ℝ, 0 < r ∧ r ≤ 1 ∧ closure (ballSet x (8 * r)) ⊆ Ω := by
  obtain ⟨ε, hε, hball⟩ := Metric.mem_nhds_iff.mp (hΩ.mem_nhds hx)
  let r := min (ε / 16) 1
  have hr : 0 < r := lt_min (by positivity) zero_lt_one
  have hrε : r ≤ ε / 16 := min_le_left _ _
  have h8r : 8 * r < ε := by linarith only [hrε, hε]
  refine ⟨r, hr, min_le_right _ _, ?_⟩
  exact (closure_minimal (ballSet_subset_closedBall x (by positivity : 0 < 8 * r))
    isClosed_closedBall).trans ((closedBall_subset_ball h8r).trans hball)

end AffineCarleson.Internal
