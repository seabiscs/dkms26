import AffineCarleson.SelfImprovement.AffineFractional
import AffineCarleson.SelfImprovement.AffineIntegral

/-! Transport of the normalized fractional estimate to a general ball. -/

noncomputable section
set_option autoImplicit false
open Set MeasureTheory

namespace AffineCarleson.Internal

theorem fractionalEnergy_le_of_scaled_unit_bound {n m : ℕ}
    (g : (Fin n → ℝ) → Fin m → ℝ)
    (hgmeas : ∀ i, Measurable (fun x ↦ g x i))
    (μ : (Fin n → ℝ) → ℝ) (C M σ s : ℝ)
    (x₀ : Fin n → ℝ) {R : ℝ} (hR : 0 < R)
    (hunit :
      (∫⁻ u in ballSet (0 : Fin n → ℝ) 1,
        ∫⁻ v in ballSet (0 : Fin n → ℝ) 1,
          ENNReal.ofReal
            ((∑ i, (g (fun j ↦ x₀ j + R * u j) i -
                g (fun j ↦ x₀ j + R * v j) i) ^ 2) /
              (Real.sqrt (∑ j, (u j - v j) ^ 2)) ^ ((n : ℝ) + 2 * s))) ≤
        ENNReal.ofReal
          (C *
            ((∫ u in ballSet (0 : Fin n → ℝ) 8,
                ∑ i, g (fun j ↦ x₀ j + R * u j) i ^ 2) +
              (M * R ^ σ) *
                ∫ u in ballSet (0 : Fin n → ℝ) 8,
                  μ (fun j ↦ x₀ j + R * u j)))) :
    (∫⁻ x in ballSet x₀ R, ∫⁻ y in ballSet x₀ R,
      ENNReal.ofReal ((∑ i, (g x i - g y i) ^ 2) /
        (Real.sqrt (∑ j, (x j - y j) ^ 2)) ^ ((n : ℝ) + 2 * s))) ≤
      ENNReal.ofReal
        (C * R ^ (-2 * s) *
          ((∫ x in ballSet x₀ (8 * R), ∑ i, g x i ^ 2) +
            M * R ^ σ * ∫ x in ballSet x₀ (8 * R), μ x)) := by
  let P : ENNReal := ENNReal.ofReal (R ^ (2 * s - (n : ℝ)))
  have hPzero : P ≠ 0 := by
    dsimp only [P]
    simp only [ne_eq, ENNReal.ofReal_eq_zero, not_le]
    exact Real.rpow_pos_of_pos hR _
  have hPtop : P ≠ ⊤ := ENNReal.ofReal_ne_top
  have henergy := fractionalEnergy_affineScale g hgmeas x₀ hR s
  have hgint := setIntegral_affineScale
    (fun x : Fin n → ℝ ↦ ∑ i, g x i ^ 2) x₀ 0 hR (r := (8 : ℝ))
  have hμint := setIntegral_affineScale μ x₀ 0 hR (r := (8 : ℝ))
  simp only [Pi.zero_apply, mul_zero, add_zero] at hgint hμint
  rw [henergy, hgint, hμint] at hunit
  simp only [mul_comm R 8] at hunit
  have hreal :
      R ^ (2 * s - (n : ℝ)) *
          (C * R ^ (-2 * s) *
            ((∫ x in ballSet x₀ (8 * R), ∑ i, g x i ^ 2) +
              M * R ^ σ * ∫ x in ballSet x₀ (8 * R), μ x)) =
        C *
          ((R ^ n)⁻¹ * (∫ x in ballSet x₀ (8 * R), ∑ i, g x i ^ 2) +
            (M * R ^ σ) * ((R ^ n)⁻¹ * ∫ x in ballSet x₀ (8 * R), μ x)) := by
    have hp : R ^ (2 * s - (n : ℝ)) * R ^ (-2 * s) = R ^ (-(n : ℝ)) := by
      rw [← Real.rpow_add hR]
      congr 1
      ring
    have hn : (R ^ n)⁻¹ = R ^ (-(n : ℝ)) := by
      rw [← Real.rpow_natCast, Real.rpow_neg hR.le]
    rw [hn, ← hp]
    ring
  have hscaled : P *
      ENNReal.ofReal
        (C * R ^ (-2 * s) *
          ((∫ x in ballSet x₀ (8 * R), ∑ i, g x i ^ 2) +
            M * R ^ σ * ∫ x in ballSet x₀ (8 * R), μ x)) =
      ENNReal.ofReal
        (C *
          ((R ^ n)⁻¹ * (∫ x in ballSet x₀ (8 * R), ∑ i, g x i ^ 2) +
            (M * R ^ σ) * ((R ^ n)⁻¹ * ∫ x in ballSet x₀ (8 * R), μ x))) := by
    dsimp only [P]
    rw [← ENNReal.ofReal_mul (Real.rpow_nonneg hR.le _), hreal]
  apply (ENNReal.mul_le_mul_iff_left hPzero hPtop).mp
  rw [mul_comm _ P, mul_comm _ P, hscaled]
  exact hunit

end AffineCarleson.Internal
