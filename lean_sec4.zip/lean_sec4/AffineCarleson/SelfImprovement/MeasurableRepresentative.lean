import Mathlib.MeasureTheory.Function.LpSeminorm.Basic
import Mathlib.MeasureTheory.Integral.Bochner.Basic

/-! Measurable representatives for transporting local integral statements. -/

noncomputable section
set_option autoImplicit false
open MeasureTheory

namespace AffineCarleson.Internal

theorem exists_measurable_l2_representative {α : Type*} [MeasurableSpace α]
    {μ : Measure α} {m : ℕ} (g : α → Fin m → ℝ)
    (hg : ∀ i, MemLp (fun x ↦ g x i) 2 μ) :
    ∃ h : α → Fin m → ℝ,
      (∀ i, Measurable (fun x ↦ h x i)) ∧
      (∀ i, (fun x ↦ h x i) =ᵐ[μ] (fun x ↦ g x i)) ∧
      (∀ i, MemLp (fun x ↦ h x i) 2 μ) := by
  let h : α → Fin m → ℝ := fun x i ↦
    (hg i).aestronglyMeasurable.mk (fun y ↦ g y i) x
  refine ⟨h, ?_, ?_, ?_⟩
  · intro i
    exact (hg i).aestronglyMeasurable.measurable_mk
  · intro i
    exact (hg i).aestronglyMeasurable.ae_eq_mk.symm
  · intro i
    exact (memLp_congr_ae (hg i).aestronglyMeasurable.ae_eq_mk).mp (hg i)

theorem exists_measurable_nonneg_representative {α : Type*} [MeasurableSpace α]
    {μ : Measure α} (f : α → ℝ) (hf : Integrable f μ) (hf_nonneg : 0 ≤ᵐ[μ] f) :
    ∃ h : α → ℝ, Measurable h ∧ (∀ x, 0 ≤ h x) ∧ h =ᵐ[μ] f ∧ Integrable h μ := by
  let h : α → ℝ := fun x ↦ max (hf.aestronglyMeasurable.mk f x) 0
  have hmeas : Measurable h := hf.aestronglyMeasurable.measurable_mk.max measurable_const
  have heq : h =ᵐ[μ] f := by
    filter_upwards [hf.aestronglyMeasurable.ae_eq_mk, hf_nonneg] with x hx hpos
    dsimp only [h]
    change (0 : ℝ) ≤ f x at hpos
    rw [← hx, max_eq_left hpos]
  exact ⟨h, hmeas, fun x ↦ le_max_right _ _, heq, hf.congr heq.symm⟩

end AffineCarleson.Internal
