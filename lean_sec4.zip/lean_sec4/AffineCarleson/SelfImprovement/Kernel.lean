import Mathlib.Analysis.SpecialFunctions.Integrals.Basic
import Mathlib.MeasureTheory.Integral.Bochner.Set

/-!
# Elementary inverse-power kernel identities

These source-independent real-calculus lemmas support the layer-cake comparison between
near-pair energies and the Gagliardo kernel. They assert no source theorem.
-/

noncomputable section

open Set MeasureTheory

namespace AffineCarleson.Internal

/-- The exact integral representation of an inverse power between `d` and one. -/
theorem inversePower_eq_one_add_integral {a d : ℝ} (ha : 0 < a)
    (hd : 0 < d) (hd_one : d ≤ 1) :
    d ^ (-a) = 1 + a * ∫ r in Ioo d 1, r ^ (-a - 1) := by
  have hzero : (0 : ℝ) ∉ Set.uIcc d 1 := by
    rw [uIcc_of_le hd_one]
    exact fun h ↦ (not_le_of_gt hd h.1)
  have hexp : -a - 1 ≠ (-1 : ℝ) := by linarith
  have hformula :
      (∫ r in d..1, r ^ (-a - 1)) =
        ((1 : ℝ) ^ ((-a - 1) + 1) - d ^ ((-a - 1) + 1)) /
          ((-a - 1) + 1) :=
    integral_rpow (Or.inr ⟨hexp, hzero⟩)
  have hset : (∫ r in Ioo d 1, r ^ (-a - 1)) = ∫ r in d..1, r ^ (-a - 1) := by
    rw [← integral_Ioc_eq_integral_Ioo, intervalIntegral.integral_of_le hd_one]
  rw [hset, hformula]
  have ha_ne : a ≠ 0 := ha.ne'
  rw [show -a - 1 + 1 = -a by ring, Real.one_rpow]
  field_simp [ha_ne]
  ring

/-- Beyond unit distance, a negative power with positive exponent is at most one. -/
theorem inversePower_le_one {a d : ℝ} (ha : 0 < a) (hd : 1 ≤ d) :
    d ^ (-a) ≤ 1 :=
  Real.rpow_le_one_of_one_le_of_nonpos hd (neg_nonpos.mpr ha.le)

end AffineCarleson.Internal
