import AffineCarleson.SelfImprovement.AffineChangeVariables
import AffineCarleson.SelfImprovement.BallVariance
import Mathlib.MeasureTheory.Integral.Bochner.Set

/-! Bochner-integral and `MemLp` transport under affine coordinate changes. -/

noncomputable section
set_option autoImplicit false

open Set MeasureTheory
open scoped ENNReal

namespace AffineCarleson.Internal

private def affineScaleEquiv {n : ℕ} (x₀ : Fin n → ℝ) (R : ℝ) (hR : 0 < R) :
    (Fin n → ℝ) ≃ᵐ (Fin n → ℝ) where
  toFun y i := x₀ i + R * y i
  invFun x i := (x i - x₀ i) / R
  left_inv y := by
    funext i
    field_simp
    ring
  right_inv x := by
    funext i
    field_simp
    ring
  measurable_toFun := by
    show Measurable (fun y : Fin n → ℝ ↦ fun i ↦ x₀ i + R * y i)
    fun_prop
  measurable_invFun := by
    show Measurable (fun x : Fin n → ℝ ↦ fun i ↦ (x i - x₀ i) / R)
    fun_prop

theorem setIntegral_affineScale {n : ℕ} (f : (Fin n → ℝ) → ℝ)
    (x₀ c : Fin n → ℝ) {R r : ℝ} (hR : 0 < R) :
    (∫ y in ballSet c r, f (fun i ↦ x₀ i + R * y i)) =
      (R ^ n)⁻¹ * ∫ x in ballSet (fun i ↦ x₀ i + R * c i) (R * r), f x := by
  let e := affineScaleEquiv x₀ R hR
  have hchange := setIntegral_map_equiv (μ := volume) e f
    (ballSet (fun i ↦ x₀ i + R * c i) (R * r))
  have hmap : Measure.map e volume = ENNReal.ofReal (R ^ n)⁻¹ • volume := by
    change Measure.map (fun y : Fin n → ℝ ↦ fun i ↦ x₀ i + R * y i) volume = _
    exact map_affineScale_volume x₀ hR
  rw [hmap, Measure.restrict_smul, integral_smul_measure] at hchange
  have hpow : 0 < R ^ n := pow_pos hR n
  have hpre : e ⁻¹' ballSet (fun i ↦ x₀ i + R * c i) (R * r) = ballSet c r := by
    change (fun y : Fin n → ℝ ↦ fun i ↦ x₀ i + R * y i) ⁻¹'
      ballSet (fun i ↦ x₀ i + R * c i) (R * r) = ballSet c r
    exact affineScale_preimage_ballSet x₀ c hR
  have hcoef : (ENNReal.ofReal (R ^ n)⁻¹).toReal = (R ^ n)⁻¹ := by
    rw [ENNReal.toReal_ofReal (inv_nonneg.2 hpow.le)]
  change (∫ y in ballSet c r, f (e y)) = _
  rw [← hpre]
  simpa only [hcoef, smul_eq_mul] using hchange.symm

private theorem map_restrict_affineScale_ball {n : ℕ} (x₀ c : Fin n → ℝ)
    {R r : ℝ} (hR : 0 < R) :
    Measure.map (affineScaleEquiv x₀ R hR)
        (volume.restrict (ballSet c r)) =
      ENNReal.ofReal (R ^ n)⁻¹ •
        volume.restrict (ballSet (fun i ↦ x₀ i + R * c i) (R * r)) := by
  let e := affineScaleEquiv x₀ R hR
  have hpre := affineScale_preimage_ballSet x₀ c hR (r := r)
  change e ⁻¹' ballSet (fun i ↦ x₀ i + R * c i) (R * r) = ballSet c r at hpre
  have hmap : Measure.map e volume = ENNReal.ofReal (R ^ n)⁻¹ • volume := by
    change Measure.map (fun y : Fin n → ℝ ↦ fun i ↦ x₀ i + R * y i) volume = _
    exact map_affineScale_volume x₀ hR
  calc
    Measure.map (affineScaleEquiv x₀ R hR) (volume.restrict (ballSet c r)) =
        Measure.map e (volume.restrict (e ⁻¹'
          ballSet (fun i ↦ x₀ i + R * c i) (R * r))) := by
      rw [hpre]
    _ = (Measure.map e volume).restrict
        (ballSet (fun i ↦ x₀ i + R * c i) (R * r)) :=
      (e.restrict_map volume _).symm
    _ = _ := by rw [hmap, Measure.restrict_smul]

theorem memLp_comp_affineScale_ball {n : ℕ} {E : Type*} [NormedAddCommGroup E]
    {p : ℝ≥0∞} {f : (Fin n → ℝ) → E} (x₀ c : Fin n → ℝ)
    {R r : ℝ} (hR : 0 < R)
    (hf : MemLp f p
      (volume.restrict (ballSet (fun i ↦ x₀ i + R * c i) (R * r)))) :
    MemLp (fun y ↦ f (fun i ↦ x₀ i + R * y i)) p
      (volume.restrict (ballSet c r)) := by
  let e := affineScaleEquiv x₀ R hR
  have hc : ENNReal.ofReal (R ^ n)⁻¹ ≠ ⊤ := by simp
  have hm := hf.smul_measure hc
  rw [← map_restrict_affineScale_ball x₀ c hR] at hm
  exact (e.memLp_map_measure_iff).mp hm

theorem IntegrableOn.comp_affineScale_ball {n : ℕ} {E : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] {f : (Fin n → ℝ) → E}
    (x₀ c : Fin n → ℝ) {R r : ℝ} (hR : 0 < R)
    (hf : IntegrableOn f
      (ballSet (fun i ↦ x₀ i + R * c i) (R * r))) :
    IntegrableOn (fun y ↦ f (fun i ↦ x₀ i + R * y i)) (ballSet c r) := by
  rw [IntegrableOn] at hf ⊢
  let e := affineScaleEquiv x₀ R hR
  have hc : ENNReal.ofReal (R ^ n)⁻¹ ≠ ⊤ := by simp
  have hm := hf.smul_measure hc
  rw [← map_restrict_affineScale_ball x₀ c hR] at hm
  exact (integrable_map_equiv e f).mp hm

theorem ballOscillation_affineScale {n m : ℕ}
    (g : (Fin n → ℝ) → Fin m → ℝ) (x₀ c : Fin n → ℝ)
    {R r : ℝ} (hR : 0 < R) (hr : 0 < r) :
    ballOscillation c r (fun y ↦ g (fun i ↦ x₀ i + R * y i)) =
      ballOscillation (fun i ↦ x₀ i + R * c i) (R * r) g := by
  let T : (Fin n → ℝ) → (Fin n → ℝ) := fun y i ↦ x₀ i + R * y i
  let cT : Fin n → ℝ := fun i ↦ x₀ i + R * c i
  let VS : ℝ := (volume (ballSet c r)).toReal
  let VT : ℝ := (volume (ballSet cT (R * r))).toReal
  let J : ℝ := (R ^ n)⁻¹
  have hJ : 0 < J := inv_pos.mpr (pow_pos hR n)
  have hVT : 0 < VT := by
    exact volume_ballSet_toReal_pos cT (mul_pos hR hr)
  have hmass : VS = J * VT := by
    have h := setIntegral_affineScale (fun _ : Fin n → ℝ ↦ (1 : ℝ)) x₀ c hR (r := r)
    simpa only [VS, VT, J, cT, integral_const, measureReal_restrict_apply_univ,
      measureReal_def, Measure.restrict_apply_univ, smul_eq_mul, mul_one] using h
  have hmean (i : Fin m) :
      VS⁻¹ * ∫ v in ballSet c r, g (T v) i =
        VT⁻¹ * ∫ v in ballSet cT (R * r), g v i := by
    have hi := setIntegral_affineScale (fun v ↦ g v i) x₀ c hR (r := r)
    change (∫ v in ballSet c r, g (T v) i) =
      J * ∫ v in ballSet cT (R * r), g v i at hi
    rw [hi]
    change VS⁻¹ * (J * _) = VT⁻¹ * _
    rw [hmass]
    field_simp [hJ.ne', hVT.ne']
  unfold ballOscillation
  change VS⁻¹ *
      (∫ u in ballSet c r, ∑ i, (g (T u) i - VS⁻¹ * ∫ v in ballSet c r, g (T v) i) ^ 2) =
    VT⁻¹ *
      ∫ u in ballSet cT (R * r), ∑ i, (g u i - VT⁻¹ * ∫ v in ballSet cT (R * r), g v i) ^ 2
  have hpoint (u : Fin n → ℝ) :
      (∑ i, (g (T u) i - VS⁻¹ * ∫ v in ballSet c r, g (T v) i) ^ 2) =
        ∑ i, (g (T u) i - VT⁻¹ * ∫ v in ballSet cT (R * r), g v i) ^ 2 := by
    apply Finset.sum_congr rfl
    intro i _
    rw [hmean i]
  have hout :
      (∫ u in ballSet c r,
        ∑ i, (g (T u) i - VS⁻¹ * ∫ v in ballSet c r, g (T v) i) ^ 2) =
      J * ∫ u in ballSet cT (R * r),
        ∑ i, (g u i - VT⁻¹ * ∫ v in ballSet cT (R * r), g v i) ^ 2 := by
    calc
      _ = ∫ u in ballSet c r,
          ∑ i, (g (T u) i - VT⁻¹ * ∫ v in ballSet cT (R * r), g v i) ^ 2 := by
        exact setIntegral_congr_fun (measurableSet_ballSet c r) (fun u _ ↦ hpoint u)
      _ = _ := setIntegral_affineScale
        (fun u ↦ ∑ i, (g u i - VT⁻¹ * ∫ v in ballSet cT (R * r), g v i) ^ 2)
        x₀ c hR
  rw [hout, hmass]
  field_simp [hJ.ne', hVT.ne']

end AffineCarleson.Internal
