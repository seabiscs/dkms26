import AffineCarleson.SelfImprovement.Scaling
import Mathlib.MeasureTheory.Measure.Lebesgue.EqHaar
import Mathlib.MeasureTheory.Integral.Lebesgue.Map

/-! Affine changes of variables on the source coordinate carrier. -/

noncomputable section
set_option autoImplicit false

open Set MeasureTheory

namespace AffineCarleson.Internal

theorem affineScale_preimage_ballSet {n : ℕ} (x₀ c : Fin n → ℝ) {R r : ℝ}
    (hR : 0 < R) :
    (fun y : Fin n → ℝ ↦ fun i ↦ x₀ i + R * y i) ⁻¹'
        ballSet (fun i ↦ x₀ i + R * c i) (R * r) = ballSet c r := by
  ext y
  simp only [ballSet, mem_preimage, mem_ofPred_eq]
  have hsum :
      (∑ i, ((x₀ i + R * y i) - (x₀ i + R * c i)) ^ 2) =
        R ^ 2 * ∑ i, (y i - c i) ^ 2 := by
    simp_rw [show ∀ i, (x₀ i + R * y i) - (x₀ i + R * c i) = R * (y i - c i) by
      intro i
      ring]
    simp_rw [mul_pow]
    rw [Finset.mul_sum]
  rw [hsum, mul_pow]
  constructor <;> intro h <;> nlinarith [sq_pos_of_pos hR]

theorem map_affineScale_volume {n : ℕ} (x₀ : Fin n → ℝ) {R : ℝ} (hR : 0 < R) :
    Measure.map (fun y : Fin n → ℝ ↦ fun i ↦ x₀ i + R * y i) volume =
      ENNReal.ofReal (R ^ n)⁻¹ • volume := by
  have hscale := (volume : Measure (Fin n → ℝ)).map_addHaar_smul hR.ne'
  have hscale' : Measure.map (R • ·) (volume : Measure (Fin n → ℝ)) =
      ENNReal.ofReal (R ^ n)⁻¹ • volume := by
    simpa [Module.finrank_pi_fintype, abs_of_pos (pow_pos hR n)] using hscale
  calc
    Measure.map (fun y : Fin n → ℝ ↦ fun i ↦ x₀ i + R * y i) volume =
        Measure.map ((x₀ + ·) ∘ (R • ·)) volume := by
      rfl
    _ = Measure.map (x₀ + ·) (Measure.map (R • ·) volume) :=
      (Measure.map_map (measurable_const_add x₀) (measurable_const_smul R)).symm
    _ = Measure.map (x₀ + ·) (ENNReal.ofReal (R ^ n)⁻¹ • volume) := by rw [hscale']
    _ = ENNReal.ofReal (R ^ n)⁻¹ • Measure.map (x₀ + ·) volume := by
      rw [Measure.map_smul]
    _ = ENNReal.ofReal (R ^ n)⁻¹ • volume := by rw [map_add_left_eq_self]

theorem setLIntegral_affineScale {n : ℕ} (F : (Fin n → ℝ) → ENNReal)
    (hF : Measurable F) (x₀ c : Fin n → ℝ) {R r : ℝ} (hR : 0 < R) :
    (∫⁻ y in ballSet c r, F (fun i ↦ x₀ i + R * y i)) =
      ENNReal.ofReal (R ^ n)⁻¹ *
        ∫⁻ x in ballSet (fun i ↦ x₀ i + R * c i) (R * r), F x := by
  let T : (Fin n → ℝ) → (Fin n → ℝ) := fun y i ↦ x₀ i + R * y i
  have hT : Measurable T := by fun_prop
  have hball := affineScale_preimage_ballSet x₀ c hR (r := r)
  have hmap := map_affineScale_volume x₀ hR
  have hchange := setLIntegral_map
    (μ := volume) (g := T) (f := F)
    (measurableSet_ballSet (fun i ↦ x₀ i + R * c i) (R * r)) hF hT
  rw [hmap] at hchange
  simp only [Measure.restrict_smul, lintegral_smul_measure, smul_eq_mul] at hchange
  simpa only [T, hball] using hchange.symm

end AffineCarleson.Internal
