import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Tactic

/-!
# Exponent arithmetic for self-improvement

Elementary facts about the constants and exponents in the iteration argument.
-/

namespace AffineCarleson.Internal

theorem iterationRatio_pos (n : ℕ) {K : ℝ} (hK : 1 ≤ K) :
    0 < (4 : ℝ) ^ n * K / ((4 : ℝ) ^ n * K + Real.log 4) := by
  have hc : 0 < (4 : ℝ) ^ n * K := mul_pos (pow_pos (by norm_num) n) (zero_lt_one.trans_le hK)
  have hl : 0 < Real.log (4 : ℝ) := Real.log_pos (by norm_num)
  positivity

theorem iterationRatio_lt_one (n : ℕ) {K : ℝ} (hK : 1 ≤ K) :
    (4 : ℝ) ^ n * K / ((4 : ℝ) ^ n * K + Real.log 4) < 1 := by
  have hc : 0 < (4 : ℝ) ^ n * K := mul_pos (pow_pos (by norm_num) n) (zero_lt_one.trans_le hK)
  have hl : 0 < Real.log (4 : ℝ) := Real.log_pos (by norm_num)
  exact (div_lt_one (add_pos hc hl)).2 (by linarith only [hl])

theorem baseExponent_pos (n : ℕ) {K : ℝ} (hK : 1 ≤ K) :
    0 < Real.log (1 + Real.log 4 / ((4 : ℝ) ^ n * K)) / (2 * Real.log 16) := by
  have hc : 0 < (4 : ℝ) ^ n * K := mul_pos (pow_pos (by norm_num) n) (zero_lt_one.trans_le hK)
  have hl4 : 0 < Real.log (4 : ℝ) := Real.log_pos (by norm_num)
  have hl16 : 0 < Real.log (16 : ℝ) := Real.log_pos (by norm_num)
  have harg : 1 < 1 + Real.log 4 / ((4 : ℝ) ^ n * K) := lt_add_of_pos_right 1 (div_pos hl4 hc)
  exact div_pos (Real.log_pos harg) (mul_pos (by norm_num) hl16)

theorem baseExponent_lt_one (n : ℕ) {K : ℝ} (hK : 1 ≤ K) :
    Real.log (1 + Real.log 4 / ((4 : ℝ) ^ n * K)) / (2 * Real.log 16) < 1 := by
  have hc : 1 ≤ (4 : ℝ) ^ n * K := by
    have hp : 1 ≤ (4 : ℝ) ^ n := one_le_pow₀ (by norm_num)
    simpa only [one_mul] using mul_le_mul hp hK (by norm_num) (by positivity)
  have hl4 : 0 < Real.log (4 : ℝ) := Real.log_pos (by norm_num)
  have hl16 : 0 < Real.log (16 : ℝ) := Real.log_pos (by norm_num)
  have hdiv : Real.log 4 / ((4 : ℝ) ^ n * K) ≤ Real.log 4 :=
    (div_le_iff₀ (zero_lt_one.trans_le hc)).2 (by nlinarith only [hl4, hc])
  have harg : 0 < 1 + Real.log 4 / ((4 : ℝ) ^ n * K) :=
    lt_trans zero_lt_one (lt_add_of_pos_right 1 (div_pos hl4 (zero_lt_one.trans_le hc)))
  have hlog : Real.log (1 + Real.log 4 / ((4 : ℝ) ^ n * K)) < Real.log 16 := by
    apply Real.log_lt_log harg
    calc
      1 + Real.log 4 / ((4 : ℝ) ^ n * K) ≤ 1 + Real.log 4 := by linarith only [hdiv]
      _ < 16 := by
        have := Real.log_lt_sub_one_of_pos (show (0 : ℝ) < 4 by norm_num) (by norm_num)
        linarith
  apply (div_lt_one (mul_pos (by norm_num) hl16)).2
  linarith only [hlog, hl16]

theorem iterationExponent_eq_twice_baseExponent (n : ℕ) {K : ℝ} (hK : 1 ≤ K) :
    Real.log (1 / ((4 : ℝ) ^ n * K / ((4 : ℝ) ^ n * K + Real.log 4))) /
        Real.log 16 =
      2 * (Real.log (1 + Real.log 4 / ((4 : ℝ) ^ n * K)) / (2 * Real.log 16)) := by
  have hc : 0 < (4 : ℝ) ^ n * K := mul_pos (pow_pos (by norm_num) n) (zero_lt_one.trans_le hK)
  have hl16 : Real.log (16 : ℝ) ≠ 0 := ne_of_gt (Real.log_pos (by norm_num))
  have hfrac :
      1 / ((4 : ℝ) ^ n * K / ((4 : ℝ) ^ n * K + Real.log 4)) =
        1 + Real.log 4 / ((4 : ℝ) ^ n * K) := by
    field_simp
  rw [hfrac]
  field_simp

theorem iterationRatio_eq_rpow_neg_iterationExponent (n : ℕ) {K : ℝ} (hK : 1 ≤ K) :
    (4 : ℝ) ^ n * K / ((4 : ℝ) ^ n * K + Real.log 4) =
      (16 : ℝ) ^
        (-(Real.log (1 / ((4 : ℝ) ^ n * K /
          ((4 : ℝ) ^ n * K + Real.log 4))) / Real.log 16)) := by
  let θ := (4 : ℝ) ^ n * K / ((4 : ℝ) ^ n * K + Real.log 4)
  have hθ : 0 < θ := iterationRatio_pos n hK
  have hlog16 : Real.log (16 : ℝ) ≠ 0 := ne_of_gt (Real.log_pos (by norm_num))
  rw [Real.rpow_def_of_pos (by norm_num : (0 : ℝ) < 16)]
  have halg : Real.log (16 : ℝ) * (-(Real.log (1 / θ) / Real.log 16)) =
      -Real.log (1 / θ) := by
    field_simp
  rw [halg, Real.exp_neg, Real.exp_log (by positivity : 0 < 1 / θ)]
  dsimp [θ]
  field_simp

theorem iterationRatio_lt_rpow_neg (n : ℕ) {K γ : ℝ} (hK : 1 ≤ K)
    (hγ : γ < 2 * (Real.log (1 + Real.log 4 / ((4 : ℝ) ^ n * K)) /
      (2 * Real.log 16))) :
    (4 : ℝ) ^ n * K / ((4 : ℝ) ^ n * K + Real.log 4) < (16 : ℝ) ^ (-γ) := by
  rw [iterationRatio_eq_rpow_neg_iterationExponent n hK]
  apply Real.rpow_lt_rpow_of_exponent_lt (by norm_num)
  rw [iterationExponent_eq_twice_baseExponent n hK]
  exact neg_lt_neg hγ

theorem rpow_neg_pos_lt_one {γ : ℝ} (hγ : 0 < γ) :
    0 < (16 : ℝ) ^ (-γ) ∧ (16 : ℝ) ^ (-γ) < 1 := by
  exact ⟨Real.rpow_pos_of_pos (by norm_num) _,
    Real.rpow_lt_one_of_one_lt_of_neg (by norm_num) (neg_neg_of_pos hγ)⟩

theorem rpow_neg_lt_rpow_neg {γ σ : ℝ} (hγσ : γ < σ) :
    (16 : ℝ) ^ (-σ) < (16 : ℝ) ^ (-γ) := by
  exact Real.rpow_lt_rpow_of_exponent_lt (by norm_num) (neg_lt_neg hγσ)

theorem exists_exponent_between {s s₀ σ : ℝ} (hs₀ : s < s₀) (hσ : s < σ / 2) :
    ∃ γ, 2 * s < γ ∧ γ < min (2 * s₀) σ := by
  apply exists_between
  rw [lt_min_iff]
  constructor <;> linarith

end AffineCarleson.Internal
