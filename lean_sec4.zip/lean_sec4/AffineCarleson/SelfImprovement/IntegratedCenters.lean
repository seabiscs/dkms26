import AffineCarleson.SelfImprovement.CenterTonelli

/-! The moving-center Tonelli estimates in the fixed-ball source argument. -/

noncomputable section
set_option autoImplicit false
open Set MeasureTheory

namespace AffineCarleson.Internal

theorem lintegral_ballSet_radius_swap {n : ℕ}
    (F : (Fin n → ℝ) → ℝ → ENNReal) (hF : Measurable (Function.uncurry F))
    (A : Set (Fin n → ℝ)) (I : Set ℝ) (t : ℝ) :
    (∫⁻ r in I, ∫⁻ c in A, ∫⁻ x in ballSet c t, F x r) =
      ∫⁻ c in A, ∫⁻ x in ballSet c t, ∫⁻ r in I, F x r := by
  classical
  have hset : MeasurableSet {p : (ℝ × (Fin n → ℝ)) × (Fin n → ℝ) |
      p.2 ∈ ballSet p.1.2 t} :=
    (measurableSet_ballSet_relation t).preimage
      ((measurable_snd.comp measurable_fst).prodMk measurable_snd)
  have hkernel : Measurable (fun p : (ℝ × (Fin n → ℝ)) × (Fin n → ℝ) ↦
      if p.2 ∈ ballSet p.1.2 t then F p.2 p.1.1 else 0) := by
    exact Measurable.ite hset
      (hF.comp (measurable_snd.prodMk (measurable_fst.comp measurable_fst))) measurable_const
  have hinner : Measurable (fun p : ℝ × (Fin n → ℝ) ↦
      ∫⁻ x in ballSet p.2 t, F x p.1) := by
    convert hkernel.lintegral_prod_right' (ν := volume) using 1
    funext p
    exact (lintegral_indicator (measurableSet_ballSet p.2 t) (fun x ↦ F x p.1)).symm
  calc
    (∫⁻ r in I, ∫⁻ c in A, ∫⁻ x in ballSet c t, F x r) =
        ∫⁻ c in A, ∫⁻ r in I, ∫⁻ x in ballSet c t, F x r :=
      lintegral_lintegral_swap hinner.aemeasurable
    _ = ∫⁻ c in A, ∫⁻ x in ballSet c t, ∫⁻ r in I, F x r := by
      apply lintegral_congr
      intro c
      exact lintegral_lintegral_swap (hF.comp measurable_swap).aemeasurable

/-- This is the lower bound obtained by integrating the source hypothesis
over centers in `B(0,1+2t)`, before applying that hypothesis. -/
theorem integrated_centers_lower {n : ℕ}
    (F : (Fin n → ℝ) → ℝ → ENNReal) (hF : Measurable (Function.uncurry F))
    {t : ℝ} (ht : 0 < t) :
    volume (ballSet (0 : Fin n → ℝ) t) *
        (∫⁻ r in Ioo (0 : ℝ) t, ∫⁻ x in ballSet 0 (1 + r), F x r) ≤
      ∫⁻ c in ballSet 0 (1 + 2 * t), ∫⁻ x in ballSet c t,
        ∫⁻ r in Ioo (0 : ℝ) t, F x r := by
  calc
    volume (ballSet (0 : Fin n → ℝ) t) *
        (∫⁻ r in Ioo (0 : ℝ) t, ∫⁻ x in ballSet 0 (1 + r), F x r) =
        ∫⁻ r in Ioo (0 : ℝ) t, volume (ballSet (0 : Fin n → ℝ) t) *
          (∫⁻ x in ballSet 0 (1 + r), F x r) :=
      (lintegral_const_mul' _ _ (volume_ballSet_ne_top 0 ht)).symm
    _ ≤ ∫⁻ r in Ioo (0 : ℝ) t, ∫⁻ c in ballSet 0 (1 + 2 * t),
        ∫⁻ x in ballSet c t, F x r := by
      apply setLIntegral_mono' measurableSet_Ioo
      intro r hr
      apply lintegral_ballSet_centers_lower (fun x ↦ F x r)
        (hF.comp (measurable_id.prodMk measurable_const)) _ _ (measurableSet_ballSet _ _) ht
      intro x hx
      exact moving_ballSet_subset zero_lt_one hr.1 hr.2.le hx
    _ = ∫⁻ c in ballSet 0 (1 + 2 * t), ∫⁻ x in ballSet c t,
        ∫⁻ r in Ioo (0 : ℝ) t, F x r :=
      lintegral_ballSet_radius_swap F hF _ _ t

/-- The error integral over centers is bounded by the mass of `B(0,4t)`
times the error integral on `B(0,8)`. -/
theorem integrated_centers_error_upper {n : ℕ} (F : (Fin n → ℝ) → ENNReal)
    (hF : Measurable F) {t : ℝ} (ht : 0 < t) (ht_upper : t ≤ 1 / 4) :
    (∫⁻ c in ballSet 0 (1 + 2 * t), ∫⁻ x in ballSet c (4 * t), F x) ≤
      volume (ballSet (0 : Fin n → ℝ) (4 * t)) * (∫⁻ x in ballSet 0 8, F x) := by
  apply lintegral_ballSet_centers_upper F hF _ _ (measurableSet_ballSet _ _) (by positivity)
  intro c hc
  have hd := (mem_ballSet_iff_euclidean_dist (by positivity : 0 < 1 + 2 * t)).mp hc
  exact ballSet_subset_of_dist_add_le (by positivity) (by norm_num) (by linarith)

end AffineCarleson.Internal
