import AffineCarleson.SelfImprovement.UnitFractional
import AffineCarleson.SelfImprovement.RelativeDensity
import AffineCarleson.SelfImprovement.OscillationMoment

/-! The quantitative self-improvement estimate on the unit ball. -/

noncomputable section
set_option autoImplicit false
open Set MeasureTheory

namespace AffineCarleson.Internal

theorem unit_selfImprovement (n : ℕ) (K σ s : ℝ)
    (hK : 1 ≤ K) (hσ : 0 < σ) (hs : 0 < s)
    (hsmax : s < min
      (Real.log (1 + Real.log 4 / ((4 : ℝ) ^ n * K)) / (2 * Real.log 16)) (σ / 2)) :
    ∃ C : ℝ, 0 < C ∧ ∀ (m : ℕ)
      (g : (Fin n → ℝ) → Fin m → ℝ) (μ : (Fin n → ℝ) → ℝ) (M : ℝ),
      (∀ i, Measurable (fun u ↦ g u i)) →
      (∀ i, MemLp (fun u ↦ g u i) 2 (volume.restrict (ballSet (0 : Fin n → ℝ) 8))) →
      Measurable μ → (∀ u, 0 ≤ μ u) → IntegrableOn μ (ballSet 0 8) → 0 ≤ M →
      (∀ t ∈ Ioc (0 : ℝ) 1, ∀ c ∈ ballSet (0 : Fin n → ℝ) (1 + 2 * t),
        (∫⁻ x in ballSet c t, ∫⁻ r in Ioo (0 : ℝ) t,
          ENNReal.ofReal (ballOscillation x r g / r)) ≤
        ENNReal.ofReal (K * (volume (ballSet c (4 * t))).toReal * ballOscillation c (4 * t) g +
          M * t ^ σ * ∫ y in ballSet c (4 * t), μ y)) →
      (∫⁻ u in ballSet (0 : Fin n → ℝ) 1, ∫⁻ v in ballSet (0 : Fin n → ℝ) 1,
        ENNReal.ofReal ((∑ i, (g u i - g v i) ^ 2) /
          (Real.sqrt (∑ i, (u i - v i) ^ 2)) ^ ((n : ℝ) + 2 * s))) ≤
        ENNReal.ofReal (C * ((∫ u in ballSet (0 : Fin n → ℝ) 8, ∑ i, g u i ^ 2) +
          M * ∫ u in ballSet (0 : Fin n → ℝ) 8, μ u)) := by
  obtain ⟨D, hD, hmoment⟩ := oscillation_weightedMoment_of_tail_contract n K σ s hK hs hsmax
  let V := (volume (ballSet (0 : Fin n → ℝ) 1)).toReal
  let c := (4 : ℝ) ^ n * K
  let q := (4 : ℝ) ^ n
  let e := (4 : ℝ) ^ σ * Real.log 4 / (c + Real.log 4)
  let d := q * (1 + e)
  let L := ((n : ℝ) + 2 * s) * (2 : ℝ) ^ (n + 1) * V
  let C := 2 * V + L * D * (c + d)
  have hV : 0 < V := volume_ballSet_toReal_pos 0 zero_lt_one
  have hc : 0 < c := mul_pos (by positivity) (zero_lt_one.trans_le hK)
  have hq : 0 < q := by positivity
  have hlog : 0 < Real.log (4 : ℝ) := Real.log_pos (by norm_num)
  have he : 0 < e := div_pos (mul_pos (Real.rpow_pos_of_pos (by norm_num) _) hlog)
    (add_pos hc hlog)
  have hd : 0 < d := mul_pos hq (by linarith)
  have hL : 0 < L := by dsimp only [L]; positivity
  have hC : 0 < C := by dsimp only [C]; positivity
  refine ⟨C, hC, ?_⟩
  intro m g μ M hgmeas hg hμmeas hμnonneg hμint hM hrel
  let E := fun r : ℝ ↦ ∫ x in ballSet (0 : Fin n → ℝ) (1 + r), ballOscillation x r g
  let A := ∫ u in ballSet (0 : Fin n → ℝ) 8, ∑ i, g u i ^ 2
  let Q := ∫ u in ballSet (0 : Fin n → ℝ) 8, μ u
  let X := M * Q
  let B := q * X * e
  have hA : 0 ≤ A := integral_nonneg fun u ↦ Finset.sum_nonneg fun i _ ↦ sq_nonneg _
  have hQ : 0 ≤ Q := integral_nonneg hμnonneg
  have hX : 0 ≤ X := mul_nonneg hM hQ
  have hB : 0 ≤ B := mul_nonneg (mul_nonneg hq.le hX) he.le
  have hEmeas : Measurable E := measurable_oscillationDensity g hgmeas
  have hEnonneg : ∀ r ∈ Ioo (0 : ℝ) 1, 0 ≤ E r :=
    fun r hr ↦ oscillationDensity_nonneg g hr.1
  obtain ⟨hfinite, htail⟩ := relative_unit_tail_finite_and_le g hgmeas hg μ hμmeas
    hμnonneg hμint hK hM hrel
  have hfinite' : (∫⁻ r in Ioo (0 : ℝ) 1, ENNReal.ofReal (E r / r)) ≠ ⊤ := hfinite.ne
  have hscale : ∀ t, 0 < t → t ≤ 1 / 4 → tailIntegral E t ≤ c * E (4 * t) +
      (q * X) * t ^ σ := by
    intro t ht htq
    have h := relative_density_scale_le g hgmeas hg μ hμmeas hμnonneg hμint
      hK hM ht htq hrel
    convert h using 1
    dsimp only [E, c, q, X, Q]
    ring
  have hcontract : ∀ r ∈ Ioc (0 : ℝ) (1 / 16),
      (∫⁻ t in Ioo (0 : ℝ) r, ENNReal.ofReal (E t / t)).toReal ≤
        ((4 : ℝ) ^ n * K / ((4 : ℝ) ^ n * K + Real.log 4)) *
          (∫⁻ t in Ioo (0 : ℝ) (16 * r), ENNReal.ofReal (E t / t)).toReal + B * r ^ σ := by
    intro r hr
    have h := tailIntegral_contract E hEmeas hEnonneg hfinite' hc
      (mul_nonneg hq.le hX) hσ hscale hr.1 hr.2
    change tailIntegral E r ≤ c / (c + Real.log 4) * tailIntegral E (16 * r) + B * r ^ σ
    have hBeq : B = q * X * (4 : ℝ) ^ σ * Real.log 4 / (c + Real.log 4) := by
      dsimp only [B, e]
      ring
    rw [hBeq]
    exact h
  have hm := hmoment E B hB hEmeas hEnonneg hfinite' hcontract
  have htail' : tailIntegral E 1 ≤ c * A + q * X := by
    convert htail using 1
    dsimp only [E, c, A, q, X, Q]
    ring
  have habsorb : tailIntegral E 1 + B ≤ (c + d) * (A + X) := by
    calc
      _ ≤ c * A + q * X + B := add_le_add htail' le_rfl
      _ = c * A + d * X := by dsimp only [B, d]; ring
      _ ≤ (c + d) * (A + X) := by
        nlinarith only [mul_nonneg hc.le hX, mul_nonneg hd.le hA]
  have hk := unitFractionalEnergy_le_densityMoment g hgmeas hg hs
  have htail_nonneg : 0 ≤ tailIntegral E 1 := tailIntegral_nonneg E 1
  have hmoment_bound : ENNReal.ofReal L *
      (∫⁻ r in Ioo (0 : ℝ) 1, ENNReal.ofReal (r ^ (-(2 * s)) * E r / r)) ≤
      ENNReal.ofReal (L * D * (tailIntegral E 1 + B)) := by
    calc
      _ ≤ ENNReal.ofReal L * ENNReal.ofReal (D * (tailIntegral E 1 + B)) :=
        mul_le_mul_right hm _
      _ = _ := by rw [← ENNReal.ofReal_mul hL.le]; congr 1; ring
  calc
    _ ≤ ENNReal.ofReal (2 * V * A) + ENNReal.ofReal L *
        (∫⁻ r in Ioo (0 : ℝ) 1, ENNReal.ofReal (r ^ (-(2 * s)) * E r / r)) := hk
    _ ≤ ENNReal.ofReal (2 * V * A) + ENNReal.ofReal (L * D * (tailIntegral E 1 + B)) :=
      add_le_add le_rfl hmoment_bound
    _ = ENNReal.ofReal (2 * V * A + L * D * (tailIntegral E 1 + B)) := by
      rw [ENNReal.ofReal_add (by positivity) (by positivity)]
    _ ≤ ENNReal.ofReal (C * (A + X)) := by
      apply ENNReal.ofReal_le_ofReal
      calc
        _ ≤ 2 * V * A + L * D * ((c + d) * (A + X)) :=
          add_le_add le_rfl (mul_le_mul_of_nonneg_left habsorb (mul_pos hL hD).le)
        _ ≤ C * (A + X) := by
          dsimp only [C]
          nlinarith only [mul_nonneg (mul_pos (by norm_num : (0 : ℝ) < 2) hV).le hX]

end AffineCarleson.Internal
