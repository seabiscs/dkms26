import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.MeasureTheory.Integral.Lebesgue.Map
import Mathlib.MeasureTheory.Integral.Lebesgue.Add
import Mathlib.Tactic

/-! Invariance of the logarithmic radius measure under positive dilations. -/

noncomputable section
set_option autoImplicit false
open Set MeasureTheory

namespace AffineCarleson.Internal

theorem setLIntegral_Ioo_mul {F : ℝ → ENNReal} (hF : Measurable F)
    {R : ℝ} (hR : 0 < R) (t : ℝ) :
    (∫⁻ r in Ioo (0 : ℝ) t, F (R * r)) =
      ENNReal.ofReal R⁻¹ * ∫⁻ u in Ioo (0 : ℝ) (R * t), F u := by
  have hmap := Real.map_volume_mul_left hR.ne'
  rw [abs_of_pos (inv_pos.mpr hR)] at hmap
  have hpre : (fun r : ℝ ↦ R * r) ⁻¹' Ioo 0 (R * t) = Ioo 0 t := by
    ext r
    simp only [mem_preimage, mem_Ioo]
    constructor
    · intro h
      exact ⟨(mul_pos_iff_of_pos_left hR).mp h.1, (mul_lt_mul_iff_right₀ hR).mp h.2⟩
    · intro h
      exact ⟨mul_pos hR h.1, mul_lt_mul_of_pos_left h.2 hR⟩
  have h := setLIntegral_map (μ := volume) (g := fun r : ℝ ↦ R * r) (f := F)
    (s := Ioo 0 (R * t)) measurableSet_Ioo hF (measurable_const.mul measurable_id)
  rw [hmap, hpre, Measure.restrict_smul, lintegral_smul_measure] at h
  exact h.symm

theorem radius_lintegral_div_scale (H : ℝ → ℝ) (hH : Measurable H)
    {R : ℝ} (hR : 0 < R) (t : ℝ) :
    (∫⁻ r in Ioo (0 : ℝ) t, ENNReal.ofReal (H (R * r) / r)) =
      ∫⁻ u in Ioo (0 : ℝ) (R * t), ENNReal.ofReal (H u / u) := by
  have hpoint (r : ℝ) : ENNReal.ofReal (H (R * r) / r) =
      ENNReal.ofReal R * ENNReal.ofReal (H (R * r) / (R * r)) := by
    rw [← ENNReal.ofReal_mul hR.le]
    congr 1
    by_cases hr : r = 0
    · simp only [hr, mul_zero, div_zero]
    · field_simp
  calc
    _ = ∫⁻ r in Ioo (0 : ℝ) t,
        ENNReal.ofReal R * ENNReal.ofReal (H (R * r) / (R * r)) := lintegral_congr hpoint
    _ = ENNReal.ofReal R *
        (∫⁻ r in Ioo (0 : ℝ) t, ENNReal.ofReal (H (R * r) / (R * r))) :=
      lintegral_const_mul' _ _ ENNReal.ofReal_ne_top
    _ = ENNReal.ofReal R * (ENNReal.ofReal R⁻¹ *
        ∫⁻ u in Ioo (0 : ℝ) (R * t), ENNReal.ofReal (H u / u)) := by
      congr 1
      exact setLIntegral_Ioo_mul (F := fun u ↦ ENNReal.ofReal (H u / u))
        (hH.div measurable_id).ennreal_ofReal hR t
    _ = _ := by
      rw [← mul_assoc, ← ENNReal.ofReal_mul hR.le, mul_inv_cancel₀ hR.ne',
        ENNReal.ofReal_one, one_mul]

end AffineCarleson.Internal
