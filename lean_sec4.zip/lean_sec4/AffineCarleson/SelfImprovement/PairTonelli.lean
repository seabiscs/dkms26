import AffineCarleson.SelfImprovement.CenterTonelli

/-! Pairwise integration over common ball centers. -/

noncomputable section
set_option autoImplicit false
open Set MeasureTheory

namespace AffineCarleson.Internal

theorem lintegral_pair_ballSet_centers {n : ℕ}
    (Q : (Fin n → ℝ) → (Fin n → ℝ) → ENNReal)
    (hQ : Measurable (Function.uncurry Q)) (A : Set (Fin n → ℝ)) (r : ℝ) :
    (∫⁻ c in A, ∫⁻ u in ballSet c r, ∫⁻ v in ballSet c r, Q u v) =
      ∫⁻ u, ∫⁻ v, volume (A ∩ ballSet u r ∩ ballSet v r) * Q u v := by
  classical
  let f : (Fin n → ℝ) → ((Fin n → ℝ) × (Fin n → ℝ)) → ENNReal :=
    fun c p ↦ if p.1 ∈ ballSet c r ∧ p.2 ∈ ballSet c r then Q p.1 p.2 else 0
  have hset : MeasurableSet {p : (Fin n → ℝ) × ((Fin n → ℝ) × (Fin n → ℝ)) |
      p.2.1 ∈ ballSet p.1 r ∧ p.2.2 ∈ ballSet p.1 r} := by
    exact ((measurableSet_ballSet_relation r).preimage
      (measurable_fst.prodMk (measurable_fst.comp measurable_snd))).inter
      ((measurableSet_ballSet_relation r).preimage
        (measurable_fst.prodMk (measurable_snd.comp measurable_snd)))
  have hf : Measurable (Function.uncurry f) :=
    Measurable.ite hset (hQ.comp measurable_snd) measurable_const
  have hrow (c : Fin n → ℝ) :
      (∫⁻ u in ballSet c r, ∫⁻ v in ballSet c r, Q u v) = ∫⁻ p, f c p := by
    have hfc : Measurable (f c) :=
      Measurable.ite ((measurableSet_ballSet c r).prod (measurableSet_ballSet c r))
        hQ measurable_const
    calc
      (∫⁻ u in ballSet c r, ∫⁻ v in ballSet c r, Q u v) = ∫⁻ u, ∫⁻ v, f c (u, v) := by
        rw [← lintegral_indicator (measurableSet_ballSet c r)]
        apply lintegral_congr
        intro u
        by_cases hu : u ∈ ballSet c r
        · rw [indicator_of_mem hu]
          simpa only [f, hu, true_and, indicator] using
            (lintegral_indicator (measurableSet_ballSet c r) (Q u)).symm
        · simp only [indicator_of_notMem hu, f, hu, false_and, ↓reduceIte, lintegral_zero]
      _ = ∫⁻ p, f c p := lintegral_lintegral hfc.aemeasurable
  have hcol (u v : Fin n → ℝ) :
      (∫⁻ c in A, f c (u, v)) = volume (A ∩ ballSet u r ∩ ballSet v r) * Q u v := by
    have heq : (fun c ↦ f c (u, v)) =
        (ballSet u r ∩ ballSet v r).indicator (fun _ ↦ Q u v) := by
      funext c
      simp only [f, indicator, mem_inter_iff, mem_ballSet_comm u c r, mem_ballSet_comm v c r]
    rw [heq, lintegral_indicator ((measurableSet_ballSet u r).inter (measurableSet_ballSet v r)),
      lintegral_const, Measure.restrict_apply_univ,
      Measure.restrict_apply ((measurableSet_ballSet u r).inter (measurableSet_ballSet v r))]
    rw [inter_comm (ballSet u r ∩ ballSet v r) A, ← inter_assoc, mul_comm]
  calc
    (∫⁻ c in A, ∫⁻ u in ballSet c r, ∫⁻ v in ballSet c r, Q u v) =
        ∫⁻ c in A, ∫⁻ p, f c p := lintegral_congr hrow
    _ = ∫⁻ p, ∫⁻ c in A, f c p := lintegral_lintegral_swap hf.aemeasurable
    _ = ∫⁻ u, ∫⁻ v, ∫⁻ c in A, f c (u, v) :=
      (lintegral_prod _ (hf.comp measurable_swap).lintegral_prod_right'.aemeasurable)
    _ = ∫⁻ u, ∫⁻ v, volume (A ∩ ballSet u r ∩ ballSet v r) * Q u v := by
      apply lintegral_congr
      intro u
      exact lintegral_congr (hcol u)

end AffineCarleson.Internal
