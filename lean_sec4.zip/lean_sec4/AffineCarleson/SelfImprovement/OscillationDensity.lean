import AffineCarleson.SelfImprovement.OscillationEnergy
import Mathlib.MeasureTheory.Integral.Prod

/-!
# The averaged oscillation density

Measurability and exact lower-integral identities for the source's actual averaged ball
oscillation. No integrability of the resulting function of the radius is assumed.
-/

noncomputable section
set_option autoImplicit false

open Set MeasureTheory
open scoped BigOperators ENNReal

namespace AffineCarleson.Internal

theorem measurable_oscillationDensity {n m : ℕ}
    (g : (Fin n → ℝ) → Fin m → ℝ) (hgmeas : ∀ i, Measurable (fun y ↦ g y i)) :
    Measurable (fun r : ℝ ↦
      ∫ x in ballSet (0 : Fin n → ℝ) (1 + r), ballOscillation x r g) := by
  classical
  have hmem : MeasurableSet
      {q : (Fin n → ℝ) × ℝ | q.1 ∈ ballSet 0 (1 + q.2)} := by
    simp only [ballSet, mem_ofPred_eq, Pi.zero_apply, sub_zero]
    exact measurableSet_lt
      (Finset.measurable_sum Finset.univ fun i _ ↦
        ((measurable_pi_apply i).comp measurable_fst).pow_const 2)
      ((measurable_const.add measurable_snd).pow_const 2)
  have hosc : Measurable
      (fun q : (Fin n → ℝ) × ℝ ↦ ballOscillation q.1 q.2 g) :=
    measurable_ballOscillation g hgmeas
  have hjoint : StronglyMeasurable
      (fun q : (Fin n → ℝ) × ℝ ↦
        if q.1 ∈ ballSet 0 (1 + q.2) then ballOscillation q.1 q.2 g else 0) :=
    (Measurable.ite hmem hosc measurable_const).stronglyMeasurable
  have hint := hjoint.integral_prod_left' (μ := volume)
  convert hint.measurable using 1
  funext r
  rw [show (fun x : Fin n → ℝ ↦
      if x ∈ ballSet 0 (1 + r) then ballOscillation x r g else 0) =
      (ballSet 0 (1 + r)).indicator (fun x ↦ ballOscillation x r g) by
        funext x
        rfl]
  exact (integral_indicator (measurableSet_ballSet 0 (1 + r))).symm

theorem integrableOn_ballOscillation_moving {n m : ℕ}
    (g : (Fin n → ℝ) → Fin m → ℝ) (hgmeas : ∀ i, Measurable (fun y ↦ g y i))
    (hg : ∀ i, MemLp (fun y ↦ g y i) 2
      (volume.restrict (ballSet (0 : Fin n → ℝ) 8)))
    {r : ℝ} (hr : 0 < r) (hr1 : r ≤ 1) :
    IntegrableOn (fun x ↦ ballOscillation x r g) (ballSet 0 (1 + r)) := by
  have hmeas : AEStronglyMeasurable (fun x ↦ ballOscillation x r g)
      (volume.restrict (ballSet 0 (1 + r))) :=
    ((measurable_ballOscillation g hgmeas).comp
      (measurable_id.prodMk measurable_const)).aestronglyMeasurable
  refine ⟨hmeas, ?_⟩
  rw [hasFiniteIntegral_iff_ofReal]
  · exact lintegral_ballOscillation_lt_top g hgmeas hg hr hr1
  · filter_upwards [self_mem_ae_restrict (measurableSet_ballSet 0 (1 + r))] with x hx
    exact ballOscillation_nonneg x hr g

theorem ofReal_oscillationDensity_eq_lintegral {n m : ℕ}
    (g : (Fin n → ℝ) → Fin m → ℝ) (hgmeas : ∀ i, Measurable (fun y ↦ g y i))
    (hg : ∀ i, MemLp (fun y ↦ g y i) 2
      (volume.restrict (ballSet (0 : Fin n → ℝ) 8)))
    {r : ℝ} (hr : 0 < r) (hr1 : r ≤ 1) :
    ENNReal.ofReal (∫ x in ballSet (0 : Fin n → ℝ) (1 + r), ballOscillation x r g) =
      ∫⁻ x in ballSet (0 : Fin n → ℝ) (1 + r), ENNReal.ofReal (ballOscillation x r g) := by
  apply ofReal_integral_eq_lintegral_ofReal
  · exact integrableOn_ballOscillation_moving g hgmeas hg hr hr1
  · filter_upwards [self_mem_ae_restrict (measurableSet_ballSet 0 (1 + r))] with x hx
    exact ballOscillation_nonneg x hr g

theorem oscillationDensity_nonneg {n m : ℕ}
    (g : (Fin n → ℝ) → Fin m → ℝ) {r : ℝ} (hr : 0 < r) :
    0 ≤ ∫ x in ballSet (0 : Fin n → ℝ) (1 + r), ballOscillation x r g := by
  apply integral_nonneg_of_ae
  filter_upwards [self_mem_ae_restrict (measurableSet_ballSet 0 (1 + r))] with x _hx
  exact ballOscillation_nonneg x hr g

theorem lintegral_oscillationDensity_div_eq {n m : ℕ}
    (g : (Fin n → ℝ) → Fin m → ℝ) (hgmeas : ∀ i, Measurable (fun y ↦ g y i))
    (hg : ∀ i, MemLp (fun y ↦ g y i) 2
      (volume.restrict (ballSet (0 : Fin n → ℝ) 8)))
    {t : ℝ} (ht1 : t ≤ 1) :
    (∫⁻ r in Ioo (0 : ℝ) t, ENNReal.ofReal
      ((∫ x in ballSet (0 : Fin n → ℝ) (1 + r), ballOscillation x r g) / r)) =
      ∫⁻ r in Ioo (0 : ℝ) t,
        ∫⁻ x in ballSet (0 : Fin n → ℝ) (1 + r),
          ENNReal.ofReal (ballOscillation x r g / r) := by
  apply setLIntegral_congr_fun measurableSet_Ioo
  intro r hr
  have hr1 : r ≤ 1 := hr.2.le.trans ht1
  have hE := ofReal_oscillationDensity_eq_lintegral g hgmeas hg hr.1 hr1
  have hinv : 0 ≤ r⁻¹ := inv_nonneg.mpr hr.1.le
  calc
    ENNReal.ofReal ((∫ x in ballSet (0 : Fin n → ℝ) (1 + r), ballOscillation x r g) / r) =
        ENNReal.ofReal r⁻¹ * ENNReal.ofReal
          (∫ x in ballSet (0 : Fin n → ℝ) (1 + r), ballOscillation x r g) := by
      rw [div_eq_inv_mul, ENNReal.ofReal_mul hinv]
    _ = ENNReal.ofReal r⁻¹ *
        (∫⁻ x in ballSet (0 : Fin n → ℝ) (1 + r),
          ENNReal.ofReal (ballOscillation x r g)) := by rw [hE]
    _ = ∫⁻ x in ballSet (0 : Fin n → ℝ) (1 + r),
        ENNReal.ofReal r⁻¹ * ENNReal.ofReal (ballOscillation x r g) := by
      rw [lintegral_const_mul' _ _ ENNReal.ofReal_ne_top]
    _ = ∫⁻ x in ballSet (0 : Fin n → ℝ) (1 + r),
        ENNReal.ofReal (ballOscillation x r g / r) := by
      apply setLIntegral_congr_fun (measurableSet_ballSet 0 (1 + r))
      intro x hx
      change ENNReal.ofReal r⁻¹ * ENNReal.ofReal (ballOscillation x r g) =
        ENNReal.ofReal (ballOscillation x r g / r)
      rw [div_eq_mul_inv]
      rw [mul_comm]
      exact (ENNReal.ofReal_mul' hinv).symm

end AffineCarleson.Internal
