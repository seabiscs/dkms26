import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Tactic

/-!
# Continuous decay from geometric scales

An elementary interpolation estimate that extends decay known at the radii
`16⁻ᵏ` to every radius in `(0, 1]` by monotonicity.
-/

namespace AffineCarleson.Internal

/-- Decay on the geometric grid `16⁻ᵏ` implies decay at every radius in
`(0, 1]`, at the cost of one factor of `16 ^ γ`. -/
theorem continuous_decay_of_geometric
    (Φ : ℝ → ℝ) (A γ : ℝ) (hA : 0 ≤ A) (hγ : 0 < γ)
    (hmono : MonotoneOn Φ (Set.Ioc 0 1))
    (hgrid : ∀ k : ℕ,
      Φ (((16 : ℝ) ^ k)⁻¹) ≤ A * Real.rpow (((16 : ℝ) ^ k)⁻¹) γ) :
    ∀ r ∈ Set.Ioc (0 : ℝ) 1,
      Φ r ≤ Real.rpow 16 γ * A * Real.rpow r γ := by
  intro r hr
  obtain ⟨k, hkr, hrk⟩ := exists_nat_pow_near_of_lt_one hr.1 hr.2
    (by norm_num : (0 : ℝ) < 1 / 16) (by norm_num : (1 : ℝ) / 16 < 1)
  have hscale : (1 / 16 : ℝ) ^ k = ((16 : ℝ) ^ k)⁻¹ := by
    rw [div_pow]
    norm_num
  have hscale_pos : 0 < (1 / 16 : ℝ) ^ k := pow_pos (by norm_num) k
  have hscale_one : (1 / 16 : ℝ) ^ k ≤ 1 :=
    pow_le_one₀ (by norm_num) (by norm_num)
  have hΦ : Φ r ≤ Φ ((1 / 16 : ℝ) ^ k) :=
    hmono hr ⟨hscale_pos, hscale_one⟩ hrk
  have hnear : (1 / 16 : ℝ) ^ k ≤ 16 * r := by
    rw [show (1 / 16 : ℝ) ^ k = 16 * (1 / 16 : ℝ) ^ (k + 1) by
      rw [pow_succ]
      ring]
    exact mul_le_mul_of_nonneg_left hkr.le (by norm_num)
  have hrpow : Real.rpow ((1 / 16 : ℝ) ^ k) γ ≤ Real.rpow (16 * r) γ :=
    Real.rpow_le_rpow hscale_pos.le hnear hγ.le
  calc
    Φ r ≤ Φ ((1 / 16 : ℝ) ^ k) := hΦ
    _ ≤ A * Real.rpow ((1 / 16 : ℝ) ^ k) γ := by
      rw [hscale]
      exact hgrid k
    _ ≤ A * Real.rpow (16 * r) γ := mul_le_mul_of_nonneg_left hrpow hA
    _ = Real.rpow 16 γ * A * Real.rpow r γ := by
      change A * (16 * r) ^ γ = (16 : ℝ) ^ γ * A * r ^ γ
      rw [Real.mul_rpow (by norm_num : (0 : ℝ) ≤ 16) hr.1.le]
      ring

end AffineCarleson.Internal
