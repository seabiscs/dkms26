# Mean-oscillation self-improvement in Lean

This project proves the abstract self-improvement lemma and its zero-error corollary from the supplied section “An elementary improvement and the proof of Theorem maint.” It also includes the previously verified affine projection characterization.

**The final application to minimizers is not yet formalized.** It requires earlier Carleson, higher-integrability, and V estimates. The completed abstract theorem has exactly its approved source hypotheses; those missing PDE results are not additional assumptions of it.

## Public results

| Lean export | Result |
|---|---|
| `AffineCarleson.meanOscillation_selfImprovement` | Local fractional regularity and the quantitative ball estimate, with the exact source exponent and one uniform constant. |
| `AffineCarleson.meanOscillation_selfImprovement_zeroError` | The stronger zero-error range `0 < s < s₀`, with constant depending only on `n, K, s`. |
| `AffineCarleson.affine_projection_characterization` | The inherited affine projection characterization. |

Import `AffineCarleson` to use the complete library. The approved self-improvement statement is in [Frozen/SelfImprovement.lean](Frozen/SelfImprovement.lean); its proof is assembled in [Proof.lean](AffineCarleson/SelfImprovement/Proof.lean). The constant is chosen before the target dimension, domain, functions, error coefficient, center, and radius. Local fractional membership is expressed by finiteness of the Gagliardo integral on every compact subset.

The proof derives the tail contraction from the actual oscillation assumption, establishes the weighted moment, proves the fractional estimate by a direct local Tonelli/layer-cake argument, and proves the changes of variables and compact-set localization. It does not assume an external Littlewood–Paley characterization. See the [source-to-Lean coverage](audit/section4-coverage-closeout.md).

## Build and verify

Requires Python 3 and Lean/Lake through Elan. Versions are pinned to Lean 4.33.0 and Mathlib commit `db584cd6d46c92f209a44c0f1c829460d327499d`.

From the repository root:

```sh
lake exe cache get
lake build AffineCarleson
python3 scripts/verify.py
```

The verifier checks frozen statements and hashes, rejects unauthorized proof holes and imports, builds every project module without warnings, checks every project declaration's axiom closure, and replays every project module with Lean's kernel checker. Only the standard axioms `propext`, `Classical.choice`, and `Quot.sound` are permitted. It writes fresh results to `verification-output/`.

The recorded release results are in [STATUS.md](STATUS.md), [verification-summary.json](audit/verification-summary.json), and the [independent final statement audit](audit/final-statement-audit.md). Frozen statement identity and successful compilation are checked separately from mathematical source fidelity.

## Upload to GitHub

Unzip the release and upload the contents of the `self-improvement-lean` directory as the repository root, including `lean-toolchain`, both Lake configuration files, `Frozen/`, `AffineCarleson/`, and `scripts/`. Keep the manifests, source files, and audit reports for reproducibility. The archive excludes `.lake/` and local build artifacts; dependencies are restored by the cache command above. Do not run `lake update` when reproducing this pinned release.

The supplied source excerpt and reference transcription are included to reproduce the source dependency graph checks. No PDF or dependency checkout is included. The source graph records the manuscript's proof route; its source gaps and external citation remain visible even where this Lean proof supplies a direct alternative. Its planning statuses are not the project's proof-status ledger.

[proof-status.json](proof-status.json) records the implemented declarations and remaining scope. Historical approval files retain their original draft text for identity comparison; all current `.lean` files are free of proof holes. No GitHub repository has been created or published by this package.
