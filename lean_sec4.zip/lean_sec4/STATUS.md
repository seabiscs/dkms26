# Verification and completion status — 10 September 2026

**The approved abstract self-improvement lemma and its zero-error corollary are proved. The final application to minimizers is unproved.**

## Verified results

- `AffineCarleson.meanOscillation_selfImprovement`: the exact approved statement, including both local fractional regularity and the quantitative ball estimate, with the original constant dependence and exponent.
- `AffineCarleson.meanOscillation_selfImprovement_zeroError`: the stronger source corollary, using `σ=4s` inside the proof to obtain every `0<s<s₀` and a constant depending only on `n,K,s`.
- `AffineCarleson.affine_projection_characterization`: the inherited theorem, with unchanged elaborated type.

The frozen self-improvement statement changed only in its proof body. Its elaborated-type SHA-256 remains `d674c7a7c39e732be5b485fd2f30c7b0b6de0be5b33c17b71616a2a5d9ac0086`. The final canonical file SHA-256 is `49f91cefbde8960bc6d79fdfcd9e98787dac3326831011916ae2e89bb8c66c46`.

## Mechanical verification

`python3 scripts/verify.py` passed on the delivered Lean sources:

- **61 project modules** compiled without warnings.
- **409 declarations**, including generated declarations, passed the recursive axiom census.
- Every project module passed Lean kernel replay.
- All current Lean sources are free of `sorry`, `admit`, custom axioms, `unsafe`, `native_decide`, and proof-budget overrides.
- Frozen identity, exact ABI, import coverage, manifest ownership, and five negative regression cases passed.
- The pinned Mathlib checkout has no tracked-source changes. No upstream library was rebuilt for this verification.

The only allowed axioms are `propext`, `Classical.choice`, and `Quot.sound`. The [verification summary](audit/verification-summary.json) binds every checked Lean source to its SHA-256 hash. Logs and the complete declaration census are in `audit/verification-*.log` and `audit/verification-axioms.tsv`.

The new section development contains 136 explicit theorems and 5 definitions, including the internal provider and helpers. These counts refer to their actual Lean types; a helper with explicit intermediate hypotheses does not itself certify a source theorem. The final public root discharges all proof obligations from its approved source assumptions.

## Independent review and source coverage

The [final statement audit](audit/final-statement-audit.md) separately passed source fidelity, binder classification, constant scope, canonical proof-body identity, predecessor consumption, and axiom closure for the abstract root and zero-error corollary. The [coverage map](audit/section4-coverage-closeout.md) explains the complete proof route, including rescaling and control of cross-ball pairs on compact sets.

The implementation proves the local fractional estimate directly by Tonelli and a kernel layer-cake argument. It does not import the external Littlewood–Paley theorem cited in the manuscript. The source-only dependency graph retains that citation and the manuscript's five omitted proof details for provenance; they are not hidden Lean assumptions. Both strict graph publication checks passed after the final manifest binding was refreshed.

Earlier audit files and the approved draft command are historical evidence. They may display the formerly registered placeholder, but there are **no draft Lean anchors** in the release.

## Remaining section content

The final application in `source/self-improvement.tex` lines 246–267 needs earlier relative Carleson and higher-integrability results, the V estimates and exponent definitions, and their assembly into the minimizer theorem. These have not been formalized here. The internal `fractionalEnergy_le_of_pointwise` comparison proves an implication; its required pointwise V estimate remains to be established for that application.

## Campaign counters

| Counter | Value |
|---|---|
| DRAFT_ANCHORS | 0 |
| UNREGISTERED_SORRIES | 0 |
| DRAFT_IMPORT_VIOLATIONS | 0 |
| SEALED_THIS_TURN | 1 — `AffineCarleson.meanOscillation_selfImprovement` |
| PROVED_ANCHORS | 2, including the inherited affine theorem |

The zero-error corollary is an ordinary derived public theorem, not a separate frozen anchor. [proof-status.json](proof-status.json) contains the complete explicit new-declaration inventory.
