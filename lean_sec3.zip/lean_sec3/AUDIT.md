# Verification and independent review — 2026-09-10

**PASS for the affine-projection characterization and its supporting code.**
This verdict does not extend to the unformalized Dorronsoro, Caccioppoli, or
Carleson estimates.

## Evidence

| Check | Result |
|---|---|
| Fresh compilation of every project source file | 14 modules; PASS; no warnings |
| Exact application at the retained approved theorem type | PASS |
| Elaborated type SHA-256 matches the approved identity | PASS |
| Axiom census of all project declarations in the imported environment | 154 declarations; PASS |
| Kernel replay of all project modules | 14 modules; PASS |
| Proof-hole, custom-axiom, unsafe-code, and budget-override scan | Zero occurrences in Lean code |
| Fresh independent source correspondence audit | PASS; no excess premise |
| Fresh independent review of all 14 Lean files | PASS; no unresolved mathematical finding |

The fresh build started in a new directory without any project build
artifacts. Existing artifacts for the pinned upstream dependencies were reused;
this was not a rebuild of mathlib from source. The local platform was macOS
ARM64 with Lean 4.33.0. A fresh network download and a hosted Linux/GitHub run
have not been performed as part of this audit.

Recorded machine evidence:

- [Fresh project build](audit/clean-build.log)
- [Axiom census](audit/axioms.tsv)
- [Kernel replay log](audit/kernel-replay.log)
- [Verification summary](audit/summary.json)
- [Verifier negative checks](audit/verifier-negative-checks.txt)
- [Lean source file hashes](audit/lean-source-sha256.json)
- [Exact retained statement](audit/approved-statement.txt)

The only axioms allowed by the verifier are `propext`, `Classical.choice`, and
`Quot.sound`. The kernel replay checks declarations again with Lean's kernel;
it is not a proof of correctness of Lean itself or an external kernel
implementation. Source correspondence is a mathematical review, separate
from kernel acceptance.

## Source and binder review

Two separate agent reviewers, independent of the implementation pass,
reconstructed the source theorem independently of the existing approval report, checked the Euclidean ball and error, normalization, tensor
orientation, and quantifier order, and tried to refute the uniqueness and
orthogonality claims. These were automated independent reviews, not external
peer review.

| Binder | Classification | Source justification |
|---|---|---|
| `n : ℕ` | SOURCE | Input dimension |
| `N : ℕ` | SOURCE | Output dimension |
| `hn : 2 ≤ n` | STANDING | Paper p. 1 |
| `hN : 2 ≤ N` | STANDING | Paper p. 1 |
| `x : Fin n → ℝ` | SOURCE | Center of the ball |
| `ρ : ℝ` | SOURCE | Radius of the ball |
| `hρ : 0 < ρ` | SOURCE | Positive-radius convention |
| `v` | SOURCE | Vector-valued input function |
| `hv` | SOURCE | Finite-coordinate realization of L² membership |

Counts: SOURCE 7; STANDING 2; TYPING 0; RULED 0; EXCESS 0. The type contains
no project-defined bundled assumption hiding extra premises. The comparisons
with arbitrary affine coefficients occur in the conclusion.

The proof review covered all files, including ball integrability, reflections
and permutations, radial integration, the measure-preserving Euclidean
transport, scalar L² least squares, and vector-valued assembly. At the final
provider boundary, all three internal moment premises are supplied by proved
terms. No conditional helper is substituted for the source theorem.

## Findings and dispositions

No mathematical correction was needed. The release audit did identify
packaging issues in the earlier working bundle: mixed historical proposal
records, machine-specific build/cache material in the working directory, and
the full extracted reference paper. The clean release excludes those items.

The source-facing Lean file had two stale sentences from the original
approval stage. Only those docstring sentences were updated. An independent
comparison verified that its imports, theorem statement, and proof are
unchanged; the other 13 Lean files are identical to the previously audited
source. The release frozen-file SHA-256 is
`b0c3fdfe288cdc86bba82d5836c751560b419ba58fb4301680fa044bee67c6dc`.

The original sealing step added the proof-provider import needed to attach
the completed proof. That implementation import addition is documented in
`verification-manifest.json`; it is not represented as an unchanged whole
file. The approved elaborated theorem type is unchanged:

```text
5df18b37c7e7a95b01414f55342b67f8de6a48404473cb5f51a79ef62dfb8fea
```

## Limits and status

The theorem is a characterization of coefficients and affine expressions.
There is no separately exported projection-operator definition in this
release. The later Lq and PDE estimates remain open, as detailed in
[SOURCE.md](SOURCE.md). The uploaded reference version is identified by hashes;
no claim is made about other versions of the paper.

```text
DRAFT_ANCHORS: 0
UNREGISTERED_SORRIES: 0
DRAFT_IMPORT_VIOLATIONS: 0
SEALED_THIS_TURN: 0 — existing proved theorem reverified
```
