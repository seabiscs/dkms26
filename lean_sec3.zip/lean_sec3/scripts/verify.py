#!/usr/bin/env python3
"""Build, check the approved type, census all project axioms, and replay the kernel."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def run(args):
    result = subprocess.run(args, cwd=ROOT, text=True, capture_output=True,
                            env={**os.environ, "LEAN_NUM_THREADS": "2"})
    output = result.stdout + result.stderr
    require(result.returncode == 0, f"Command failed: {' '.join(args)}\n{output}")
    require(not re.search(r"\bwarning:", output), f"Compiler warning:\n{output}")
    return output


def strip_comments(text):
    depth, i, out = 0, 0, []
    while i < len(text):
        pair = text[i:i + 2]
        if pair == "/-":
            depth += 1
            i += 2
        elif depth and pair == "-/":
            depth -= 1
            i += 2
        elif depth:
            i += 1
        elif pair == "--":
            i = text.find("\n", i)
            if i == -1:
                break
        else:
            out.append(text[i])
            i += 1
    require(depth == 0, "Unclosed block comment")
    return "".join(out)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-directory", type=Path,
                        default=ROOT / "verification-output")
    args = parser.parse_args()
    output_dir = args.output_directory.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    # A failed rerun must not leave an earlier PASS result looking current.
    (output_dir / "summary.json").unlink(missing_ok=True)
    manifest = json.loads((ROOT / "verification-manifest.json").read_text())
    anchor = manifest["anchor"]
    require(anchor["state"] == "PROVED", "Anchor is not marked proved")
    statement_path = ROOT / anchor["approved_statement_path"]
    statement = statement_path.read_text().rstrip("\n")
    require(sha(statement_path.read_bytes()) == anchor["approved_statement_sha256"],
            "Approved statement text changed")
    frozen = (ROOT / anchor["path"]).read_text()
    require(sha(frozen.encode()) == anchor["release_file_sha256"],
            "Frozen release file changed")
    actual_statement = frozen[frozen.index("theorem affine_projection_characterization"):
                              frozen.rindex(" := by")]
    require(actual_statement == statement, "Public theorem statement changed")
    require((ROOT / "lean-toolchain").read_text().strip() == manifest["toolchain"],
            "Toolchain pin changed")
    lock = json.loads((ROOT / "lake-manifest.json").read_text())
    locked_mathlib = next(p for p in lock["packages"] if p["name"] == "mathlib")
    require(locked_mathlib["rev"] == manifest["mathlib_revision"], "Mathlib lock changed")
    mathlib = ROOT / ".lake/packages/mathlib"
    require(mathlib.exists(), "Fetch the pinned dependencies with: lake exe cache get")
    require(run(["git", "-C", str(mathlib), "rev-parse", "HEAD"]).strip() ==
            manifest["mathlib_revision"], "Mathlib checkout differs from the pin")
    require(not run(["git", "-C", str(mathlib), "status", "--porcelain=v1",
                     "--untracked-files=no"]).strip(), "Mathlib tracked sources are modified")
    files = sorted((ROOT / "AffineCarleson").rglob("*.lean"))
    files += sorted((ROOT / "Frozen").rglob("*.lean"))
    files += [ROOT / "AffineCarleson.lean"]
    modules = {p.relative_to(ROOT).with_suffix("").as_posix().replace("/", ".")
               for p in files}
    for path in files:
        code = strip_comments(path.read_text())
        require(not re.search(r"\b(sorry|admit|axiom|sorryAx|unsafe|native_decide)\b", code),
                f"Forbidden proof/trust marker in {path.relative_to(ROOT)}")
        require(not re.search(r"set_option\s+.*(?:maxHeartbeats|maxRecDepth)", code),
                f"Budget override in {path.relative_to(ROOT)}")
        if path.is_relative_to(ROOT / "AffineCarleson"):
            require(not re.search(r"^import Frozen\b", code, re.M),
                    "A proof provider imports its frozen theorem")

    print("Building all project modules...", flush=True)
    build = run(["lake", "build", "AffineCarleson"])
    (output_dir / "build.log").write_text(build)
    example = statement.replace("theorem affine_projection_characterization", "example", 1)
    probe = """import AffineCarleson
noncomputable section
set_option autoImplicit false
open MeasureTheory
""" + example + """ := by
  exact AffineCarleson.affine_projection_characterization n N hn hN x ρ hρ v hv

run_cmd do
  let ci ← Lean.getConstInfo `AffineCarleson.affine_projection_characterization
  Lean.logInfo s!"ELABORATED_TYPE_BEGIN\\n{repr ci.type}\\nELABORATED_TYPE_END"

run_cmd do
  let env ← Lean.getEnv
  for mod in env.header.moduleNames do
    if (`AffineCarleson).isPrefixOf mod || (`Frozen).isPrefixOf mod then
      Lean.logInfo s!"PROJECT_MODULE|{mod}"
  for (name, _) in env.constants do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.header.moduleNames[idx.toNat]!
      if (`AffineCarleson).isPrefixOf mod || (`Frozen).isPrefixOf mod then
        let axioms ← Lean.collectAxioms name
        for ax in axioms do
          unless ax == `propext || ax == `Classical.choice || ax == `Quot.sound do
            throwError "Unapproved axiom {ax} in {name}"
        Lean.logInfo s!"AXIOM_CENSUS|{mod}|{name}|{axioms.toList}"
"""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".lean", prefix="ReleaseAudit",
                                     dir=ROOT, encoding="utf-8", delete=False) as f:
        f.write(probe)
        temporary = Path(f.name)
    try:
        print("Checking the exact type and every project declaration's axioms...", flush=True)
        audit = run(["lake", "env", "lean", str(temporary)])
    finally:
        temporary.unlink(missing_ok=True)
    raw_type = audit.split("ELABORATED_TYPE_BEGIN\n", 1)[1].split("\nELABORATED_TYPE_END", 1)[0]
    require(sha(raw_type.encode()) == anchor["elaborated_type_sha256"],
            "Elaborated theorem type differs from the approved type")
    imported_modules = set(re.findall(r"^PROJECT_MODULE\|(.+)$", audit, re.M))
    require(imported_modules == modules,
            f"Main import/source inventory mismatch: {imported_modules ^ modules}")
    census = re.findall(r"^AXIOM_CENSUS\|(.+)$", audit, re.M)
    require(any(f"|{anchor['export']}|" in line for line in census),
            "Frozen theorem missing from axiom census")
    (output_dir / "axioms.tsv").write_text("module|declaration|axioms\n" +
                                          "\n".join(sorted(census)) + "\n")
    print("Replaying every project module with Lean's kernel checker...", flush=True)
    replay = run(["lake", "env", "leanchecker", "--verbose", "AffineCarleson", "Frozen"])
    (output_dir / "kernel-replay.log").write_text(replay)
    replayed = set(re.findall(r"^replaying (.+)$", replay, re.M))
    require(replayed == modules, f"Kernel replay/module inventory mismatch: {replayed ^ modules}")
    summary = {
        "result": "PASS",
        "project_modules": len(modules),
        "project_declarations_checked": len(census),
        "exact_approved_type": "PASS",
        "elaborated_type_sha256": anchor["elaborated_type_sha256"],
        "axiom_allowlist": ["propext", "Classical.choice", "Quot.sound"],
        "proof_holes_custom_axioms_unsafe_or_budget_overrides": 0,
        "kernel_replay": "PASS",
        "compiler_warnings": 0,
        "toolchain": manifest["toolchain"],
        "mathlib_revision": manifest["mathlib_revision"],
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
