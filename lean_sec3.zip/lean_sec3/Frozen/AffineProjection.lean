import AffineCarleson.ProjectionProof
import Mathlib.MeasureTheory.Function.LpSeminorm.Basic
import Mathlib.MeasureTheory.Integral.Bochner.Basic
import Mathlib.MeasureTheory.Integral.Bochner.Set
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.LinearAlgebra.Matrix.Defs

noncomputable section
set_option autoImplicit false
open MeasureTheory

namespace AffineCarleson

/-- The unique affine L² approximation on a Euclidean ball, together with
the explicit coefficient formula in (pro), PDF (2.4).

`Fin n → ℝ` is only the coordinate carrier. The ball and all squared errors
below use sums of squares, hence exactly the Euclidean norm. L² membership
is stated coordinatewise and does not use a sup-norm approximation error.

The coefficient formula, well-definedness, and unique orthogonal projection
are proved from the displayed L² hypothesis by the imported proof provider.
-/
theorem affine_projection_characterization
    (n N : ℕ) (hn : 2 ≤ n) (hN : 2 ≤ N)
    (x : Fin n → ℝ) (ρ : ℝ) (hρ : 0 < ρ)
    (v : (Fin n → ℝ) → Fin N → ℝ)
    (hv : ∀ α : Fin N, MemLp (fun y => v y α) 2
      (volume.restrict {y : Fin n → ℝ | ∑ i, (y i - x i) ^ 2 < ρ ^ 2})) :
    let B : Set (Fin n → ℝ) :=
      {y | ∑ i, (y i - x i) ^ 2 < ρ ^ 2}
    let mass : ℝ := (volume B).toReal
    let m : Fin N → ℝ := fun α => mass⁻¹ * ∫ y in B, v y α
    let Q : Matrix (Fin N) (Fin n) ℝ := fun α i =>
      ((n : ℝ) + 2) / ρ ^ 2 *
        (mass⁻¹ * ∫ y in B, v y α * (y i - x i))
    let affine : (Fin N → ℝ) → Matrix (Fin N) (Fin n) ℝ →
        (Fin n → ℝ) → Fin N → ℝ :=
      fun b A y α => b α + ∑ i, A α i * (y i - x i)
    let error : (Fin N → ℝ) → Matrix (Fin N) (Fin n) ℝ → ℝ :=
      fun b A => ∫ y in B, ∑ α, (v y α - affine b A y α) ^ 2
    (0 < mass) ∧
    (∀ α : Fin N, IntegrableOn (fun y => v y α) B) ∧
    (∀ (α : Fin N) (i : Fin n),
      IntegrableOn (fun y => v y α * (y i - x i)) B) ∧
    (∀ (b : Fin N → ℝ) (A : Matrix (Fin N) (Fin n) ℝ),
      IntegrableOn (fun y => ∑ α, (v y α - affine b A y α) ^ 2) B) ∧
    (∃! θ : (Fin N → ℝ) × Matrix (Fin N) (Fin n) ℝ,
      ∀ (b : Fin N → ℝ) (A : Matrix (Fin N) (Fin n) ℝ),
        error θ.1 θ.2 ≤ error b A) ∧
    (∀ (b : Fin N → ℝ) (A : Matrix (Fin N) (Fin n) ℝ),
      IntegrableOn
        (fun y => ∑ α, (v y α - affine m Q y α) * affine b A y α) B ∧
      (∫ y in B, ∑ α, (v y α - affine m Q y α) * affine b A y α) = 0) ∧
    (∀ (b : Fin N → ℝ) (A : Matrix (Fin N) (Fin n) ℝ),
      error m Q ≤ error b A) ∧
    (∀ (b : Fin N → ℝ) (A : Matrix (Fin N) (Fin n) ℝ),
      error b A = error m Q ↔ b = m ∧ A = Q) := by
  exact AffineCarleson.Internal.affine_projection_characterization n N hn hN x ρ hρ v hv

end AffineCarleson
