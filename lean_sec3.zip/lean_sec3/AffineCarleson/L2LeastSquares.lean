import AffineCarleson.LeastSquares
import Mathlib.MeasureTheory.Function.L2Space

/-! Concrete scalar L² integrals for the finite orthogonal least-squares lemmas.
No ball-moment or source theorem is assumed here. -/

noncomputable section
set_option autoImplicit false
open MeasureTheory
open scoped BigOperators

namespace AffineCarleson.Internal

variable {α ι : Type*} [MeasurableSpace α] {μ : Measure α} [Fintype ι]

theorem inner_toLp_eq_integral_mul {f g : α → ℝ} (hf : MemLp f 2 μ) (hg : MemLp g 2 μ) :
    inner ℝ (hf.toLp f) (hg.toLp g) = ∫ y, f y * g y ∂μ := by
  change (∫ y, inner ℝ ((hf.toLp f) y) ((hg.toLp g) y) ∂μ) = _
  apply integral_congr_ae
  filter_upwards [hf.coeFn_toLp, hg.coeFn_toLp] with y hfy hgy
  rw [hfy, hgy]
  simp only [RCLike.inner_apply, conj_trivial, mul_comm]

theorem norm_toLp_sq_eq_integral_sq {f : α → ℝ} (hf : MemLp f 2 μ) :
    ‖hf.toLp f‖ ^ 2 = ∫ y, f y ^ 2 ∂μ := by
  rw [← real_inner_self_eq_norm_sq, inner_toLp_eq_integral_mul]
  simp only [pow_two]

theorem memLp_finite_sum_mul (w : ι → α → ℝ) (hw : ∀ i, MemLp (w i) 2 μ)
    (c : ι → ℝ) : MemLp (fun y => ∑ i, c i * w i y) 2 μ := by
  exact memLp_finsetSum Finset.univ (fun i _ => (hw i).const_mul (c i))

theorem toLp_finite_sum_mul (w : ι → α → ℝ) (hw : ∀ i, MemLp (w i) 2 μ)
    (c : ι → ℝ) :
    (memLp_finite_sum_mul w hw c).toLp (fun y => ∑ i, c i * w i y) =
      finiteFit (fun i => (hw i).toLp (w i)) c := by
  apply Lp.ext
  have hsum : (fun y => (finiteFit (fun i => (hw i).toLp (w i)) c) y) =ᵐ[μ]
      fun y => ∑ i, c i * w i y := by
    unfold finiteFit
    filter_upwards [Lp.coeFn_fun_finsetSum Finset.univ (fun i => c i • (hw i).toLp (w i)),
      ae_all_iff.mpr (fun i : ι => Lp.coeFn_smul (c i) ((hw i).toLp (w i))),
      ae_all_iff.mpr (fun i : ι => (hw i).coeFn_toLp)] with y hsum hsmul hw'
    rw [hsum]
    apply Finset.sum_congr rfl
    intro i _
    rw [hsmul i]
    change c i * ((hw i).toLp (w i)) y = c i * w i y
    rw [hw' i]
  exact (memLp_finite_sum_mul w hw c).coeFn_toLp.trans hsum.symm

theorem norm_toLp_sub_sq_eq_integral_sq {f g : α → ℝ}
    (hf : MemLp f 2 μ) (hg : MemLp g 2 μ) :
    ‖hf.toLp f - hg.toLp g‖ ^ 2 = ∫ y, (f y - g y) ^ 2 ∂μ := by
  rw [← MemLp.toLp_sub hf hg]
  exact norm_toLp_sq_eq_integral_sq (hf.sub hg)

theorem toLp_ne_zero_of_integral_sq_pos {f : α → ℝ} (hf : MemLp f 2 μ)
    (hpos : 0 < ∫ y, f y ^ 2 ∂μ) : hf.toLp f ≠ 0 := by
  intro h
  have he := norm_toLp_sq_eq_integral_sq hf
  rw [h, norm_zero, zero_pow (by omega : 2 ≠ 0)] at he
  exact hpos.ne' he.symm

omit [Fintype ι] in
theorem leastSquaresCoeff_toLp (w : ι → α → ℝ) (hw : ∀ i, MemLp (w i) 2 μ)
    {f : α → ℝ} (hf : MemLp f 2 μ) :
    leastSquaresCoeff (fun i => (hw i).toLp (w i)) (hf.toLp f) =
      fun i => (∫ y, w i y * f y ∂μ) / (∫ y, w i y ^ 2 ∂μ) := by
  funext i
  exact congrArg₂ (fun a b : ℝ => a / b)
    (inner_toLp_eq_integral_mul (hw i) hf) (norm_toLp_sq_eq_integral_sq (hw i))

theorem l2_leastSquares_orthogonal (w : ι → α → ℝ) (hw : ∀ i, MemLp (w i) 2 μ)
    {f : α → ℝ} (hf : MemLp f 2 μ)
    (horth : ∀ i j, i ≠ j → (∫ y, w i y * w j y ∂μ) = 0)
    (hpos : ∀ i, 0 < ∫ y, w i y ^ 2 ∂μ) (c : ι → ℝ) :
    let coeff : ι → ℝ := fun i => (∫ y, w i y * f y ∂μ) / (∫ y, w i y ^ 2 ∂μ)
    (∫ y, (f y - ∑ i, coeff i * w i y) * (∑ i, c i * w i y) ∂μ) = 0 := by
  let W : ι → Lp ℝ 2 μ := fun i => (hw i).toLp (w i)
  have ho : ∀ i j, i ≠ j → inner ℝ (W i) (W j) = 0 := by
    intro i j hij
    exact (inner_toLp_eq_integral_mul (hw i) (hw j)).trans (horth i j hij)
  have hn : ∀ i, W i ≠ 0 := fun i => toLp_ne_zero_of_integral_sq_pos (hw i) (hpos i)
  have h := inner_residual_finiteFit W (hf.toLp f) c ho hn
  rw [leastSquaresCoeff_toLp w hw hf] at h
  rw [← toLp_finite_sum_mul w hw _, ← toLp_finite_sum_mul w hw c,
    ← MemLp.toLp_sub, inner_toLp_eq_integral_mul] at h
  exact h

theorem l2_leastSquares_eq_iff (w : ι → α → ℝ) (hw : ∀ i, MemLp (w i) 2 μ)
    {f : α → ℝ} (hf : MemLp f 2 μ)
    (horth : ∀ i j, i ≠ j → (∫ y, w i y * w j y ∂μ) = 0)
    (hpos : ∀ i, 0 < ∫ y, w i y ^ 2 ∂μ) (c : ι → ℝ) :
    let coeff : ι → ℝ := fun i => (∫ y, w i y * f y ∂μ) / (∫ y, w i y ^ 2 ∂μ)
    (∫ y, (f y - ∑ i, c i * w i y) ^ 2 ∂μ) =
      (∫ y, (f y - ∑ i, coeff i * w i y) ^ 2 ∂μ) ↔ c = coeff := by
  let W : ι → Lp ℝ 2 μ := fun i => (hw i).toLp (w i)
  have ho : ∀ i j, i ≠ j → inner ℝ (W i) (W j) = 0 := by
    intro i j hij
    exact (inner_toLp_eq_integral_mul (hw i) (hw j)).trans (horth i j hij)
  have hn : ∀ i, W i ≠ 0 := fun i => toLp_ne_zero_of_integral_sq_pos (hw i) (hpos i)
  have h := leastSquares_eq_iff W (hf.toLp f) ho hn c
  rw [leastSquaresCoeff_toLp w hw hf] at h
  rw [← toLp_finite_sum_mul w hw c, ← toLp_finite_sum_mul w hw _,
    norm_toLp_sub_sq_eq_integral_sq, norm_toLp_sub_sq_eq_integral_sq] at h
  exact h

theorem l2_leastSquares_minimizes (w : ι → α → ℝ) (hw : ∀ i, MemLp (w i) 2 μ)
    {f : α → ℝ} (hf : MemLp f 2 μ)
    (horth : ∀ i j, i ≠ j → (∫ y, w i y * w j y ∂μ) = 0)
    (hpos : ∀ i, 0 < ∫ y, w i y ^ 2 ∂μ) (c : ι → ℝ) :
    let coeff : ι → ℝ := fun i => (∫ y, w i y * f y ∂μ) / (∫ y, w i y ^ 2 ∂μ)
    (∫ y, (f y - ∑ i, coeff i * w i y) ^ 2 ∂μ) ≤
      ∫ y, (f y - ∑ i, c i * w i y) ^ 2 ∂μ := by
  let W : ι → Lp ℝ 2 μ := fun i => (hw i).toLp (w i)
  have horthW : ∀ i j, i ≠ j → inner ℝ (W i) (W j) = 0 := by
    intro i j hij
    exact (inner_toLp_eq_integral_mul (hw i) (hw j)).trans (horth i j hij)
  have hnonzero : ∀ i, W i ≠ 0 := by
    intro i hi
    have he := norm_toLp_sq_eq_integral_sq (hw i)
    change ‖W i‖ ^ 2 = _ at he
    rw [hi, norm_zero, zero_pow (by omega : 2 ≠ 0)] at he
    exact (hpos i).ne' he.symm
  have hc : leastSquaresCoeff W (hf.toLp f) =
      fun i => (∫ y, w i y * f y ∂μ) / (∫ y, w i y ^ 2 ∂μ) := by
    funext i
    exact congrArg₂ (fun a b : ℝ => a / b)
      (inner_toLp_eq_integral_mul (hw i) hf) (norm_toLp_sq_eq_integral_sq (hw i))
  have h := leastSquares_minimizes W (hf.toLp f) horthW hnonzero c
  rw [hc] at h
  rw [← toLp_finite_sum_mul w hw _, ← toLp_finite_sum_mul w hw c,
    norm_toLp_sub_sq_eq_integral_sq, norm_toLp_sub_sq_eq_integral_sq] at h
  exact h

end AffineCarleson.Internal
