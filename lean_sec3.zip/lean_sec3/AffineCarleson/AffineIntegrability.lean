import AffineCarleson.BallGeometry
import Mathlib.MeasureTheory.Function.L2Space

noncomputable section
set_option autoImplicit false

open MeasureTheory

namespace AffineCarleson.Internal

/-- The literal affine expression occurring in the frozen source theorem. -/
def affineValue {n N : ℕ} (b : Fin N → ℝ) (A : Matrix (Fin N) (Fin n) ℝ)
    (x y : Fin n → ℝ) (α : Fin N) : ℝ :=
  b α + ∑ i, A α i * (y i - x i)

theorem component_integrableOn_ballSet {n N : ℕ} (x : Fin n → ℝ) {ρ : ℝ}
    (hρ : 0 < ρ) (v : (Fin n → ℝ) → Fin N → ℝ)
    (hv : ∀ α, MemLp (fun y ↦ v y α) 2 (volume.restrict (ballSet x ρ)))
    (α : Fin N) : IntegrableOn (fun y ↦ v y α) (ballSet x ρ) := by
  change Integrable (fun y ↦ v y α) (volume.restrict (ballSet x ρ))
  let _ : IsFiniteMeasure (volume.restrict (ballSet x ρ)) :=
    isFiniteMeasure_restrict.mpr (volume_ballSet_ne_top x hρ)
  have hone : MemLp (fun _ : Fin n → ℝ ↦ (1 : ℝ)) 2
      (volume.restrict (ballSet x ρ)) := memLp_const 1
  convert (hv α).integrable_mul hone using 1
  ext y
  simp

theorem component_moment_integrableOn_ballSet {n N : ℕ} (x : Fin n → ℝ) {ρ : ℝ}
    (hρ : 0 < ρ) (v : (Fin n → ℝ) → Fin N → ℝ)
    (hv : ∀ α, MemLp (fun y ↦ v y α) 2 (volume.restrict (ballSet x ρ)))
    (α : Fin N) (i : Fin n) :
    IntegrableOn (fun y ↦ v y α * (y i - x i)) (ballSet x ρ) := by
  change Integrable (fun y ↦ v y α * (y i - x i)) (volume.restrict (ballSet x ρ))
  convert (hv α).integrable_mul (coordinate_sub_memLp_ballSet x hρ i 2) using 1
  ext y
  rfl

theorem affineValue_memLp_ballSet {n N : ℕ} (x : Fin n → ℝ) {ρ : ℝ}
    (hρ : 0 < ρ) (b : Fin N → ℝ) (A : Matrix (Fin N) (Fin n) ℝ)
    (α : Fin N) :
    MemLp (fun y ↦ affineValue b A x y α) 2 (volume.restrict (ballSet x ρ)) := by
  let _ : IsFiniteMeasure (volume.restrict (ballSet x ρ)) :=
    isFiniteMeasure_restrict.mpr (volume_ballSet_ne_top x hρ)
  have hb : MemLp (fun _ : Fin n → ℝ ↦ b α) 2
      (volume.restrict (ballSet x ρ)) := memLp_const (b α)
  have hsum : MemLp (fun y : Fin n → ℝ ↦ ∑ i, A α i * (y i - x i)) 2
      (volume.restrict (ballSet x ρ)) := by
    exact memLp_finsetSum _ fun i _ ↦ (coordinate_sub_memLp_ballSet x hρ i 2).const_mul (A α i)
  exact hb.add hsum

theorem residual_memLp_ballSet {n N : ℕ} (x : Fin n → ℝ) {ρ : ℝ}
    (hρ : 0 < ρ) (v : (Fin n → ℝ) → Fin N → ℝ)
    (hv : ∀ α, MemLp (fun y ↦ v y α) 2 (volume.restrict (ballSet x ρ)))
    (b : Fin N → ℝ) (A : Matrix (Fin N) (Fin n) ℝ) (α : Fin N) :
    MemLp (fun y ↦ v y α - affineValue b A x y α) 2
      (volume.restrict (ballSet x ρ)) :=
  (hv α).sub (affineValue_memLp_ballSet x hρ b A α)

theorem squaredResidualSum_integrableOn_ballSet {n N : ℕ} (x : Fin n → ℝ) {ρ : ℝ}
    (hρ : 0 < ρ) (v : (Fin n → ℝ) → Fin N → ℝ)
    (hv : ∀ α, MemLp (fun y ↦ v y α) 2 (volume.restrict (ballSet x ρ)))
    (b : Fin N → ℝ) (A : Matrix (Fin N) (Fin n) ℝ) :
    IntegrableOn (fun y ↦ ∑ α, (v y α - affineValue b A x y α) ^ 2)
      (ballSet x ρ) := by
  exact integrable_finsetSum _ fun α _ ↦ (residual_memLp_ballSet x hρ v hv b A α).integrable_sq

theorem residualAffinePairing_integrableOn_ballSet {n N : ℕ} (x : Fin n → ℝ) {ρ : ℝ}
    (hρ : 0 < ρ) (v : (Fin n → ℝ) → Fin N → ℝ)
    (hv : ∀ α, MemLp (fun y ↦ v y α) 2 (volume.restrict (ballSet x ρ)))
    (b A_b : Fin N → ℝ) (A A_A : Matrix (Fin N) (Fin n) ℝ) :
    IntegrableOn (fun y ↦ ∑ α,
      (v y α - affineValue b A x y α) * affineValue A_b A_A x y α) (ballSet x ρ) := by
  exact integrable_finsetSum _ fun α _ ↦
    (residual_memLp_ballSet x hρ v hv b A α).integrable_mul
      (affineValue_memLp_ballSet x hρ A_b A_A α)

end AffineCarleson.Internal
