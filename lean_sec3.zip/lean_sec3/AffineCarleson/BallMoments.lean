import AffineCarleson.BallGeometry
import Mathlib.MeasureTheory.Constructions.HaarToSphere
import Mathlib.MeasureTheory.Integral.Pi

noncomputable section
set_option autoImplicit false

open MeasureTheory

namespace AffineCarleson.Internal

/-- Reflection in the coordinate hyperplane through `x` normal to coordinate `k`. -/
def reflectCoord {n : ℕ} (x : Fin n → ℝ) (k : Fin n) (y : Fin n → ℝ) : Fin n → ℝ :=
  fun i ↦ if i = k then 2 * x i - y i else y i

@[simp]
theorem reflectCoord_apply_same {n : ℕ} (x : Fin n → ℝ) (k : Fin n) (y : Fin n → ℝ) :
    reflectCoord x k y k = 2 * x k - y k := by
  simp [reflectCoord]

theorem reflectCoord_apply_of_ne {n : ℕ} (x : Fin n → ℝ) {i k : Fin n} (hik : i ≠ k)
    (y : Fin n → ℝ) : reflectCoord x k y i = y i := by
  simp [reflectCoord, hik]

@[simp]
theorem reflectCoord_involutive {n : ℕ} (x : Fin n → ℝ) (k : Fin n) :
    Function.Involutive (reflectCoord x k) := by
  intro y
  funext i
  by_cases hik : i = k
  · subst i
    simp [reflectCoord]
  · simp [reflectCoord, hik]

/-- Coordinate reflection as a measurable equivalence, for set-integral transport. -/
def reflectCoordMeasurableEquiv {n : ℕ} (x : Fin n → ℝ) (k : Fin n) :
    (Fin n → ℝ) ≃ᵐ (Fin n → ℝ) where
  toEquiv :=
    { toFun := reflectCoord x k
      invFun := reflectCoord x k
      left_inv := reflectCoord_involutive x k
      right_inv := reflectCoord_involutive x k }
  measurable_toFun := by
    change Measurable (reflectCoord x k)
    refine measurable_pi_lambda _ fun i ↦ ?_
    by_cases hik : i = k
    · simp only [reflectCoord, hik, ↓reduceIte]
      fun_prop
    · simp only [reflectCoord, hik, ↓reduceIte]
      fun_prop
  measurable_invFun := by
    change Measurable (reflectCoord x k)
    refine measurable_pi_lambda _ fun i ↦ ?_
    by_cases hik : i = k
    · simp only [reflectCoord, hik, ↓reduceIte]
      fun_prop
    · simp only [reflectCoord, hik, ↓reduceIte]
      fun_prop

@[simp]
theorem reflectCoordMeasurableEquiv_apply {n : ℕ} (x : Fin n → ℝ) (k : Fin n)
    (y : Fin n → ℝ) : reflectCoordMeasurableEquiv x k y = reflectCoord x k y := rfl

theorem measurePreserving_reflectCoord {n : ℕ} (x : Fin n → ℝ) (k : Fin n) :
    MeasurePreserving (reflectCoord x k) volume volume := by
  unfold reflectCoord
  let f : Fin n → ℝ → ℝ := fun i t ↦ if i = k then 2 * x i - t else t
  have hneg : MeasurePreserving (fun t : ℝ ↦ -t) volume volume := by
    refine ⟨measurable_neg, ?_⟩
    change Measure.map (fun t : ℝ ↦ -t) volume = volume
    rw [show (fun t : ℝ ↦ -t) = fun t ↦ (-1 : ℝ) * t by
      funext t
      ring]
    rw [Real.map_volume_mul_left (by norm_num)]
    norm_num
  have hf : ∀ i, MeasurePreserving (f i) volume volume := by
    intro i
    by_cases hik : i = k
    · subst i
      simp only [f, ↓reduceIte, sub_eq_add_neg]
      convert (measurePreserving_add_left volume (2 * x k)).comp hneg using 1
      funext t
      rfl
    · simp only [f, hik, ↓reduceIte]
      exact MeasurePreserving.id volume
  simpa only [f] using volume_preserving_pi hf

theorem reflectCoord_mem_ballSet_iff {n : ℕ} (x : Fin n → ℝ) (ρ : ℝ) (k : Fin n)
    (y : Fin n → ℝ) : reflectCoord x k y ∈ ballSet x ρ ↔ y ∈ ballSet x ρ := by
  simp only [ballSet, Set.mem_ofPred_eq]
  rw [show (∑ i, (reflectCoord x k y i - x i) ^ 2) =
      ∑ i, (y i - x i) ^ 2 by
    apply Finset.sum_congr rfl
    intro i _
    by_cases hik : i = k
    · subst i
      simp [reflectCoord]
      ring
    · simp [reflectCoord, hik]]

theorem reflectCoord_preimage_ballSet {n : ℕ} (x : Fin n → ℝ) (ρ : ℝ) (k : Fin n) :
    reflectCoord x k ⁻¹' ballSet x ρ = ballSet x ρ := by
  ext y
  exact reflectCoord_mem_ballSet_iff x ρ k y

/-- Change variables by one coordinate reflection inside the source's Euclidean ball. -/
theorem integral_reflectCoord_ballSet {n : ℕ} (x : Fin n → ℝ) (ρ : ℝ) (k : Fin n)
    (f : (Fin n → ℝ) → ℝ) :
    (∫ y in ballSet x ρ, f (reflectCoord x k y)) = ∫ y in ballSet x ρ, f y := by
  have h := (measurePreserving_reflectCoord x k).setIntegral_preimage_emb
    (reflectCoordMeasurableEquiv x k).measurableEmbedding f (ballSet x ρ)
  simpa only [reflectCoordMeasurableEquiv_apply, reflectCoord_preimage_ballSet] using h

/-- Every centered coordinate has zero mean on the Euclidean ball. -/
theorem integral_coordinate_sub_ballSet {n : ℕ} (x : Fin n → ℝ) (ρ : ℝ) (i : Fin n) :
    (∫ y in ballSet x ρ, (y i - x i)) = 0 := by
  have h := integral_reflectCoord_ballSet x ρ i (fun y ↦ y i - x i)
  have hneg : -(∫ y in ballSet x ρ, (y i - x i)) =
      ∫ y in ballSet x ρ, (y i - x i) := by
    rw [← integral_neg]
    calc
      (∫ y in ballSet x ρ, -(y i - x i)) =
          ∫ y in ballSet x ρ, reflectCoord x i y i - x i := by
        apply setIntegral_congr_fun (measurableSet_ballSet x ρ)
        intro y _
        dsimp only
        rw [reflectCoord_apply_same]
        ring
      _ = _ := h
  linarith

/-- Distinct centered coordinates are orthogonal on the Euclidean ball. -/
theorem integral_coordinate_sub_mul_coordinate_sub_ballSet {n : ℕ} (x : Fin n → ℝ)
    (ρ : ℝ) {i j : Fin n} (hij : i ≠ j) :
    (∫ y in ballSet x ρ, (y i - x i) * (y j - x j)) = 0 := by
  have h := integral_reflectCoord_ballSet x ρ i
    (fun y ↦ (y i - x i) * (y j - x j))
  have hneg : -(∫ y in ballSet x ρ, (y i - x i) * (y j - x j)) =
      ∫ y in ballSet x ρ, (y i - x i) * (y j - x j) := by
    rw [← integral_neg]
    calc
      (∫ y in ballSet x ρ, -((y i - x i) * (y j - x j))) =
          ∫ y in ballSet x ρ,
            (reflectCoord x i y i - x i) * (reflectCoord x i y j - x j) := by
        apply setIntegral_congr_fun (measurableSet_ballSet x ρ)
        intro y _
        dsimp only
        rw [reflectCoord_apply_same, reflectCoord_apply_of_ne x hij.symm]
        ring
      _ = _ := h
  linarith

/-- A coordinate permutation conjugated by translation about `x`. -/
def permuteAroundMeasurableEquiv {n : ℕ} (x : Fin n → ℝ) (e : Fin n ≃ Fin n) :
    (Fin n → ℝ) ≃ᵐ (Fin n → ℝ) :=
  (MeasurableEquiv.piCongrLeft (fun _ : Fin n ↦ ℝ) e).trans
    (MeasurableEquiv.piCongrRight fun k ↦ MeasurableEquiv.addLeft (x k - x (e.symm k)))

@[simp]
theorem permuteAroundMeasurableEquiv_apply {n : ℕ} (x : Fin n → ℝ) (e : Fin n ≃ Fin n)
    (y : Fin n → ℝ) (k : Fin n) :
    permuteAroundMeasurableEquiv x e y k = x k + (y (e.symm k) - x (e.symm k)) := by
  simp only [permuteAroundMeasurableEquiv, MeasurableEquiv.trans_apply,
    MeasurableEquiv.piCongrRight, MeasurableEquiv.addLeft, MeasurableEquiv.piCongrLeft,
    MeasurableEquiv.coe_mk, Equiv.piCongrRight_apply, Pi.map_apply, Equiv.piCongrLeft_apply]
  simp
  ring

theorem measurePreserving_permuteAround {n : ℕ} (x : Fin n → ℝ) (e : Fin n ≃ Fin n) :
    MeasurePreserving (permuteAroundMeasurableEquiv x e) volume volume := by
  apply MeasurePreserving.trans (volume_measurePreserving_piCongrLeft (fun _ : Fin n ↦ ℝ) e)
  apply volume_preserving_pi
  intro k
  convert measurePreserving_add_left (volume : Measure ℝ) (x k - x (e.symm k)) using 1
  funext t
  rfl

theorem permuteAround_mem_ballSet_iff {n : ℕ} (x : Fin n → ℝ) (ρ : ℝ)
    (e : Fin n ≃ Fin n) (y : Fin n → ℝ) :
    permuteAroundMeasurableEquiv x e y ∈ ballSet x ρ ↔ y ∈ ballSet x ρ := by
  simp only [ballSet, Set.mem_ofPred_eq, permuteAroundMeasurableEquiv_apply]
  rw [show (∑ k, (x k + (y (e.symm k) - x (e.symm k)) - x k) ^ 2) =
      ∑ k, (y k - x k) ^ 2 by
    simp only [add_sub_cancel_left]
    exact Equiv.sum_comp e.symm (fun k ↦ (y k - x k) ^ 2)]

theorem permuteAround_preimage_ballSet {n : ℕ} (x : Fin n → ℝ) (ρ : ℝ)
    (e : Fin n ≃ Fin n) :
    ⇑(permuteAroundMeasurableEquiv x e) ⁻¹' ballSet x ρ = ballSet x ρ := by
  ext y
  exact permuteAround_mem_ballSet_iff x ρ e y

theorem integral_permuteAround_ballSet {n : ℕ} (x : Fin n → ℝ) (ρ : ℝ)
    (e : Fin n ≃ Fin n) (f : (Fin n → ℝ) → ℝ) :
    (∫ y in ballSet x ρ, f (permuteAroundMeasurableEquiv x e y)) =
      ∫ y in ballSet x ρ, f y := by
  have h := (measurePreserving_permuteAround x e).setIntegral_preimage_emb
    (permuteAroundMeasurableEquiv x e).measurableEmbedding f (ballSet x ρ)
  simpa only [permuteAround_preimage_ballSet] using h

/-- All diagonal coordinate second moments agree. -/
theorem integral_coordinate_sub_sq_eq {n : ℕ} (x : Fin n → ℝ) (ρ : ℝ) (i j : Fin n) :
    (∫ y in ballSet x ρ, (y i - x i) ^ 2) =
      ∫ y in ballSet x ρ, (y j - x j) ^ 2 := by
  let e : Fin n ≃ Fin n := Equiv.swap i j
  have h := integral_permuteAround_ballSet x ρ e (fun y ↦ (y i - x i) ^ 2)
  simpa [e] using h.symm

end AffineCarleson.Internal
