import Mathlib.MeasureTheory.Constructions.HaarToSphere
import Mathlib.Analysis.SpecialFunctions.Integrals.Basic

noncomputable section
set_option autoImplicit false

open MeasureTheory Metric Set

namespace AffineCarleson.Internal

private theorem integral_Ioo_pow (m : ℕ) {r : ℝ} (hr : 0 < r) :
    ∫ t in Ioo (0 : ℝ) r, t ^ m = r ^ (m + 1) / (m + 1) := by
  rw [← integral_Ioc_eq_integral_Ioo, ← intervalIntegral.integral_of_le hr.le,
    integral_pow]
  simp

/-- The second radial moment of a ball for an arbitrary additive Haar measure.
This depends only on radial scaling, so no inner product is needed. -/
theorem integral_norm_sq_ball_addHaar
    {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    [Nontrivial E] [MeasurableSpace E] [BorelSpace E]
    (μ : Measure E) [μ.IsAddHaarMeasure] {r : ℝ} (hr : 0 < r) :
    ∫ y in ball (0 : E) r, ‖y‖ ^ 2 ∂μ =
      (Module.finrank ℝ E : ℝ) / ((Module.finrank ℝ E : ℝ) + 2) *
        μ.real (ball (0 : E) r) * r ^ 2 := by
  let d := Module.finrank ℝ E
  have hd : 0 < d := Module.finrank_pos
  let f : ℝ → ℝ := (Iio r).indicator (fun t ↦ t ^ 2)
  have hrad := integral_fun_norm_addHaar μ f
  have hlhs : (∫ y : E, f ‖y‖ ∂μ) = ∫ y in ball (0 : E) r, ‖y‖ ^ 2 ∂μ := by
    rw [← integral_indicator measurableSet_ball]
    apply integral_congr_ae
    filter_upwards with y
    simp only [f, indicator_apply, mem_Iio]
    split_ifs <;> simp_all
  have hrhs : (∫ t in Ioi (0 : ℝ), t ^ (d - 1) • f t) = r ^ (d + 2) / (d + 2) := by
    rw [← integral_indicator measurableSet_Ioi]
    have hfun : (Ioi (0 : ℝ)).indicator (fun t ↦ t ^ (d - 1) • f t) =
        (Ioo 0 r).indicator (fun t ↦ t ^ (d + 1)) := by
      funext t
      simp only [f, indicator_apply, mem_Ioi, mem_Iio, mem_Ioo, smul_eq_mul]
      split_ifs with h₁ h₂ h₃
      · rw [← pow_add]
        congr 1
        omega
      all_goals simp_all
    rw [hfun, integral_indicator measurableSet_Ioo]
    rw [integral_Ioo_pow (d + 1) hr]
    congr 1
    norm_cast
  rw [hlhs, hrhs] at hrad
  rw [hrad]
  simp only [nsmul_eq_mul]
  have hball : μ.real (ball (0 : E) r) = r ^ d * μ.real (ball (0 : E) 1) := by
    dsimp [d]
    rw [Measure.real, μ.addHaar_ball_of_pos (0 : E) hr, ENNReal.toReal_mul,
      ENNReal.toReal_ofReal (pow_nonneg hr.le _)]
    rfl
  rw [hball]
  simp only [d, smul_eq_mul]
  rw [pow_add]
  have hden : (2 : ℝ) + Module.finrank ℝ E ≠ 0 := by positivity
  field_simp [hden, add_comm]

end AffineCarleson.Internal
