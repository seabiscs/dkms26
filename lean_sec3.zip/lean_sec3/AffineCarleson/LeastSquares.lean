import Mathlib.Analysis.InnerProductSpace.Basic
import Mathlib.Tactic

/-! Finite orthogonal least squares. These are general Hilbert-space lemmas;
the Euclidean ball moment identities must be proved before they apply to the
affine approximation theorem. This file does not import a frozen declaration. -/

noncomputable section
set_option autoImplicit false
open scoped BigOperators

namespace AffineCarleson.Internal

variable {ι E : Type*} [Fintype ι]
  [NormedAddCommGroup E] [InnerProductSpace ℝ E]

/-- A finite linear combination, used for the constant and coordinate functions. -/
def finiteFit (w : ι → E) (c : ι → ℝ) : E := ∑ i, c i • w i

/-- Coefficients in a finite, orthogonal, not necessarily normalized family. -/
def leastSquaresCoeff (w : ι → E) (v : E) (i : ι) : ℝ :=
  inner ℝ (w i) v / ‖w i‖ ^ 2

theorem inner_finiteFit (w : ι → E) (c : ι → ℝ)
    (horth : ∀ i j, i ≠ j → inner ℝ (w i) (w j) = 0) (i : ι) :
    inner ℝ (w i) (finiteFit w c) = c i * ‖w i‖ ^ 2 := by
  classical
  rw [finiteFit, inner_sum]
  simp_rw [inner_smul_right]
  rw [Finset.sum_eq_single i]
  · rw [real_inner_self_eq_norm_sq]
  · intro j _ hji
    rw [horth i j (Ne.symm hji), mul_zero]
  · simp only [Finset.mem_univ, not_true_eq_false, false_implies]

theorem inner_residual_eq_zero (w : ι → E) (v : E)
    (horth : ∀ i j, i ≠ j → inner ℝ (w i) (w j) = 0)
    (hnonzero : ∀ i, w i ≠ 0) (i : ι) :
    inner ℝ (w i) (v - finiteFit w (leastSquaresCoeff w v)) = 0 := by
  rw [inner_sub_right, inner_finiteFit w _ horth, leastSquaresCoeff,
    div_mul_cancel₀ _ (pow_ne_zero 2 (norm_ne_zero_iff.mpr (hnonzero i))), sub_self]

theorem finiteFit_injective (w : ι → E)
    (horth : ∀ i j, i ≠ j → inner ℝ (w i) (w j) = 0)
    (hnonzero : ∀ i, w i ≠ 0) : Function.Injective (finiteFit w) := by
  intro c d h
  funext i
  have hi := congrArg (fun z => inner ℝ (w i) z) h
  rw [inner_finiteFit w c horth, inner_finiteFit w d horth] at hi
  exact mul_right_cancel₀ (pow_ne_zero 2 (norm_ne_zero_iff.mpr (hnonzero i))) hi

theorem inner_residual_finiteFit (w : ι → E) (v : E) (c : ι → ℝ)
    (horth : ∀ i j, i ≠ j → inner ℝ (w i) (w j) = 0)
    (hnonzero : ∀ i, w i ≠ 0) :
    inner ℝ (v - finiteFit w (leastSquaresCoeff w v)) (finiteFit w c) = 0 := by
  change inner ℝ (v - finiteFit w (leastSquaresCoeff w v)) (∑ i, c i • w i) = 0
  rw [inner_sum]
  apply Finset.sum_eq_zero
  intro i _
  rw [inner_smul_right, real_inner_comm, inner_residual_eq_zero w v horth hnonzero,
    mul_zero]

theorem leastSquares_pythagoras (w : ι → E) (v : E) (c : ι → ℝ)
    (horth : ∀ i j, i ≠ j → inner ℝ (w i) (w j) = 0)
    (hnonzero : ∀ i, w i ≠ 0) :
    ‖v - finiteFit w c‖ ^ 2 =
      ‖v - finiteFit w (leastSquaresCoeff w v)‖ ^ 2 +
      ‖finiteFit w (leastSquaresCoeff w v) - finiteFit w c‖ ^ 2 := by
  have ho : inner ℝ (v - finiteFit w (leastSquaresCoeff w v))
      (finiteFit w (leastSquaresCoeff w v) - finiteFit w c) = 0 := by
    rw [inner_sub_right, inner_residual_finiteFit w v _ horth hnonzero,
      inner_residual_finiteFit w v _ horth hnonzero, sub_self]
  have hp := norm_add_sq_real (v - finiteFit w (leastSquaresCoeff w v))
    (finiteFit w (leastSquaresCoeff w v) - finiteFit w c)
  rw [sub_add_sub_cancel, ho, mul_zero, add_zero] at hp
  exact hp

theorem leastSquares_minimizes (w : ι → E) (v : E)
    (horth : ∀ i j, i ≠ j → inner ℝ (w i) (w j) = 0)
    (hnonzero : ∀ i, w i ≠ 0) (c : ι → ℝ) :
    ‖v - finiteFit w (leastSquaresCoeff w v)‖ ^ 2 ≤ ‖v - finiteFit w c‖ ^ 2 := by
  rw [leastSquares_pythagoras w v c horth hnonzero]
  exact le_add_of_nonneg_right (sq_nonneg _)

theorem leastSquares_eq_iff (w : ι → E) (v : E)
    (horth : ∀ i j, i ≠ j → inner ℝ (w i) (w j) = 0)
    (hnonzero : ∀ i, w i ≠ 0) (c : ι → ℝ) :
    ‖v - finiteFit w c‖ ^ 2 = ‖v - finiteFit w (leastSquaresCoeff w v)‖ ^ 2 ↔
      c = leastSquaresCoeff w v := by
  constructor
  · intro h
    have hz : ‖finiteFit w (leastSquaresCoeff w v) - finiteFit w c‖ ^ 2 = 0 := by
      have hp := leastSquares_pythagoras w v c horth hnonzero
      linarith only [hp, h]
    have hfit : finiteFit w (leastSquaresCoeff w v) = finiteFit w c :=
      sub_eq_zero.mp (norm_eq_zero.mp (sq_eq_zero_iff.mp hz))
    exact (finiteFit_injective w horth hnonzero hfit).symm
  · rintro rfl
    rfl

theorem existsUnique_leastSquares (w : ι → E) (v : E)
    (horth : ∀ i j, i ≠ j → inner ℝ (w i) (w j) = 0)
    (hnonzero : ∀ i, w i ≠ 0) :
    ∃! c : ι → ℝ, ∀ d : ι → ℝ, ‖v - finiteFit w c‖ ^ 2 ≤ ‖v - finiteFit w d‖ ^ 2 := by
  refine ⟨leastSquaresCoeff w v, leastSquares_minimizes w v horth hnonzero, ?_⟩
  intro c hc
  apply (leastSquares_eq_iff w v horth hnonzero c).mp
  exact le_antisymm (hc _) (leastSquares_minimizes w v horth hnonzero c)

end AffineCarleson.Internal
