import AffineCarleson.AffineIntegrability
import AffineCarleson.BallSecondMoments

noncomputable section
set_option autoImplicit false

open MeasureTheory

namespace AffineCarleson.Internal

private theorem integral_affineValue_ballSet {n N : ℕ} (x : Fin n → ℝ) {ρ : ℝ}
    (hρ : 0 < ρ) (b : Fin N → ℝ) (A : Matrix (Fin N) (Fin n) ℝ) (α : Fin N) :
    (∫ y in ballSet x ρ, affineValue b A x y α) =
      (volume (ballSet x ρ)).toReal * b α := by
  let _ : IsFiniteMeasure (volume.restrict (ballSet x ρ)) :=
    isFiniteMeasure_restrict.mpr (volume_ballSet_ne_top x hρ)
  change (∫ y, b α + ∑ i, A α i * (y i - x i) ∂volume.restrict (ballSet x ρ)) = _
  rw [integral_add (integrable_const _) (integrable_finsetSum Finset.univ fun i _ ↦
    (coordinate_sub_integrableOn_ballSet x hρ i).const_mul (A α i)),
    integral_const, integral_finsetSum Finset.univ]
  simp only [Measure.restrict_apply_univ, Measure.real, smul_eq_mul,
    integral_const_mul, integral_coordinate_sub_ballSet, mul_zero, Finset.sum_const_zero,
    add_zero]
  intro i _
  exact (coordinate_sub_integrableOn_ballSet x hρ i).const_mul (A α i)

private theorem integral_affineValue_mul_coordinate_ballSet {n N : ℕ} (hn : 0 < n)
    (x : Fin n → ℝ) {ρ : ℝ} (hρ : 0 < ρ) (b : Fin N → ℝ)
    (A : Matrix (Fin N) (Fin n) ℝ) (α : Fin N) (i : Fin n) :
    (∫ y in ballSet x ρ, affineValue b A x y α * (y i - x i)) =
      A α i * ((volume (ballSet x ρ)).toReal * ρ ^ 2 / ((n : ℝ) + 2)) := by
  let _ : IsFiniteMeasure (volume.restrict (ballSet x ρ)) :=
    isFiniteMeasure_restrict.mpr (volume_ballSet_ne_top x hρ)
  have hb : IntegrableOn (fun y : Fin n → ℝ ↦ b α * (y i - x i)) (ballSet x ρ) :=
    (coordinate_sub_integrableOn_ballSet x hρ i).const_mul (b α)
  have hs : ∀ j ∈ Finset.univ,
      IntegrableOn (fun y : Fin n → ℝ ↦ A α j * ((y j - x j) * (y i - x i)))
        (ballSet x ρ) := by
    intro j _
    exact (continuous_integrableOn_ballSet x hρ (by fun_prop)).const_mul (A α j)
  change (∫ y, (b α + ∑ j, A α j * (y j - x j)) * (y i - x i)
      ∂volume.restrict (ballSet x ρ)) = _
  have hpoint : (fun y : Fin n → ℝ ↦
      (b α + ∑ j, A α j * (y j - x j)) * (y i - x i)) =
      fun y ↦ b α * (y i - x i) +
        ∑ j, A α j * ((y j - x j) * (y i - x i)) := by
    funext y
    rw [add_mul, Finset.sum_mul]
    apply congrArg (b α * (y i - x i) + ·)
    apply Finset.sum_congr rfl
    intro j _
    ring
  rw [hpoint, integral_add hb (integrable_finsetSum Finset.univ hs),
    integral_finsetSum Finset.univ]
  simp only [integral_const_mul, integral_coordinate_sub_ballSet, mul_zero, zero_add]
  rw [Finset.sum_eq_single i]
  · rw [show (∫ y in ballSet x ρ, (y i - x i) * (y i - x i)) =
        ∫ y in ballSet x ρ, (y i - x i) ^ 2 by
      apply setIntegral_congr_fun (measurableSet_ballSet x ρ)
      intro y _
      ring,
      integral_coordinate_sub_sq_ballSet hn x hρ i]
  · intro j _ hji
    rw [integral_coordinate_sub_mul_coordinate_sub_ballSet x ρ hji]
    simp
  · intro hi
    exact (hi (Finset.mem_univ i)).elim
  · exact hs

/-- The coefficient formulas reproduce every affine map exactly on the source Euclidean ball. -/
theorem affineValue_coefficients_reproduce {n N : ℕ} (hn : 0 < n)
    (x : Fin n → ℝ) {ρ : ℝ} (hρ : 0 < ρ)
    (b : Fin N → ℝ) (A : Matrix (Fin N) (Fin n) ℝ) :
    let mass : ℝ := (volume (ballSet x ρ)).toReal
    let m : Fin N → ℝ := fun α =>
      mass⁻¹ * ∫ y in ballSet x ρ, affineValue b A x y α
    let Q : Matrix (Fin N) (Fin n) ℝ := fun α i =>
      ((n : ℝ) + 2) / ρ ^ 2 *
        (mass⁻¹ * ∫ y in ballSet x ρ, affineValue b A x y α * (y i - x i))
    m = b ∧ Q = A := by
  dsimp only
  have hmass : (volume (ballSet x ρ)).toReal ≠ 0 :=
    (volume_ballSet_toReal_pos x hρ).ne'
  constructor
  · funext α
    rw [integral_affineValue_ballSet x hρ b A α]
    field_simp
  · funext α i
    rw [integral_affineValue_mul_coordinate_ballSet hn x hρ b A α i]
    have hρsq : ρ ^ 2 ≠ 0 := pow_ne_zero _ hρ.ne'
    have hden : (n : ℝ) + 2 ≠ 0 := by positivity
    field_simp [hmass, hρsq, hden]

end AffineCarleson.Internal
