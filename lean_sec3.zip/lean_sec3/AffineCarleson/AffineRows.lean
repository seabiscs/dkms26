import AffineCarleson.AffineIntegrability
import AffineCarleson.L2LeastSquares

/-! The constant/coordinate basis for scalar affine least squares.
Moment hypotheses in the internal lemmas below are obligations that the
Euclidean ball-moment development must supply. No source theorem is assumed. -/

noncomputable section
set_option autoImplicit false
open MeasureTheory
open scoped BigOperators

namespace AffineCarleson.Internal

/-- Constant and centered coordinate functions, indexed together. -/
def rowBasis {n : ℕ} (x : Fin n → ℝ) : Option (Fin n) → (Fin n → ℝ) → ℝ
  | none => fun _ => 1
  | some i => fun y => y i - x i

/-- Coefficients of a single affine row in the constant/coordinate basis. -/
def rowCoeffs {n : ℕ} (b : ℝ) (A : Fin n → ℝ) : Option (Fin n) → ℝ
  | none => b
  | some i => A i

theorem rowBasis_memLp {n : ℕ} (x : Fin n → ℝ) {ρ : ℝ} (hρ : 0 < ρ)
    (i : Option (Fin n)) : MemLp (rowBasis x i) 2 (volume.restrict (ballSet x ρ)) := by
  let _ : IsFiniteMeasure (volume.restrict (ballSet x ρ)) :=
    isFiniteMeasure_restrict.mpr (volume_ballSet_ne_top x hρ)
  cases i with
  | none => exact memLp_const 1
  | some i => exact coordinate_sub_memLp_ballSet x hρ i 2

theorem rowBasis_fit {n : ℕ} (x y : Fin n → ℝ) (b : ℝ) (A : Fin n → ℝ) :
    (∑ i, rowCoeffs b A i * rowBasis x i y) = b + ∑ i, A i * (y i - x i) := by
  simp only [Fintype.sum_option, rowCoeffs, rowBasis, mul_one]

theorem rowCoeffs_injective {n : ℕ} {b c : ℝ} {A C : Fin n → ℝ} :
    rowCoeffs b A = rowCoeffs c C ↔ b = c ∧ A = C := by
  constructor
  · intro h
    exact ⟨congrFun h none, funext (fun i => congrFun h (some i))⟩
  · rintro ⟨rfl, rfl⟩
    rfl

theorem rowBasis_orthogonal {n : ℕ} (x : Fin n → ℝ) (ρ : ℝ)
    (hfirst : ∀ i : Fin n, (∫ y in ballSet x ρ, y i - x i) = 0)
    (hoff : ∀ i j : Fin n, i ≠ j →
      (∫ y in ballSet x ρ, (y i - x i) * (y j - x j)) = 0) :
    ∀ i j : Option (Fin n), i ≠ j →
      (∫ y in ballSet x ρ, rowBasis x i y * rowBasis x j y) = 0 := by
  intro i j hij
  cases i with
  | none =>
    cases j with
    | none => exact (hij rfl).elim
    | some j => simpa only [rowBasis, one_mul] using hfirst j
  | some i =>
    cases j with
    | none => simpa only [rowBasis, mul_one] using hfirst i
    | some j => exact hoff i j (fun h => hij (congrArg some h))

theorem rowBasis_sq_pos {n : ℕ} (x : Fin n → ℝ) {ρ : ℝ} (hρ : 0 < ρ)
    (hdiag : ∀ i : Fin n, (∫ y in ballSet x ρ, (y i - x i) ^ 2) =
      (volume (ballSet x ρ)).toReal * ρ ^ 2 / ((n : ℝ) + 2)) :
    ∀ i : Option (Fin n), 0 < ∫ y in ballSet x ρ, rowBasis x i y ^ 2 := by
  intro i
  cases i with
  | none =>
    simpa only [rowBasis, one_pow, integral_const, Measure.restrict_apply_univ,
      smul_eq_mul, mul_one, Measure.real] using volume_ballSet_toReal_pos x hρ
  | some i =>
    change 0 < ∫ y in ballSet x ρ, (y i - x i) ^ 2
    rw [hdiag i]
    exact div_pos (mul_pos (volume_ballSet_toReal_pos x hρ) (sq_pos_of_pos hρ)) (by positivity)

theorem rowBasis_coeff {n : ℕ} (x : Fin n → ℝ) {ρ : ℝ}
    (f : (Fin n → ℝ) → ℝ)
    (hdiag : ∀ i : Fin n, (∫ y in ballSet x ρ, (y i - x i) ^ 2) =
      (volume (ballSet x ρ)).toReal * ρ ^ 2 / ((n : ℝ) + 2)) :
    (fun i : Option (Fin n) =>
      (∫ y in ballSet x ρ, rowBasis x i y * f y) /
        (∫ y in ballSet x ρ, rowBasis x i y ^ 2)) =
    rowCoeffs
      ((volume (ballSet x ρ)).toReal⁻¹ * ∫ y in ballSet x ρ, f y)
      (fun i => ((n : ℝ) + 2) / ρ ^ 2 *
        ((volume (ballSet x ρ)).toReal⁻¹ * ∫ y in ballSet x ρ, f y * (y i - x i))) := by
  funext i
  cases i with
  | none =>
    simp only [rowBasis, one_mul, one_pow, integral_const, Measure.restrict_apply_univ,
      smul_eq_mul, mul_one, rowCoeffs, Measure.real, div_eq_mul_inv, mul_comm]
  | some i =>
    dsimp only [rowBasis, rowCoeffs]
    rw [hdiag i]
    have hcomm : (∫ y in ballSet x ρ, (y i - x i) * f y) =
        ∫ y in ballSet x ρ, f y * (y i - x i) := by
      congr 1
      funext y
      exact mul_comm _ _
    rw [hcomm]
    field_simp

/-- Scalar affine least squares, conditional only on the explicit ball moments.
This is an internal assembly lemma, not the frozen source theorem. -/
theorem scalar_affine_projection_of_moments {n : ℕ} (x : Fin n → ℝ) {ρ : ℝ}
    (hρ : 0 < ρ) (f : (Fin n → ℝ) → ℝ)
    (hf : MemLp f 2 (volume.restrict (ballSet x ρ)))
    (hfirst : ∀ i : Fin n, (∫ y in ballSet x ρ, y i - x i) = 0)
    (hoff : ∀ i j : Fin n, i ≠ j →
      (∫ y in ballSet x ρ, (y i - x i) * (y j - x j)) = 0)
    (hdiag : ∀ i : Fin n, (∫ y in ballSet x ρ, (y i - x i) ^ 2) =
      (volume (ballSet x ρ)).toReal * ρ ^ 2 / ((n : ℝ) + 2)) :
    let m := (volume (ballSet x ρ)).toReal⁻¹ * ∫ y in ballSet x ρ, f y
    let Q := fun i => ((n : ℝ) + 2) / ρ ^ 2 *
      ((volume (ballSet x ρ)).toReal⁻¹ * ∫ y in ballSet x ρ, f y * (y i - x i))
    (∀ (b : ℝ) (A : Fin n → ℝ),
      (∫ y in ballSet x ρ, (f y - (m + ∑ i, Q i * (y i - x i))) ^ 2) ≤
      ∫ y in ballSet x ρ, (f y - (b + ∑ i, A i * (y i - x i))) ^ 2) ∧
    (∀ (b : ℝ) (A : Fin n → ℝ),
      (∫ y in ballSet x ρ, (f y - (b + ∑ i, A i * (y i - x i))) ^ 2) =
        (∫ y in ballSet x ρ, (f y - (m + ∑ i, Q i * (y i - x i))) ^ 2) ↔
        b = m ∧ A = Q) ∧
    (∀ (b : ℝ) (A : Fin n → ℝ),
      (∫ y in ballSet x ρ, (f y - (m + ∑ i, Q i * (y i - x i))) *
        (b + ∑ i, A i * (y i - x i))) = 0) := by
  dsimp only
  have hw := rowBasis_memLp x hρ
  have ho := rowBasis_orthogonal x ρ hfirst hoff
  have hp := rowBasis_sq_pos x hρ hdiag
  have hc := rowBasis_coeff x f hdiag
  have hci := fun i => congrFun hc i
  constructor
  · intro b A
    have h := l2_leastSquares_minimizes (rowBasis x) hw hf ho hp (rowCoeffs b A)
    dsimp only at h
    simp_rw [hci] at h
    simpa only [rowBasis_fit] using h
  constructor
  · intro b A
    have h := l2_leastSquares_eq_iff (rowBasis x) hw hf ho hp (rowCoeffs b A)
    dsimp only at h
    simp_rw [hci] at h
    simpa only [rowBasis_fit, rowCoeffs_injective] using h
  · intro b A
    have h := l2_leastSquares_orthogonal (rowBasis x) hw hf ho hp (rowCoeffs b A)
    dsimp only at h
    simp_rw [hci] at h
    simpa only [rowBasis_fit] using h

end AffineCarleson.Internal
