import AffineCarleson.BallMoments
import AffineCarleson.RadialMoment
import Mathlib.MeasureTheory.Measure.Haar.InnerProductSpace

noncomputable section
set_option autoImplicit false

open MeasureTheory Metric

namespace AffineCarleson.Internal

private theorem norm_toLp_sq {n : ℕ} (y : Fin n → ℝ) :
    ‖WithLp.toLp 2 y‖ ^ 2 = ∑ i, y i ^ 2 := by
  rw [PiLp.norm_sq_eq_of_L2]
  simp only [Real.norm_eq_abs, sq_abs]

private theorem toLp_preimage_ball {n : ℕ} (ρ : ℝ) (hρ : 0 < ρ) :
    (fun y : Fin n → ℝ ↦ WithLp.toLp 2 y) ⁻¹'
        Metric.ball (0 : EuclideanSpace ℝ (Fin n)) ρ = ballSet 0 ρ := by
  ext y
  simp only [Set.mem_preimage, mem_ball_zero_iff, ballSet, Set.mem_ofPred_eq, Pi.zero_apply,
    sub_zero]
  constructor
  · intro h
    have hsquare := (sq_lt_sq₀ (norm_nonneg _) hρ.le).mpr h
    simpa only [norm_toLp_sq] using hsquare
  · intro h
    apply (sq_lt_sq₀ (norm_nonneg _) hρ.le).mp
    simpa only [norm_toLp_sq] using h

private theorem integral_normSq_origin_ballSet {n : ℕ} (hn : 0 < n) {ρ : ℝ} (hρ : 0 < ρ) :
    (∫ y in ballSet (0 : Fin n → ℝ) ρ, normSq y) =
      (n : ℝ) / ((n : ℝ) + 2) * (volume (ballSet (0 : Fin n → ℝ) ρ)).toReal * ρ ^ 2 := by
  let _ : Nonempty (Fin n) := Fin.pos_iff_nonempty.mp hn
  have hrad := integral_norm_sq_ball_addHaar (E := EuclideanSpace ℝ (Fin n)) volume hρ
  have hchange := (PiLp.volume_preserving_toLp (Fin n)).setIntegral_preimage_emb
    (MeasurableEquiv.toLp 2 (Fin n → ℝ)).measurableEmbedding
    (fun z : EuclideanSpace ℝ (Fin n) ↦ ‖z‖ ^ 2)
      (Metric.ball (0 : EuclideanSpace ℝ (Fin n)) ρ)
  have hmass := (PiLp.volume_preserving_toLp (Fin n)).measure_preimage
    (measurableSet_ball.nullMeasurableSet :
      NullMeasurableSet (Metric.ball (0 : EuclideanSpace ℝ (Fin n)) ρ) volume)
  rw [toLp_preimage_ball ρ hρ] at hchange hmass
  have hmassReal : (volume (ballSet (0 : Fin n → ℝ) ρ)).toReal =
      volume.real (Metric.ball (0 : EuclideanSpace ℝ (Fin n)) ρ) :=
    congrArg ENNReal.toReal hmass
  calc
    (∫ y in ballSet (0 : Fin n → ℝ) ρ, normSq y) =
        ∫ y in ballSet (0 : Fin n → ℝ) ρ, ‖WithLp.toLp 2 y‖ ^ 2 := by
      apply setIntegral_congr_fun (measurableSet_ballSet 0 ρ)
      intro y _
      exact (norm_toLp_sq y).symm
    _ = _ := hchange.trans <| by
      rw [hrad, ← hmassReal]
      simp

private theorem add_preimage_ballSet {n : ℕ} (x : Fin n → ℝ) (ρ : ℝ) :
    (fun y ↦ x + y) ⁻¹' ballSet x ρ = ballSet 0 ρ := by
  ext y
  simp [ballSet]

private theorem integral_normSq_centered_ballSet {n : ℕ} (hn : 0 < n) (x : Fin n → ℝ) {ρ : ℝ}
    (hρ : 0 < ρ) :
    (∫ y in ballSet x ρ, ∑ i, (y i - x i) ^ 2) =
      (n : ℝ) / ((n : ℝ) + 2) * (volume (ballSet x ρ)).toReal * ρ ^ 2 := by
  have hchange := (measurePreserving_add_left volume x).setIntegral_preimage_emb
    (MeasurableEquiv.addLeft x).measurableEmbedding
    (fun y : Fin n → ℝ ↦ ∑ i, (y i - x i) ^ 2) (ballSet x ρ)
  have hmass := (measurePreserving_add_left volume x).measure_preimage
    (measurableSet_ballSet x ρ).nullMeasurableSet
  rw [add_preimage_ballSet x ρ] at hchange hmass
  have horigin := integral_normSq_origin_ballSet hn hρ
  calc
    (∫ y in ballSet x ρ, ∑ i, (y i - x i) ^ 2) =
        ∫ y in ballSet 0 ρ, ∑ i, y i ^ 2 := by
      rw [← hchange]
      apply setIntegral_congr_fun (measurableSet_ballSet 0 ρ)
      intro y _
      simp
    _ = _ := by
      change (∫ y in ballSet 0 ρ, normSq y) = _
      rw [horigin, hmass]

/-- The diagonal second moment of the source's Euclidean ball. -/
theorem integral_coordinate_sub_sq_ballSet {n : ℕ} (hn : 0 < n) (x : Fin n → ℝ)
    {ρ : ℝ} (hρ : 0 < ρ) (i : Fin n) :
    (∫ y in ballSet x ρ, (y i - x i) ^ 2) =
      (volume (ballSet x ρ)).toReal * ρ ^ 2 / ((n : ℝ) + 2) := by
  have hsum := integral_normSq_centered_ballSet hn x hρ
  have hsplit : (∫ y in ballSet x ρ, ∑ i, (y i - x i) ^ 2) =
      ∑ i, ∫ y in ballSet x ρ, (y i - x i) ^ 2 := by
    simpa only [Finset.sum_apply] using
      (integral_finsetSum Finset.univ fun j _ ↦
        continuous_integrableOn_ballSet x hρ (by fun_prop))
  rw [hsplit] at hsum
  have heq : (∑ j : Fin n, ∫ y in ballSet x ρ, (y j - x j) ^ 2) =
      n * (∫ y in ballSet x ρ, (y i - x i) ^ 2) := by
    rw [Finset.sum_eq_card_nsmul (fun j _ ↦ integral_coordinate_sub_sq_eq x ρ j i)]
    simp
  rw [heq] at hsum
  have hnR : (n : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr hn.ne'
  field_simp [hnR] at hsum ⊢
  linarith

/-- The complete centered coordinate covariance formula for the Euclidean ball. -/
theorem integral_coordinate_sub_mul_ballSet {n : ℕ} (hn : 0 < n) (x : Fin n → ℝ)
    {ρ : ℝ} (hρ : 0 < ρ) (i j : Fin n) :
    (∫ y in ballSet x ρ, (y i - x i) * (y j - x j)) =
      if i = j then (volume (ballSet x ρ)).toReal * ρ ^ 2 / ((n : ℝ) + 2) else 0 := by
  by_cases hij : i = j
  · rw [if_pos hij]
    subst j
    simpa only [pow_two] using integral_coordinate_sub_sq_ballSet hn x hρ i
  · rw [if_neg hij]
    exact integral_coordinate_sub_mul_coordinate_sub_ballSet x ρ hij

end AffineCarleson.Internal
