import AffineCarleson.AffineIntegrability
import Mathlib.Analysis.Calculus.FDeriv.Pi
import Mathlib.LinearAlgebra.Matrix.ToLin

noncomputable section
set_option autoImplicit false

namespace AffineCarleson.Internal

/-- The continuous linear map represented by a finite real matrix. -/
def matrixContinuousLinearMap {n N : ℕ} (A : Matrix (Fin N) (Fin n) ℝ) :
    (Fin n → ℝ) →L[ℝ] (Fin N → ℝ) :=
  A.mulVecLin.toContinuousLinearMap

@[simp]
theorem matrixContinuousLinearMap_apply {n N : ℕ} (A : Matrix (Fin N) (Fin n) ℝ)
    (h : Fin n → ℝ) (α : Fin N) :
    matrixContinuousLinearMap A h α = ∑ i, A α i * h i := by
  rfl

/-- Evaluation of an affine map at its chosen center. -/
@[simp]
theorem affineValue_at_center {n N : ℕ} (b : Fin N → ℝ)
    (A : Matrix (Fin N) (Fin n) ℝ) (x : Fin n → ℝ) :
    (fun α ↦ affineValue b A x x α) = b := by
  funext α
  simp [affineValue]

/-- The Fréchet derivative of an affine map is its matrix linear part. -/
theorem hasFDerivAt_affineValue {n N : ℕ} (b : Fin N → ℝ)
    (A : Matrix (Fin N) (Fin n) ℝ) (x y : Fin n → ℝ) :
    HasFDerivAt (fun z α ↦ affineValue b A x z α) (matrixContinuousLinearMap A) y := by
  apply hasFDerivAt_pi''
  intro α
  unfold affineValue
  have hs : HasFDerivAt (fun z : Fin n → ℝ ↦ b α + ∑ i, A α i * (z i - x i))
      (∑ i, A α i • ContinuousLinearMap.proj (R := ℝ) (φ := fun _ : Fin n ↦ ℝ) i) y := by
    fun_prop
  rw [show (ContinuousLinearMap.proj α).comp (matrixContinuousLinearMap A) =
      ∑ i, A α i • ContinuousLinearMap.proj (R := ℝ) (φ := fun _ : Fin n ↦ ℝ) i by
    ext h
    simp [matrixContinuousLinearMap, Matrix.mulVec, dotProduct]]
  exact hs

end AffineCarleson.Internal
