import AffineCarleson.AffineRows

/-! Internal assembly from Euclidean ball moments. The three moment hypotheses
are explicit obligations discharged only in ProjectionProof. This lemma is
not the approved source theorem. -/
noncomputable section
set_option autoImplicit false
open MeasureTheory
namespace AffineCarleson.Internal

theorem affine_projection_of_moments
    (n N : ℕ)
    (x : Fin n → ℝ) (ρ : ℝ) (hρ : 0 < ρ)
    (v : (Fin n → ℝ) → Fin N → ℝ)
    (hv : ∀ α : Fin N, MemLp (fun y => v y α) 2
      (volume.restrict {y : Fin n → ℝ | ∑ i, (y i - x i) ^ 2 < ρ ^ 2}))
    (hfirst : ∀ i : Fin n, (∫ y in ballSet x ρ, y i - x i) = 0)
    (hoff : ∀ i j : Fin n, i ≠ j →
      (∫ y in ballSet x ρ, (y i - x i) * (y j - x j)) = 0)
    (hdiag : ∀ i : Fin n, (∫ y in ballSet x ρ, (y i - x i) ^ 2) =
      (volume (ballSet x ρ)).toReal * ρ ^ 2 / ((n : ℝ) + 2)) :
    let B : Set (Fin n → ℝ) :=
      {y | ∑ i, (y i - x i) ^ 2 < ρ ^ 2}
    let mass : ℝ := (volume B).toReal
    let m : Fin N → ℝ := fun α => mass⁻¹ * ∫ y in B, v y α
    let Q : Matrix (Fin N) (Fin n) ℝ := fun α i =>
      ((n : ℝ) + 2) / ρ ^ 2 *
        (mass⁻¹ * ∫ y in B, v y α * (y i - x i))
    let affine : (Fin N → ℝ) → Matrix (Fin N) (Fin n) ℝ →
        (Fin n → ℝ) → Fin N → ℝ :=
      fun b A y α => b α + ∑ i, A α i * (y i - x i)
    let error : (Fin N → ℝ) → Matrix (Fin N) (Fin n) ℝ → ℝ :=
      fun b A => ∫ y in B, ∑ α, (v y α - affine b A y α) ^ 2
    (0 < mass) ∧
    (∀ α : Fin N, IntegrableOn (fun y => v y α) B) ∧
    (∀ (α : Fin N) (i : Fin n),
      IntegrableOn (fun y => v y α * (y i - x i)) B) ∧
    (∀ (b : Fin N → ℝ) (A : Matrix (Fin N) (Fin n) ℝ),
      IntegrableOn (fun y => ∑ α, (v y α - affine b A y α) ^ 2) B) ∧
    (∃! θ : (Fin N → ℝ) × Matrix (Fin N) (Fin n) ℝ,
      ∀ (b : Fin N → ℝ) (A : Matrix (Fin N) (Fin n) ℝ),
        error θ.1 θ.2 ≤ error b A) ∧
    (∀ (b : Fin N → ℝ) (A : Matrix (Fin N) (Fin n) ℝ),
      IntegrableOn
        (fun y => ∑ α, (v y α - affine m Q y α) * affine b A y α) B ∧
      (∫ y in B, ∑ α, (v y α - affine m Q y α) * affine b A y α) = 0) ∧
    (∀ (b : Fin N → ℝ) (A : Matrix (Fin N) (Fin n) ℝ),
      error m Q ≤ error b A) ∧
    (∀ (b : Fin N → ℝ) (A : Matrix (Fin N) (Fin n) ℝ),
      error b A = error m Q ↔ b = m ∧ A = Q) := by
  let B := ballSet x ρ
  let m : Fin N → ℝ := fun α => (volume B).toReal⁻¹ * ∫ y in B, v y α
  let Q : Matrix (Fin N) (Fin n) ℝ := fun α i =>
    ((n : ℝ) + 2) / ρ ^ 2 * ((volume B).toReal⁻¹ * ∫ y in B, v y α * (y i - x i))
  let error : (Fin N → ℝ) → Matrix (Fin N) (Fin n) ℝ → ℝ :=
    fun b A => ∫ y in B, ∑ α, (v y α - affineValue b A x y α) ^ 2
  have hrow := fun α => scalar_affine_projection_of_moments x hρ
    (fun y => v y α) (hv α) hfirst hoff hdiag
  have herr (b : Fin N → ℝ) (A : Matrix (Fin N) (Fin n) ℝ) :
      error b A = ∑ α, ∫ y in B, (v y α - affineValue b A x y α) ^ 2 := by
    exact integral_finsetSum Finset.univ
      (fun α _ => (residual_memLp_ballSet x hρ v hv b A α).integrable_sq)
  have hmin (b : Fin N → ℝ) (A : Matrix (Fin N) (Fin n) ℝ) :
      error m Q ≤ error b A := by
    rw [herr, herr]
    exact Finset.sum_le_sum (fun α _ => (hrow α).1 (b α) (A α))
  have heq (b : Fin N → ℝ) (A : Matrix (Fin N) (Fin n) ℝ) :
      error b A = error m Q ↔ b = m ∧ A = Q := by
    constructor
    · intro h
      rw [herr, herr] at h
      have hall := (Finset.sum_eq_sum_iff_of_le
        (fun α (_ : α ∈ Finset.univ) => (hrow α).1 (b α) (A α))).mp h.symm
      have hc : ∀ α, b α = m α ∧ A α = Q α := by
        intro α
        exact ((hrow α).2.1 (b α) (A α)).mp (hall α (Finset.mem_univ α)).symm
      exact ⟨funext (fun α => (hc α).1), funext (fun α => (hc α).2)⟩
    · rintro ⟨rfl, rfl⟩
      rfl
  refine ⟨volume_ballSet_toReal_pos x hρ, ?_, ?_, ?_, ?_, ?_, hmin, heq⟩
  · exact component_integrableOn_ballSet x hρ v hv
  · exact component_moment_integrableOn_ballSet x hρ v hv
  · exact squaredResidualSum_integrableOn_ballSet x hρ v hv
  · refine ⟨(m,Q), ?_, ?_⟩
    · exact hmin
    · intro θ hθ
      have ht := (heq θ.1 θ.2).mp (le_antisymm (hθ m Q) (hmin θ.1 θ.2))
      exact Prod.ext ht.1 ht.2
  · intro b A
    refine ⟨residualAffinePairing_integrableOn_ballSet x hρ v hv m b Q A, ?_⟩
    change (∫ y in B, ∑ α,
      (v y α - affineValue m Q x y α) * affineValue b A x y α) = 0
    exact (integral_finsetSum Finset.univ (fun α _ =>
      (residual_memLp_ballSet x hρ v hv m Q α).integrable_mul
        (affineValue_memLp_ballSet x hρ b A α))).trans
      (Finset.sum_eq_zero (fun α _ => (hrow α).2.2 (b α) (A α)))

end AffineCarleson.Internal
