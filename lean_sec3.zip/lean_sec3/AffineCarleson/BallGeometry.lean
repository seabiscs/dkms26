import Mathlib.MeasureTheory.Function.LpSeminorm.Basic
import Mathlib.MeasureTheory.Function.LocallyIntegrable
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.MeasureTheory.Measure.OpenPos

noncomputable section
set_option autoImplicit false

open MeasureTheory Metric Set

namespace AffineCarleson.Internal

/-- The squared Euclidean norm on the plain coordinate carrier `Fin n → ℝ`. -/
def normSq {n : ℕ} (y : Fin n → ℝ) : ℝ := ∑ i, y i ^ 2

/-- The source's Euclidean ball, kept on the plain coordinate carrier `Fin n → ℝ`. -/
def ballSet {n : ℕ} (x : Fin n → ℝ) (ρ : ℝ) : Set (Fin n → ℝ) :=
  {y | ∑ i, (y i - x i) ^ 2 < ρ ^ 2}

theorem continuous_normSq {n : ℕ} : Continuous (normSq : (Fin n → ℝ) → ℝ) := by
  unfold normSq
  fun_prop

theorem isOpen_ballSet {n : ℕ} (x : Fin n → ℝ) (ρ : ℝ) : IsOpen (ballSet x ρ) := by
  unfold ballSet
  exact isOpen_lt (by fun_prop) continuous_const

theorem measurableSet_ballSet {n : ℕ} (x : Fin n → ℝ) (ρ : ℝ) :
    MeasurableSet (ballSet x ρ) :=
  (isOpen_ballSet x ρ).measurableSet

theorem center_mem_ballSet {n : ℕ} (x : Fin n → ℝ) {ρ : ℝ} (hρ : 0 < ρ) :
    x ∈ ballSet x ρ := by
  simp only [ballSet, sub_self, zero_pow (by omega : 2 ≠ 0), Finset.sum_const_zero,
    Set.mem_ofPred_eq]
  positivity

theorem coordinate_abs_sub_lt {n : ℕ} {x y : Fin n → ℝ} {ρ : ℝ}
    (hρ : 0 < ρ) (hy : y ∈ ballSet x ρ) (i : Fin n) : |y i - x i| < ρ := by
  have hterm : (y i - x i) ^ 2 ≤ ∑ j, (y j - x j) ^ 2 :=
    Finset.single_le_sum (fun j _ ↦ sq_nonneg (y j - x j)) (Finset.mem_univ i)
  have hsquare : (y i - x i) ^ 2 < ρ ^ 2 := hterm.trans_lt hy
  rw [sq_lt_sq] at hsquare
  simpa [abs_of_pos hρ] using hsquare

theorem ballSet_subset_closedBall {n : ℕ} (x : Fin n → ℝ) {ρ : ℝ} (hρ : 0 < ρ) :
    ballSet x ρ ⊆ closedBall x ρ := by
  intro y hy
  rw [mem_closedBall, dist_eq_norm, pi_norm_le_iff_of_nonneg hρ.le]
  intro i
  simpa [Real.norm_eq_abs] using (coordinate_abs_sub_lt hρ hy i).le

theorem isCompact_closure_ballSet {n : ℕ} (x : Fin n → ℝ) {ρ : ℝ} (hρ : 0 < ρ) :
    IsCompact (closure (ballSet x ρ)) := by
  exact (isCompact_closedBall x ρ).of_isClosed_subset isClosed_closure
    (closure_minimal (ballSet_subset_closedBall x hρ) isClosed_closedBall)

theorem volume_ballSet_ne_top {n : ℕ} (x : Fin n → ℝ) {ρ : ℝ} (hρ : 0 < ρ) :
    volume (ballSet x ρ) ≠ ⊤ := by
  exact ne_top_of_le_ne_top (isCompact_closure_ballSet x hρ).measure_ne_top
    (measure_mono (subset_closure : ballSet x ρ ⊆ closure (ballSet x ρ)))

theorem volume_ballSet_pos {n : ℕ} (x : Fin n → ℝ) {ρ : ℝ} (hρ : 0 < ρ) :
    0 < volume (ballSet x ρ) := by
  exact (isOpen_ballSet x ρ).measure_pos volume ⟨x, center_mem_ballSet x hρ⟩

theorem volume_ballSet_toReal_pos {n : ℕ} (x : Fin n → ℝ) {ρ : ℝ} (hρ : 0 < ρ) :
    0 < (volume (ballSet x ρ)).toReal := by
  exact ENNReal.toReal_pos (volume_ballSet_pos x hρ).ne' (volume_ballSet_ne_top x hρ)

theorem continuous_integrableOn_ballSet {n : ℕ} (x : Fin n → ℝ) {ρ : ℝ} (hρ : 0 < ρ)
    {f : (Fin n → ℝ) → ℝ} (hf : Continuous f) : IntegrableOn f (ballSet x ρ) := by
  exact hf.continuousOn.integrableOn_of_subset_isCompact (isCompact_closure_ballSet x hρ)
    (measurableSet_ballSet x ρ) subset_closure (volume_ballSet_ne_top x hρ)

theorem coordinate_integrableOn_ballSet {n : ℕ} (x : Fin n → ℝ) {ρ : ℝ} (hρ : 0 < ρ)
    (i : Fin n) : IntegrableOn (fun y : Fin n → ℝ ↦ y i) (ballSet x ρ) := by
  apply continuous_integrableOn_ballSet x hρ
  fun_prop

theorem coordinate_sub_integrableOn_ballSet {n : ℕ} (x : Fin n → ℝ) {ρ : ℝ}
    (hρ : 0 < ρ) (i : Fin n) :
    IntegrableOn (fun y : Fin n → ℝ ↦ y i - x i) (ballSet x ρ) := by
  apply continuous_integrableOn_ballSet x hρ
  fun_prop

theorem coordinate_sub_memLp_ballSet {n : ℕ} (x : Fin n → ℝ) {ρ : ℝ} (hρ : 0 < ρ)
    (i : Fin n) (p : ENNReal) :
    MemLp (fun y : Fin n → ℝ ↦ y i - x i) p (volume.restrict (ballSet x ρ)) := by
  let _ : IsFiniteMeasure (volume.restrict (ballSet x ρ)) :=
    isFiniteMeasure_restrict.mpr (volume_ballSet_ne_top x hρ)
  apply MemLp.of_bound (C := ρ)
    ((by fun_prop : Continuous (fun y : Fin n → ℝ ↦ y i - x i)).aestronglyMeasurable)
  filter_upwards [ae_restrict_mem (measurableSet_ballSet x ρ)] with y hy
  simpa [Real.norm_eq_abs] using (coordinate_abs_sub_lt hρ hy i).le

theorem coordinate_memLp_ballSet {n : ℕ} (x : Fin n → ℝ) {ρ : ℝ} (hρ : 0 < ρ)
    (i : Fin n) (p : ENNReal) :
    MemLp (fun y : Fin n → ℝ ↦ y i) p (volume.restrict (ballSet x ρ)) := by
  let _ : IsFiniteMeasure (volume.restrict (ballSet x ρ)) :=
    isFiniteMeasure_restrict.mpr (volume_ballSet_ne_top x hρ)
  apply MemLp.of_bound (C := ρ + |x i|)
    ((by fun_prop : Continuous (fun y : Fin n → ℝ ↦ y i)).aestronglyMeasurable)
  filter_upwards [ae_restrict_mem (measurableSet_ballSet x ρ)] with y hy
  rw [Real.norm_eq_abs]
  calc
    |y i| = |(y i - x i) + x i| := by ring_nf
    _ ≤ |y i - x i| + |x i| := abs_add_le _ _
    _ ≤ ρ + |x i| := add_le_add (coordinate_abs_sub_lt hρ hy i).le le_rfl

end AffineCarleson.Internal
