# Affine L² projection on Euclidean balls

A Lean 4 / mathlib proof of the explicit affine least-squares approximation on
a Euclidean ball. The source-facing theorem is
[`AffineCarleson.affine_projection_characterization`](Frozen/AffineProjection.lean).

**Scope:** this repository proves the affine projection characterization and
coefficient formula. It does **not** prove the entire supplied excerpt:
Dorronsoro's estimates, the weighted Caccioppoli inequality, and the Carleson
estimate remain unformalized here.

## Mathematical result

For an open Euclidean ball $B=B(x,\rho)$, $\rho>0$, and a vector-valued
function $v\in L^2(B;\mathbb R^N)$, put

$$
m=\frac{1}{|B|}\int_B v(y)\,dy,
\qquad
Q_{\alpha i}=\frac{n+2}{\rho^2|B|}
  \int_B v_\alpha(y)(y_i-x_i)\,dy.
$$

The theorem proves that $y\mapsto m+Q(y-x)$ is the unique affine minimizer
of the squared L² error. It includes positive ball mass, the integrability
obligations, orthogonality of the residual to every affine map, minimality,
and the exact equality case for the coefficients.

The assumptions are the source's standing dimensions $n,N\ge2$, a positive
radius, and coordinatewise L² membership. The ball and squared error are
explicit sums of squares on finite coordinate carriers. In particular, they
are Euclidean quantities, independent of the default norm on function types.

## Build and verify

Install [Lean's elan toolchain manager](https://github.com/leanprover/elan), Git,
and Python 3.10 or newer. The included `lean-toolchain` selects Lean **4.33.0**.
Keep `lake-manifest.json`: it locks mathlib to
`db584cd6d46c92f209a44c0f1c829460d327499d` and pins its dependencies.

From the repository root:

```sh
lake exe cache get
python3 scripts/verify.py
```

The first command obtains the upstream dependency cache. The verifier then:

1. Builds all project modules and rejects compiler warnings.
2. Applies the public theorem at its retained approved type and checks its
   elaborated type hash.
3. Checks the axiom dependencies of every project declaration, including
   private and generated declarations exposed in the imported environment.
4. Replays every project module with Lean's bundled `leanchecker`.

Only `propext`, `Classical.choice`, and `Quot.sound` are permitted in the axiom
census. The source contains no proof holes, custom axioms, unsafe declarations,
or heartbeat overrides. The kernel replay is an additional check using Lean's
kernel, not an independent implementation of that kernel.

Generated verification logs go into the ignored `verification-output/`
directory. For a build alone, use `lake build AffineCarleson`.

## Use from Lean

```lean
import Frozen.AffineProjection

#check AffineCarleson.affine_projection_characterization
#print axioms AffineCarleson.affine_projection_characterization
```

`import AffineCarleson` also imports the supporting infrastructure. The
`AffineCarleson.Internal` namespace contains intermediate lemmas, some with
explicit moment hypotheses. The final theorem discharges those hypotheses
using proved ball moments; they are not assumptions of the public result.

## Layout

| Files | Purpose |
|---|---|
| `Frozen/AffineProjection.lean` | Approved source-facing statement and completed proof |
| `BallGeometry`, `AffineIntegrability` | Ball measure and integrability |
| `BallMoments`, `RadialMoment`, `BallSecondMoments` | Exact first and second moments |
| `LeastSquares`, `L2LeastSquares`, `AffineRows` | Orthogonal least squares and its integral realization |
| `ProjectionAssembly`, `ProjectionProof` | Vector-valued assembly and discharge of moment premises |
| `AffineReproduction`, `AffineDifferentiation` | Additional internal affine-map facts |
| `verification-manifest.json`, `audit/` | Statement identity and recorded verification evidence |
| `scripts/verify.py` | Reproducible build, type, axiom, and kernel checks |
| `.github/workflows/lean.yml` | Checks on GitHub pushes and pull requests |

All helper modules are under `AffineCarleson/`. The names retain the original
project namespace; they do not imply that a Carleson estimate has been proved.

## Source and current status

See [SOURCE.md](SOURCE.md) for the mathematical source, representation choices,
and precisely excluded claims. See [AUDIT.md](AUDIT.md) for the fresh-build and
independent-review results and their limits.

The workflow uses pinned versions of
[Lean's CI action](https://github.com/leanprover/lean-action) and
[GitHub's checkout action](https://github.com/actions/checkout). Its verification
commands have been tested locally; a hosted GitHub Actions run will occur after
this repository is uploaded. No hosted CI success is claimed in this release.
