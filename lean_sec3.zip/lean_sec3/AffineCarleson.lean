import Frozen.AffineProjection
import AffineCarleson.AffineReproduction
import AffineCarleson.AffineDifferentiation

/-! The audited affine projection theorem and proved supporting infrastructure.
The later Dorronsoro, Caccioppoli, and Carleson results remain open. -/
