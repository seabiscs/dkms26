# Mathematical source and coverage

The reference supplied for this formalization is **The Singular Set of Minima
of Multiple Integrals**, by Cristiana De Filippis, Jan Kristensen, Giuseppe
Mingione, and Aidan Strong. The formalized result is the affine projection
formula on supplied PDF p. 5, equation (2.4), also labelled `(pro)` in the
separately supplied text. The standing dimensions $n,N\ge2$ are on PDF p. 1.

The complete supplied PDF and its extracted text are not distributed in this
repository. These hashes identify the exact inputs used for the review:

| Input | SHA-256 |
|---|---|
| Supplied PDF | `3627ef43e5159289cecba6af52c98a6ce9323d2af9b24977bc09d37e2818e170` |
| Supplied LaTeX excerpt | `5b7589e1f6bcfeb21d6ee96a79840fc61bec4f51957d12843a53298fa1e42da0` |

The phrase “L²-orthogonal projection onto the space of affine maps” is
expanded into explicit orthogonality, unique least-squares coefficients,
minimality, and the equality case. Positivity and integrability are proved
conclusions, rather than extra assumptions. The coefficient formula uses the
normalized Lebesgue integral and the exact factor $(n+2)/\rho^2$.

## Representation

| Source object | Lean realization |
|---|---|
| ℝⁿ, ℝᴺ | `Fin n → ℝ`, `Fin N → ℝ` |
| B(x,ρ) | `{y \| ∑ i, (y i - x i)^2 < ρ^2}` |
| Vector L² membership | `MemLp` of each of the finitely many real components |
| ‖v−a‖² | `∑ α, (v y α - a y α)^2` |
| Affine map based at x | `b α + ∑ i, A α i * (y i - x i)` |
| Tensor coefficient | Matrix entry with output index `α` and input index `i` |
| Normalized average | `(volume B).toReal⁻¹ * ∫ y in B, ...` |

The finite-coordinate L² presentation is mathematically equivalent to the
usual finite-dimensional vector-valued L² condition. A separate bundled
vector-L² equivalence theorem is not part of the exported API.

For a radial integration lemma, the implementation explicitly transports
coordinate space to `EuclideanSpace` with its measure-preserving `WithLp`
map. It proves the norm-square identity and equality of the ball measures;
there is no replacement of the source ball by a cube or a sup-norm ball.

The cited affine-projection result is proved directly from mathlib here.
No theorem from the reference's bibliography is introduced as an axiom.

## Exclusions

The source-facing theorem does not export a separately named projection
operator. Proposed future operator definitions are not included in this
release. The source's later uniform normalized Lq bound, projection-gradient
estimate, Dorronsoro square-function/Besov bounds, weighted Caccioppoli
inequality, and Carleson estimate are not formalized here.

There are compiled internal lemmas for reproduction of affine coefficients,
evaluation at the center, and differentiation of an affine map. These helpers
do not constitute closure of the entire affine-approximation subsection.
